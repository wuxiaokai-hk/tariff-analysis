# Tariff price model

Estimates how Canada's counter-tariffs on U.S. goods change consumer prices. It combines two Bank of Canada staff working papers:

1. **Market dampening** (BoC SWP 2026-36). Within each industry, Canadian, U.S. and other foreign firms compete. When a tariff raises U.S. costs, buyers switch suppliers and firms adjust their markups. This gives a **dampening ratio**: the share of the tariff cost that actually reaches prices. The ratio is computed for 32 industries at 5, 10, 15, 25 and 50% tariffs, then mapped to 21 goods.
2. **Supply-chain pass-through** (BoC SWP 2026-35). The dampened tariff on each good passes through Canadian input-output links into the prices of 20 sectors, and then into the consumer price level:

```
dp = (I - A_CA W_CA)^-1  A_US W_US (R x dtau)        dP = gamma' dp  (+ consumer channel)
```

Each run produces:
- an Excel workbook in which every model step is a live formula;
- a CSV summary;
- a short results table on screen.

## Setup

Requires Python 3.9 or newer.

```
pip install -r requirements.txt
```

## Run

```
python run.py                                           # input-output 2024, trade Jan-Dec 2024
python run.py --io-year 2022                            # the papers' input-output year
python run.py --uniform-rate 10                         # custom scenario: 10% on all U.S. goods
python run.py --scenario my_scenario.csv                # custom scenario by HS chapter
python run.py --trade-start 2025-01 --trade-end 2025-12 # newer trade data
python run.py --io-year 2023 --trade-start 2025-09 --trade-end 2026-08
python run.py --list-years                              # input-output years Statistics Canada publishes
python run.py --help
```

| Option | Meaning | Default |
|---|---|---|
| `--io-year` | Year of the input-output table: sector cost shares, consumption weights, imports by origin | 2024 (the papers use 2022) |
| `--trade-start`, `--trade-end` | Months (YYYY-MM) of imports from the U.S. used to weight the tariff lists | 2024-01 to 2024-12 |
| `--iot` | Statistics Canada IOT workbook with separate domestic and imported tables (see below) | off |
| `--shares` | `proportional` or `iot`: source of aCA, aUS and household weights | `iot` with `--iot`, else `proportional` |
| `--omega-us` | `paper` = Table 1; `io` = public table by proportionality; `iot` = IOT tables | `iot` with `--iot`, else `paper` |
| `--omega-ca` | `paper` = Table A1; `io` = public table; `iot` = IOT Domestic table | `iot` with `--iot`, else `paper` |
| `--scenario` | Custom scenario: tariff rate and coverage (%) for each HS chapter (2-digit) | `data/scenario_hs2.csv` |
| `--scenario-hs6` | Optional rates (%) for single HS6 products; they override the chapter rate | `data/scenario_hs6_overrides.csv` (empty) |
| `--uniform-rate` | Custom scenario: one rate (%) on every chapter | off |
| `--N` | Fix the number of Canadian firms per industry instead of calibrating it | calibrated |
| `--refresh` | Download the Statistics Canada files again, e.g. after a new release | off |
| `--no-excel` | Skip the workbook | off |

The first run for a new year or period downloads the data from Statistics Canada:
- input-output tables: about 45 MB;
- trade data: about 80 MB per year.

The downloads are cached in `data/cache` and the aggregated data in `data/processed`, so later runs work offline. The 2022 and 2024 input-output data (with industry detail) and the 2024 trade data are already included.

If a period runs past the latest published month, the model uses the months that are available and prints a warning.

## Data sources (all public)

| Data | Source | Used for |
|---|---|---|
| Input-output tables, detail level, basic prices | Statistics Canada Table 36-10-0001-01 | Output, intermediate use, household consumption, imports by origin (U.S. and other countries) → aUS, aCA, gamma, consumer channel, rest-of-world/U.S. import ratios |
| Imports by HS6 and country, monthly | Statistics Canada CIMT annual import files (`CIMT-CICM_Imp_YYYY.zip`, Open Government Portal) | U.S. imports by product, to weight the tariff lists |
| Counter-tariff lists | Finance Canada (March 4 2025, March 13 2025, vehicles April 2025, September 8 2026), matched to HS6 in `data/tariff_lists_hs6.csv` | Which products are covered and at what rate |
| W_US, W_CA, package totals | BoC SWP 2026-35, Tables 1, A1, 2 | Network structure |
| sigma, rho, Table F.1, Tables 1 and 3 | BoC SWP 2026-36 | Market model and its validation |
| Firm-size distribution | U.S. Census, Profile of U.S. Importing and Exporting Companies 2021-2022, Table 1a | Size groups of U.S. and other foreign firms |

## Using Statistics Canada's IOT workbook (domestic and imported tables)

Statistics Canada provides, on request, an input-output workbook with separate tables by origin. Give it to the model with `--iot`:

```
python run.py --iot path/to/IOT.xlsx --io-year 2024
```

The workbook can have up to four tables, one per sheet. Sheets are recognised by name:

| Sheet | Contents | Used for |
|---|---|---|
| **Total** (required) | All products, domestic and imported | Output, intermediate use, imports, household spending: the same quantities as the public table |
| **Domestic** | Domestically produced products only | **aCA**, **Omega_CA**, household spending on Canadian products (gamma, domestic share) |
| **Import from US** | Products imported from the U.S. | **aUS**, **Omega_US**, household purchases of U.S. imports (consumer channel) |
| **Imports** | Products imported from all countries | Checks (optional) |

Layout of each sheet: supplying industries in rows, with the code in column B and the title in column C. Uses in columns, with the code in row 6 and the title in row 7. Values start in column D and row 8. If the codes are only inside the titles, e.g. "Crop production … [BS111A00]", they are read from there, and pivot-table lines such as "Grand Total" are ignored. If your sheet names differ, use `--iot-sheets "total=Sheet A,domestic=Sheet B,us=Sheet C,imports=Sheet D"`.

**What changes with the IOT tables:**

| Input | Without IOT (public table) | With IOT |
|---|---|---|
| aCA_j | Σ_i Z_ij × (1 − import share of product i): proportionality | Σ_i domestic flow_ij ÷ denominator_j, read directly |
| aUS_j | Σ_i Z_ij × U.S. import share of product i | Σ over goods i of U.S.-imported flow_ij ÷ denominator_j |
| gamma, domestic share of spending | Household spending × (1 − import share) | Household spending on domestic products |
| Consumer channel | Household spending × U.S. import share | Household purchases of U.S. imports |
| Omega_CA (20 × 20) | Paper Table A1 | Each buying sector's domestic inputs by supplying sector |
| Omega_US (20 × 21) | Paper Table 1 | Each buying sector's U.S. goods imports by good |

Notes on the IOT version:
- The denominator is still total intermediate inputs, or output with `Settings B5 = Total cost`.
- aUS counts U.S. imports of **goods**, because tariffs apply to goods.

With `--iot` all of these come from the IOT tables by default. You can switch each piece back:
- `--shares proportional` for aCA, aUS and the household weights;
- `--omega-us paper|io|iot`;
- `--omega-ca paper|io|iot`.

In the workbook, the same choices are the yellow switches **Settings B7, B8 and B9**. The IOT tabs are:
- **N9_IOT_Shares:** aggregates, shares and the two Omegas;
- **N10_IOT_Domestic_Flows** and **N11_IOT_US_Flows:** the industry-level flows.

`N7_Omega_US` and `N8_Omega_CA` show the base table in rows 5-24 and the table in use in rows 30-49.

If the workbook has only a Total table, it replaces the public table, and the shares stay on proportionality.

## Scenario analysis

The fourth package, **Custom scenario**, is yours to set. There are two ways:

- **In Excel, on the yellow Scenario tab:**
  - type a rate (%) for any HS chapter (2-digit) in column E;
  - optionally type the share of that chapter's U.S. imports it hits in column F (100 = all products);
  - or type one rate in C6 to apply it to every chapter;
  - to change single products, type a rate in `T3_Trade_HS6` column P.
  The CPI effect updates in Results row 9 and on the Scenario tab itself.
- **In Python:** copy `data/scenario_hs2.csv` and edit the `rate_pct` and `coverage_pct` columns, then run `python run.py --scenario your_file.csv`.

Each product's dampening ratio is taken at its own tariff rate. It is interpolated between the 5, 10, 15, 25 and 50% market-model results, and held flat above 50% and below 5%.

The default scenario is 25% on chapters 72-83 (iron, steel and other base metals).

## Workbook tabs

Tabs are coloured and numbered by step:

| Colour | Tabs |
|---|---|
| Yellow (inputs you can change) | Scenario, Settings |
| Green | Results |
| Blue, Step 1: tariffs | T1-T3 |
| Orange, Step 2: market dampening | D1-D12 |
| Purple, Step 3: supply-chain network | N1-N8 |
| Grey | Checks, References |

The README tab has a clickable map of every tab.

## The one calibrated number

The market model needs the number of Canadian firms competing in each industry. SWP 2026-36 does not publish it, because it comes from confidential firm data. Each run therefore picks the N that best matches the paper's industry results at a 25% tariff (Table F.1). That is N = 16.0 with the 2022 and 2024 data.

The fit is then checked against the paper's results at 5%, 10% and 50% (Table 3), which are not used in the calibration.

## Results (CPI percentage points, trade 2024)

| Package | Input-output 2024: full | 2024: with dampening | Input-output 2022: full | 2022: with dampening |
|---|---|---|---|---|
| Pre-Sept 2025 (C$96bn at 25%) | 2.81 | 1.51 | 2.92 | 1.58 |
| Post-Sept 2025 (C$50bn at 25%) | 1.41 | 0.75 | 1.47 | 0.78 |
| Sept 8, 2026 round | 0.98 | 0.37 | 1.02 | 0.38 |

Paper (SWP 2026-35, full pass-through): 1.56 and 0.72.

## Files

```
run.py                   command line
tpm/download.py          Statistics Canada downloads
tpm/statcan_io.py        input-output table -> 20 sectors, 21 goods
tpm/statcan_iot.py       reads the IOT workbook (Total / Domestic / Import from US / Imports tables)
tpm/cimt.py              CIMT imports from the U.S. by HS6 for a period
tpm/model.py             market model, calibration, dampening ratios, network model (numpy)
tpm/excel.py             workbook with live formulas
tpm/excel_io.py          N4-N6 tabs: the input-output aggregation as formulas
tpm/excel_iot.py         N9-N11 IOT tabs and the Settings B7-B9 switches
tpm/excel_layout.py      tab names, colours, order and the sheet map
data/scenario_hs2.csv    custom scenario: rate and coverage by HS chapter
data/scenario_hs6_overrides.csv   optional HS6 rates for the custom scenario
tpm/static.py            paper tables, classifications, official list values
data/tariff_lists_hs6.csv   HS6 products on each Finance Canada list (flags; Sept 2026 rate)
tpm/tariff_lists.py      builds data/tariff_lists_hs6.csv from the Finance Canada list pages
tests/test_model.py      parser tests and a regression test against the published results
```

## Rebuilding the tariff-list file

`data/tariff_lists_hs6.csv` is built from the Department of Finance Canada list pages:

```
python -m tpm.tariff_lists                  # download the pages, rebuild the file, compare with the previous one
python -m tpm.tariff_lists --html-dir DIR   # use pages saved from a browser instead
```

What the script does:
1. Reads every table on each page and keeps the 8-digit tariff items (`####.##.##`). For September 8, 2026 it also reads each item's rate (15, 25 or 50%).
2. Cuts each item to HS6. On the March 13, 2025 list, chapters 72-73 count as steel, chapter 76 as aluminum and everything else as other goods. Vehicles are every HS6 under headings 8703 and 8704.
3. Where one HS6 has Sept 2026 items at different rates, it uses the highest rate.
4. Writes `tariff_lists_hs6.csv`, plus `tariff_lists_items.csv` with one row per 8-digit item, so you can check every match.
5. Prints the item counts against the official counts (1,258, 539 and 629) and a comparison with the previous file, which it keeps as `tariff_lists_hs6.csv.previous.csv`.

The pages are cached in `data/cache/lists`. If the download is blocked, open each page in a browser, save it (HTML only) as `mar4_2025.html`, `mar13_2025.html` and `sep8_2026.html` in one folder, and use `--html-dir`.

## Adding a new tariff round

1. Add a column to `data/tariff_lists_hs6.csv` with the new rate for each HS6 product.
2. Add the list's official value to `LISTS` in `tpm/static.py`.
3. Add the package to `effective_tariffs` and `package_ratios` in `tpm/model.py`, following the Sept 2026 round as the example.

## Notes

- The workbook is written without stored results. Excel calculates it when the file is opened. It has about 150,000 formulas, so the first calculation takes a few seconds.
- The input-output aggregation is in the workbook too:
  - **N4_IO_Industries** has one row per Statistics Canada industry: output, each household-spending column and the imports by origin.
  - **N5_IO_Flows** has the industry-by-industry flows.
  - **N6_IO_Mapping** holds the industry → sector and industry → good mappings.
  - N2_IO_Sectors and N3_IO_Goods are SUMIFS/SUMPRODUCT formulas on these tabs.
  - A check compares the workbook totals with the Python aggregation.
- The Python results and the workbook use the same equations. The regression test checks that the Python results match the published workbook.
- Run the tests with `python tests/test_model.py`.
