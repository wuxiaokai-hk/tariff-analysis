"""Run with:  python -m pytest tests   (or: python tests/test_model.py)

1. Parsers on small files in the exact Statistics Canada formats.
2. Regression: input-output 2022 + trade 2024 reproduces the published workbook results.
"""
import csv
import io
import json
import os
import sys
import tempfile
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
from tpm import cimt, model, statcan_io  # noqa: E402

IO_HEADER = '"REF_DATE","GEO","DGUID","Valuation","Supply","Use","UOM","UOM_ID","SCALAR_FACTOR","SCALAR_ID","VECTOR","COORDINATE","VALUE","STATUS","SYMBOL","TERMINATED","DECIMALS"'


def io_line(year, val, sup, use, v):
    return f'"{year}","Canada","2021A000011124","{val}","{sup}","{use}","Dollars","81","thousands","3","v1","1.1.1.1","{v}","","","","0"'


def test_io_parser():
    crop = "Crop production (except cannabis, greenhouse, nursery and floriculture production) [BS111A00]"
    lines = [IO_HEADER,
             io_line(2022, "Basic price", crop, "Total use", 63318748),
             io_line(2022, "Basic price", crop, "Household final consumption expenditure, food [PEC01100]", 9085583),
             io_line(2022, "Basic price", crop, "Imports from United States [INTIMUS]", -11935059),
             io_line(2022, "Basic price", crop, "Imports from rest of the world [INTIMRW]", -5077846),
             io_line(2022, "Basic price", crop, "Meat product manufacturing [BS311600]", 1000),
             io_line(2022, "Basic price", "Other activities of the construction industry [BS23E000]", "Imports from United States [INTIMUS]", -127784),
             io_line(2022, "Basic price", "Wages and salaries [PRM100000]", "Total use", 5),
             io_line(2022, "Purchaser price", crop, "Total use", 99),
             io_line(2021, "Basic price", crop, "Total use", 99)]
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "36100001-eng.zip")
        with zipfile.ZipFile(p, "w") as z:
            z.writestr("36100001.csv", "\n".join(lines) + "\n"); z.writestr("36100001_MetaData.csv", "x")
        r = statcan_io.aggregate_rows(statcan_io._rows(p), 2022)
        assert statcan_io.available_years(p) == ["2021", "2022"]
    assert r["X"][0] == 63318748 and r["H"][0] == 9085583
    assert r["M"][0] == 17012905 and r["MUS"][0] == 11935059
    assert r["MUS"][3] == 0 and r["M"][3] == 127784          # construction: no U.S. goods imports counted
    assert r["Z"][0][4] == 1000 and r["MUS_g"][1] == 11935059
    assert abs(r["HUS_g"][1] - 9085583 * 11935059 / (63318748 + 17012905)) < 1e-6
    det = r["detail"]                                        # industry detail for the IO_Industries / IO_Z sheets
    assert det["inds"] == ["BS111A00", "BS23E000", "BS311600"] and det["pec"] == ["PEC01100"]
    assert det["rows"][0] == [63318748, 9085583, -11935059, 0, 0, -5077846] and det["Z"][0][2] == 1000


def test_cimt_parser():
    hdr = "YearMonth/AnnéeMois,HS6,Country/Pays,Province,State/État,Value/Valeur,Quantity/Quantité,Unit of Measure/Unité de Mesure\r\n"
    rows = ['"202312","010121","US","ON","KY",5,1,"NMB"', '"202401","010121","US","ON","KY",153452,12,"NMB"',
            '"202401","010121","AU","ON",,13297,1,"NMB"', '"202402","720851","US","QC","PA",1000,1,"KGM"']
    desc = ("010121     202201 999912 NMB Horses; live, pure-bred breeding animals                                          Chevaux vivants\r\n"
            "720851     200201 999912 KGM Flat-rolled iron, width >=600mm, >10mm thick                                     Produits laminés\r\n")
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "CIMT-CICM_Imp_2024.zip")
        with zipfile.ZipFile(p, "w") as z:
            z.writestr("CIMT-CICM_Imp_2024/ODPFN015_202412N.csv", (hdr + "\r\n".join(rows) + "\r\n").encode("utf-8"))
            z.writestr("CIMT-CICM_Imp_2024/ODPF_3_HS6MDesc.TXT", desc.encode("latin-1"))
        vals, de, months = cimt.sum_us_imports([p], "2024-01", "2024-01")
    assert vals == {"010121": 153452.0} and months == [202401]
    assert de["010121"].startswith("Horses")


def test_regression_2022_2024():
    io_ = json.load(open(os.path.join(ROOT, "data", "processed", "io_2022.json")))
    rows = [(r["HS6"], r["Description"], float(r["US_imports_CAD"]))
            for r in csv.DictReader(open(os.path.join(ROOT, "data", "processed", "us_imports_2024-01_2024-12.csv"), encoding="utf-8"))]
    res = model.run(io_, rows, os.path.join(ROOT, "data", "tariff_lists_hs6.csv"), {"calibrate_N": True})
    s = res["specs"][("Intermediate inputs", True)]
    assert abs(res["N"] - 16.04) < 0.01
    for got, want in zip(s["full"]["total"][:3], (2.9227, 1.4703, 1.0235)):
        assert abs(got - want) < 1e-3
    for got, want in zip(s["damp"]["total"][:3], (1.5767, 0.7800, 0.3830)):
        assert abs(got - want) < 1e-3
    assert abs(res["corr"] - 0.955) < 0.002
    # custom scenario: no scenario -> zero; 25% on HS chapters 72-83 = 25% on all base metals
    assert abs(s["full"]["total"][3]) < 1e-12
    scen = model.read_scenario(os.path.join(ROOT, "data", "scenario_hs2.csv"))
    res2 = model.run(io_, rows, os.path.join(ROOT, "data", "tariff_lists_hs6.csv"), {"calibrate_N": False, "N": res["N"], "scenario": scen})
    s2 = res2["specs"][("Intermediate inputs", True)]
    assert abs(s2["full"]["total"][3] - 0.6367) < 1e-3 and abs(s2["damp"]["total"][3] - 0.3446) < 1e-3
    scen["uniform"] = 10.0                                       # uniform rate overrides every chapter
    res3 = model.run(io_, rows, os.path.join(ROOT, "data", "tariff_lists_hs6.csv"), {"calibrate_N": False, "N": res["N"], "scenario": scen})
    assert abs(res3["tar"]["tau"][0, 3] - 0.10) < 1e-9


def test_tariff_list_parser():
    from tpm import tariff_lists as tl
    row = lambda it, *rest: "<tr><td>" + it + "</td>" + "".join(f"<td>{x}</td>" for x in rest) + "</tr>"
    head = "<thead><tr><th>Tariff Item</th><th>Harmonized System (HS) Heading</th><th>Indicative Description</th></tr></thead>"
    mar4 = "<h2>List</h2><table><caption>Table 1</caption>" + head + "<tbody>" + row("0105.11.22", "Live poultry", "Broilers") + row("0105.94.92", "x", "y") + "</tbody></table>"
    mar13 = ("<table>" + head + "<tbody>" + row("7208.51.00", "Flat-rolled", "x") + row("7606.12.00", "Aluminum plates", "x")
             + row("9506.62.00", "Balls", "x") + "</tbody></table>")
    sep = ("<h3>Products subject to a 50 per cent surtax</h3><table>" + head + "<tbody>" + row("0402.10.00", "Milk", "x") + row("7208.51.00", "Steel", "x") + "</tbody></table>"
           "<h3>Products subject to a 15 per cent surtax</h3><table>" + head + "<tbody>" + row("0402.10.90", "Milk", "x") + "</tbody></table>"
           "<table><thead><tr><th>Tariff Item</th><th>Description</th><th>Rate of surtax</th></tr></thead><tbody>" + row("9506.62.00", "Balls", "25%") + "</tbody></table>")
    items, flags, counts = tl.build({"mar4": mar4, "mar13": mar13, "sep2026": sep}, ["870323", "870421", "010511"])
    assert counts["mar4"] == 2 and counts["mar13"] == 3 and counts["sep2026"] == 4 and counts["mixed_rate_hs6"] == 1
    assert flags["010511"]["Mar4_2025"] == 1 and flags["720851"]["Mar13_steel"] == 1 and flags["760612"]["Mar13_aluminum"] == 1
    assert flags["950662"]["Mar13_other"] == 1 and flags["950662"]["Sep2026_rate"] == 25
    assert flags["040210"]["Sep2026_rate"] == 50 and flags["720851"]["Sep2026_rate"] == 50     # 50 and 15 in one HS6 -> highest
    assert flags["870323"]["Vehicles_8703_8704"] == 1 and "Vehicles_8703_8704" not in flags.get("010511", {})


def test_iot_workbook():
    """Four-sheet IOT workbook in the Statistics Canada layout -> aCA, aUS, gamma, Omega_CA, Omega_US read directly."""
    from openpyxl import Workbook
    from tpm import statcan_iot, model
    inds = [("BS111A00", "Crop production"), ("BS331100", "Iron and steel mills"), ("GS911100", "Defence services")]
    uses = inds + [("PEC01100", "Household consumption expenditure, food"), ("INTIMUS", "International imports from United States"),
                   ("INTIMRW", "International imports from the rest of the world"), ("Total use", "Total use")]
    # supply -> use; Domestic and US tables hold the split of the intermediate and household columns
    dom = {"BS111A00": {"BS111A00": 6, "BS331100": 1, "GS911100": 2, "PEC01100": 30},
           "BS331100": {"BS111A00": 3, "BS331100": 20, "GS911100": 5, "PEC01100": 1},
           "GS911100": {"GS911100": 1}}
    us = {"BS111A00": {"BS111A00": 2, "BS331100": 0, "GS911100": 0, "PEC01100": 10},
          "BS331100": {"BS111A00": 1, "BS331100": 10, "GS911100": 1, "PEC01100": 0}}
    tot = {k: {u: dom.get(k, {}).get(u, 0) + us.get(k, {}).get(u, 0) for u, _ in uses[:4]} for k, _ in inds}
    tot["BS111A00"].update({"INTIMUS": -12, "INTIMRW": 0, "Total use": 100})
    tot["BS331100"].update({"INTIMUS": -12, "INTIMRW": -5, "Total use": 200})
    tot["GS911100"].update({"Total use": 50})
    wb = Workbook(); wb.remove(wb.active)
    for name, tab in (("Total", tot), ("Domestic", dom), ("Import from US", us)):
        ws = wb.create_sheet(name)
        for k, (c, t) in enumerate(uses):
            ws.cell(row=6, column=4 + k, value=c); ws.cell(row=7, column=4 + k, value=t)
        for i, (c, t) in enumerate(inds):
            ws.cell(row=8 + i, column=2, value=c); ws.cell(row=8 + i, column=3, value=t)
            for k, (u, _) in enumerate(uses):
                if tab.get(c, {}).get(u):
                    ws.cell(row=8 + i, column=4 + k, value=tab[c][u])
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "IOT.xlsx"); wb.save(p)
        io_ = statcan_iot.aggregate(statcan_iot.read_workbook(p), 2024)
    assert io_["iot"]["has"] == ["total", "domestic", "us"]
    par = model.network_params(io_, shares="iot", omega_us="iot", omega_ca="iot")
    # agriculture (sector 0) buys: crops 6+2, steel 3+1 -> total 12; domestic 9; U.S. goods 3
    assert abs(par["aCA"][0] - 9 / 12) < 1e-12 and abs(par["aUS"][0] - 3 / 12) < 1e-12
    # Omega_US of agriculture: U.S. crops 2 (good 2), U.S. steel 1 (good 15)
    assert abs(par["W_US"][0, 1] - 2 / 3) < 1e-12 and abs(par["W_US"][0, 14] - 1 / 3) < 1e-12
    # Omega_CA of manufacturing (sector 4): domestic from agriculture 1, from manufacturing 20
    assert abs(par["W_CA"][4, 0] - 1 / 21) < 1e-12 and abs(par["W_CA"][4, 4] - 20 / 21) < 1e-12
    # households: domestic 30 + 1 (gamma), U.S. crops 10 (consumer channel, good 2)
    assert abs(par["gamma"][0] - 30 / 31) < 1e-12 and abs(par["c_g"][1] * io_["Htot"] - 10) < 1e-9


if __name__ == "__main__":
    for f in (test_io_parser, test_cimt_parser, test_regression_2022_2024, test_tariff_list_parser, test_iot_workbook):
        f(); print("passed:", f.__name__)
