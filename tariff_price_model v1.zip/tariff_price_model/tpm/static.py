"""Fixed inputs: tables printed in the two Bank of Canada papers, classifications and official tariff-list values.

Nothing here depends on the period you choose. Period-dependent data (input-output table, trade) are downloaded
from Statistics Canada by download.py.
"""

# ---------------- Sectors and goods (BoC SWP 2026-35, Tables 1 and A1)
SECTORS = ['Agriculture', 'Mining', 'Utilities', 'Construction', 'Manufacturing', 'Retail trade', 'Wholesale trade', 'Transportation and warehousing', 'Information industries', 'Finance and insurance', 'Real estate', 'Professional services', 'Management of companies', 'Admin. and support', 'Educational services', 'Health care and social assistance', 'Arts, entertainment and recreation', 'Accommodation and food services', 'Other services', 'Public administration']
SECTOR_NAICS = ['11', '21', '22', '23', '31-33', '44-45', '41', '48-49', '51', '52', '53', '54', '55', '56', '61', '62', '71', '72', '81', '91']
GOODS = ['Live animals & animal products', 'Vegetable products', 'Animal & vegetable fats', 'Prepared foods & beverages', 'Mineral products', 'Chemical products', 'Plastics & rubber', 'Hides & leather', 'Wood', 'Wood pulp & paper', 'Textiles', 'Footwear', 'Stone & glass', 'Precious metals', 'Base metals', 'Machinery', 'Transport equipment', 'Optical & medical instruments', 'Arms', 'Misc. manufactures', 'Artwork']

# Map from the first two NAICS digits of a Statistics Canada input-output industry code (BS/NP/GS) to a sector index.
NAICS2_TO_SECTOR = {"11": 0, "21": 1, "22": 2, "23": 3, "31": 4, "32": 4, "33": 4, "44": 5, "45": 5, "41": 6,
                    "48": 7, "49": 7, "51": 8, "52": 9, "53": 10, "54": 11, "55": 12, "56": 13, "61": 14, "62": 15,
                    "71": 16, "72": 17, "81": 18, "91": 19}
# NP999999 (non-profit institutions, other) goes to Other services.
SPECIAL_SECTOR = {"NP999999": 18}

# Goods (1-21) produced by input-output industries: longest matching prefix of the industry code after BS/NP/GS.
IO_INDUSTRY_TO_GOOD = [
    (1, ["112", "114", "3115", "3116", "3117"]),
    (2, ["111A", "1114", "111C", "3112"]),
    (4, ["3111", "3113", "3114", "3118", "3119", "312"]),
    (5, ["211", "212", "213", "221", "324"]),
    (6, ["325"]), (7, ["326"]), (9, ["113", "321"]), (10, ["322", "323"]), (11, ["31A", "31B"]), (13, ["327"]),
    (15, ["331", "332"]), (16, ["333", "334", "335"]), (17, ["336"]), (20, ["337", "339"]),
]
GOODS_SECTORS = (0, 1, 2, 4)   # sectors whose output is goods (NAICS 11, 21, 22, 31-33)

# W_US: BoC SWP 2026-35 Table 1 (rows = 20 sectors, columns = 21 goods; rows sum to 1)
OMEGA_US = [
    [0.17, 0.17, 0.00, 0.03, 0.00, 0.23, 0.20, 0.00, 0.06, 0.02, 0.00, 0.00, 0.00, 0.00, 0.01, 0.06, 0.04, 0.00, 0.00, 0.00, 0.00],
    [0.00, 0.00, 0.00, 0.00, 0.81, 0.07, 0.02, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.01, 0.02, 0.05, 0.01, 0.00, 0.00, 0.00, 0.00],
    [0.00, 0.00, 0.00, 0.00, 0.88, 0.00, 0.01, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.01, 0.06, 0.02, 0.01, 0.00, 0.00, 0.00],
    [0.00, 0.00, 0.00, 0.02, 0.01, 0.03, 0.07, 0.00, 0.02, 0.00, 0.02, 0.00, 0.02, 0.00, 0.13, 0.51, 0.08, 0.03, 0.00, 0.05, 0.00],
    [0.01, 0.02, 0.00, 0.05, 0.03, 0.09, 0.09, 0.00, 0.01, 0.03, 0.01, 0.00, 0.01, 0.04, 0.09, 0.18, 0.30, 0.02, 0.00, 0.01, 0.00],
    [0.00, 0.04, 0.00, 0.12, 0.04, 0.08, 0.02, 0.00, 0.01, 0.01, 0.01, 0.00, 0.01, 0.03, 0.01, 0.04, 0.50, 0.02, 0.00, 0.05, 0.00],
    [0.01, 0.04, 0.00, 0.08, 0.03, 0.18, 0.06, 0.00, 0.01, 0.03, 0.01, 0.00, 0.01, 0.00, 0.08, 0.23, 0.15, 0.04, 0.00, 0.02, 0.00],
    [0.01, 0.01, 0.00, 0.01, 0.09, 0.02, 0.02, 0.00, 0.01, 0.01, 0.00, 0.00, 0.00, 0.01, 0.04, 0.22, 0.50, 0.03, 0.00, 0.02, 0.00],
    [0.00, 0.01, 0.00, 0.00, 0.00, 0.03, 0.01, 0.00, 0.00, 0.35, 0.01, 0.00, 0.00, 0.01, 0.01, 0.52, 0.00, 0.03, 0.00, 0.03, 0.00],
    [0.02, 0.04, 0.00, 0.01, 0.30, 0.01, 0.02, 0.00, 0.01, 0.03, 0.00, 0.00, 0.01, 0.32, 0.03, 0.14, 0.05, 0.01, 0.00, 0.00, 0.00],
    [0.02, 0.00, 0.04, 0.04, 0.00, 0.01, 0.04, 0.00, 0.01, 0.00, 0.00, 0.00, 0.05, 0.00, 0.07, 0.38, 0.26, 0.04, 0.00, 0.02, 0.01],
    [0.01, 0.00, 0.00, 0.02, 0.00, 0.10, 0.03, 0.00, 0.00, 0.01, 0.00, 0.00, 0.01, 0.00, 0.04, 0.59, 0.02, 0.15, 0.00, 0.01, 0.01],
    [0.01, 0.05, 0.00, 0.04, 0.62, 0.05, 0.02, 0.00, 0.01, 0.03, 0.00, 0.00, 0.00, 0.00, 0.05, 0.07, 0.03, 0.00, 0.00, 0.00, 0.00],
    [0.00, 0.04, 0.00, 0.03, 0.06, 0.09, 0.13, 0.00, 0.01, 0.11, 0.03, 0.00, 0.01, 0.02, 0.06, 0.27, 0.08, 0.02, 0.00, 0.04, 0.00],
    [0.01, 0.00, 0.00, 0.00, 0.00, 0.10, 0.01, 0.00, 0.00, 0.09, 0.02, 0.00, 0.00, 0.00, 0.02, 0.24, 0.14, 0.33, 0.00, 0.03, 0.00],
    [0.00, 0.00, 0.00, 0.00, 0.00, 0.35, 0.02, 0.00, 0.00, 0.01, 0.00, 0.00, 0.00, 0.00, 0.01, 0.07, 0.01, 0.36, 0.00, 0.15, 0.00],
    [0.01, 0.00, 0.00, 0.06, 0.00, 0.01, 0.01, 0.00, 0.00, 0.02, 0.01, 0.00, 0.00, 0.00, 0.01, 0.08, 0.19, 0.01, 0.01, 0.43, 0.15],
    [0.03, 0.30, 0.00, 0.24, 0.00, 0.01, 0.07, 0.00, 0.00, 0.05, 0.01, 0.00, 0.01, 0.00, 0.01, 0.09, 0.11, 0.00, 0.00, 0.05, 0.00],
    [0.00, 0.01, 0.00, 0.01, 0.00, 0.05, 0.04, 0.00, 0.00, 0.02, 0.04, 0.01, 0.01, 0.00, 0.05, 0.57, 0.11, 0.08, 0.00, 0.01, 0.00],
    [0.00, 0.00, 0.00, 0.00, 0.00, 0.20, 0.02, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.02, 0.44, 0.10, 0.13, 0.06, 0.02, 0.00]]

# W_CA: BoC SWP 2026-35 Table A1 (rows = buying sector, columns = supplying sector; rows sum to 1)
OMEGA_CA = [
    [0.29, 0.01, 0.03, 0.02, 0.42, 0.02, 0.04, 0.06, 0.00, 0.03, 0.01, 0.04, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00],
    [0.00, 0.23, 0.04, 0.04, 0.29, 0.02, 0.07, 0.05, 0.01, 0.05, 0.02, 0.11, 0.01, 0.05, 0.00, 0.00, 0.00, 0.01, 0.01, 0.01],
    [0.00, 0.23, 0.04, 0.17, 0.17, 0.02, 0.04, 0.03, 0.03, 0.06, 0.02, 0.13, 0.00, 0.04, 0.00, 0.00, 0.00, 0.01, 0.00, 0.01],
    [0.01, 0.05, 0.00, 0.00, 0.54, 0.03, 0.08, 0.04, 0.00, 0.03, 0.02, 0.14, 0.00, 0.02, 0.00, 0.00, 0.00, 0.00, 0.01, 0.01],
    [0.10, 0.18, 0.02, 0.01, 0.50, 0.01, 0.05, 0.06, 0.01, 0.02, 0.01, 0.02, 0.00, 0.01, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00],
    [0.00, 0.02, 0.03, 0.03, 0.10, 0.02, 0.03, 0.09, 0.07, 0.15, 0.17, 0.15, 0.00, 0.09, 0.01, 0.00, 0.01, 0.03, 0.00, 0.02],
    [0.00, 0.02, 0.02, 0.01, 0.15, 0.02, 0.03, 0.16, 0.09, 0.10, 0.07, 0.18, 0.00, 0.10, 0.00, 0.00, 0.00, 0.02, 0.00, 0.02],
    [0.00, 0.01, 0.01, 0.05, 0.31, 0.01, 0.03, 0.34, 0.02, 0.05, 0.04, 0.03, 0.00, 0.04, 0.00, 0.00, 0.00, 0.02, 0.02, 0.01],
    [0.00, 0.00, 0.01, 0.01, 0.21, 0.02, 0.03, 0.03, 0.35, 0.03, 0.05, 0.12, 0.00, 0.06, 0.01, 0.00, 0.03, 0.02, 0.02, 0.01],
    [0.00, 0.00, 0.01, 0.01, 0.03, 0.00, 0.01, 0.02, 0.05, 0.59, 0.02, 0.14, 0.00, 0.06, 0.00, 0.00, 0.00, 0.01, 0.02, 0.02],
    [0.00, 0.01, 0.03, 0.26, 0.07, 0.01, 0.02, 0.03, 0.03, 0.17, 0.09, 0.07, 0.00, 0.14, 0.00, 0.00, 0.01, 0.02, 0.02, 0.02],
    [0.00, 0.00, 0.01, 0.01, 0.13, 0.02, 0.04, 0.04, 0.10, 0.04, 0.08, 0.31, 0.00, 0.12, 0.01, 0.00, 0.01, 0.04, 0.03, 0.01],
    [0.00, 0.00, 0.01, 0.01, 0.06, 0.01, 0.02, 0.04, 0.06, 0.12, 0.08, 0.28, 0.00, 0.22, 0.00, 0.00, 0.01, 0.01, 0.03, 0.02],
    [0.00, 0.00, 0.01, 0.02, 0.21, 0.03, 0.05, 0.06, 0.06, 0.05, 0.09, 0.16, 0.00, 0.12, 0.01, 0.00, 0.01, 0.04, 0.06, 0.01],
    [0.00, 0.02, 0.04, 0.08, 0.19, 0.02, 0.04, 0.14, 0.07, 0.01, 0.05, 0.10, 0.00, 0.11, 0.02, 0.00, 0.01, 0.04, 0.04, 0.03],
    [0.00, 0.00, 0.02, 0.02, 0.32, 0.04, 0.07, 0.02, 0.03, 0.02, 0.05, 0.05, 0.00, 0.06, 0.01, 0.18, 0.00, 0.03, 0.04, 0.03],
    [0.00, 0.00, 0.02, 0.03, 0.19, 0.10, 0.04, 0.04, 0.06, 0.04, 0.07, 0.05, 0.00, 0.12, 0.00, 0.00, 0.11, 0.05, 0.04, 0.02],
    [0.05, 0.00, 0.02, 0.02, 0.48, 0.04, 0.05, 0.04, 0.03, 0.05, 0.08, 0.03, 0.00, 0.05, 0.00, 0.00, 0.01, 0.01, 0.01, 0.01],
    [0.00, 0.01, 0.03, 0.01, 0.32, 0.04, 0.05, 0.06, 0.04, 0.07, 0.10, 0.08, 0.00, 0.10, 0.01, 0.00, 0.01, 0.04, 0.03, 0.02],
    [0.00, 0.01, 0.02, 0.04, 0.17, 0.02, 0.04, 0.03, 0.03, 0.04, 0.03, 0.11, 0.00, 0.08, 0.02, 0.29, 0.01, 0.01, 0.01, 0.04]]

# Paper results (Table 2), full pass-through, pp of CPI: (direct, indirect, total)
PAPER_TABLE2 = {"pre": (0.55, 1.01, 1.56), "post": (0.24, 0.48, 0.72)}

# ---------------- Market model (BoC SWP 2026-36)
SIGMA = 10.5   # within-industry substitution (Section 3.2, from Edmond, Midrigan and Xu 2015)
RHO = 1.24     # across-industry substitution
# Table F.1: (NAICS, industry, U.S. share %, exact %, first-order %, markup %, cost %) at a 25% tariff
TABLE_F1 = [(111, 'Crop Production', 25.0, 2.4, 4.15, -1.43, 5.59), (112, 'Animal Production', 0.1, 0.01, 0.02, 0.0, 0.02), (113, 'Forestry/Logging', 3.7, 0.39, 0.82, 0.01, 0.82), (114, 'Fishing/Hunting', 0.1, 0.01, 0.03, 0.0, 0.03), (115, 'Support Activities', 0.6, 0.07, 0.14, 0.02, 0.13), (211, 'Oil/Gas Extraction', 8.9, 1.32, 2.23, 0.24, 1.98), (212, 'Mining (excl. O&G)', 7.8, 1.12, 1.94, 0.21, 1.74), (221, 'Utilities', 2.5, 0.37, 0.67, 0.12, 0.55), (311, 'Food Mfg', 12.1, 1.25, 2.36, -0.34, 2.7), (312, 'Beverage/Tobacco', 11.6, 1.51, 2.52, -0.06, 2.58), (313, 'Textile Mills', 33.4, 4.58, 6.59, -0.85, 7.44), (314, 'Textile Products', 20.4, 3.43, 4.6, 0.05, 4.55), (316, 'Leather Products', 2.9, 0.83, 1.16, 0.53, 0.63), (321, 'Wood Products', 7.7, 0.82, 1.66, -0.04, 1.7), (322, 'Paper Mfg', 30.6, 3.12, 4.61, -2.21, 6.82), (323, 'Printing', 14.9, 1.44, 2.71, -0.62, 3.33), (324, 'Petroleum/Coal', 51.4, 5.79, 7.14, -4.34, 11.48), (325, 'Chemical Mfg', 37.6, 4.03, 5.55, -2.85, 8.39), (326, 'Plastics/Rubber', 24.3, 2.45, 4.01, -1.41, 5.42), (327, 'Non-Metallic Mineral', 15.2, 1.58, 2.74, -0.64, 3.38), (331, 'Primary Metals', 26.0, 3.56, 5.29, -0.51, 5.8), (332, 'Fabricated Metals', 17.9, 1.82, 3.3, -0.7, 3.99), (333, 'Machinery Mfg', 35.3, 4.23, 5.9, -1.98, 7.88), (334, 'Computer/Electronic', 15.5, 3.44, 4.53, 1.08, 3.45), (335, 'Electrical Equipment', 25.7, 3.56, 5.06, -0.67, 5.73), (336, 'Transportation Equip.', 33.1, 3.45, 4.61, -2.78, 7.38), (337, 'Furniture Mfg', 10.4, 1.19, 2.15, -0.18, 2.33), (339, 'Misc. Manufacturing', 20.6, 2.78, 4.23, -0.36, 4.58), (414, 'Personal/Household Wholesale', 0.05, 0.005, 0.005, 0.0, 0.005), (415, 'Motor Vehicle Wholesale', 9.1, 0.96, 1.9, -0.13, 2.03), (417, 'Machinery/Equipment Wholesale', 0.4, 0.04, 0.08, 0.0, 0.08), (418, 'Building Materials Wholesale', 5.9, 0.64, 1.31, -0.01, 1.32)]
# Table 1: expenditure weight (%) by 2-digit sector
TABLE1_WEIGHTS = {"11": 0.68, "21": 5.91, "22": 0.67, "31": 3.28, "32": 5.54, "33": 10.18, "41": 16.36}
# Table 3: aggregate (exact %, cost %) by tariff rate
TABLE3 = {0.05: (0.20, 0.27), 0.10: (0.36, 0.53), 0.25: (0.66, 1.25), 0.50: (0.88, 2.28)}
# 2-digit market-model sector -> input-output sector used for the rest-of-world / U.S. import ratio
ROW_RATIO_SECTOR = {"11": 0, "21": 1, "22": 2, "31": 4, "32": 4, "33": 4, "41": 4}
# U.S. Census, Profile of U.S. Importing and Exporting Companies 2021-2022, Table 1a (2022 known export value by size, %)
SIZE_CLASSES = [("Unknown employment or 1-19 employees", 12.1 + 5.1), ("20-99 employees", 2.9 + 2.8),
                ("100-249 employees", 6.2), ("250-499 employees", 6.7), ("500 or more employees", 64.3)]
# Goods (1-21) -> market-model industries (NAICS) that produce them
GOOD_TO_INDUSTRIES = {1: [112, 114], 2: [111], 3: [311], 4: [311, 312], 5: [211, 212, 324], 6: [325], 7: [326], 8: [316],
                      9: [113, 321], 10: [322, 323], 11: [313, 314], 12: [316], 13: [327], 14: [331], 15: [331, 332],
                      16: [333, 334, 335], 17: [336], 18: [334, 339], 19: [332], 20: [337, 339], 21: [339]}
RATES = [0.05, 0.10, 0.15, 0.25, 0.50]

# ---------------- Trade classification
def hs_section(hs6: str) -> int:
    """HS section (1-21) of an HS code; 0 for chapters 98-99 (special classifications, not one of the 21 goods)."""
    ch = int(hs6[:2])
    if ch >= 98: return 0
    bounds = [(5, 1), (14, 2), (15, 3), (24, 4), (27, 5), (38, 6), (40, 7), (43, 8), (46, 9), (49, 10), (63, 11),
              (67, 12), (70, 13), (71, 14), (83, 15), (85, 16), (89, 17), (92, 18), (93, 19), (96, 20), (97, 21)]
    for last, sec in bounds:
        if ch <= last: return sec
    return 0

# ---------------- Official counter-tariff packages (Finance Canada; C$)
LISTS = {
    "mar4": dict(name="March 4, 2025: C$30bn list", items=1258, official=30.0e9, flag="Mar4_2025", rate=0.25),
    "steel": dict(name="March 13, 2025: steel", items=None, official=12.6e9, flag="Mar13_steel", rate=0.25),
    "alum": dict(name="March 13, 2025: aluminum", items=None, official=3.0e9, flag="Mar13_aluminum", rate=0.25),
    "other": dict(name="March 13, 2025: other goods", items=None, official=14.2e9, flag="Mar13_other", rate=0.25),
    "veh_pre": dict(name="April 9, 2025: vehicles, pre-Sept 2025", items=None, official=96e9 - 30e9 - 12.6e9 - 3.0e9 - 14.2e9, flag="Vehicles_8703_8704", rate=0.25),
    "veh_post": dict(name="Vehicles, post-Sept 2025", items=None, official=50e9 - 12.6e9 - 3.0e9, flag="Vehicles_8703_8704", rate=0.25),
    "sep2026": dict(name="Sept 8, 2026 round", items=629, official=27.6e9, flag="Sep2026_rate", rate=None),
}
PACKAGES = ["Pre-Sept 2025 package (C$96bn at 25%)", "Post-Sept 2025 package (C$50bn at 25%)",
            "Sept 8, 2026 round (C$27.6bn at 15/25/50%)", "Custom scenario (Scenario sheet)"]
AVG_TARIFF_POINTS = [2.6, 1.0, 0.75, None]   # BoC MPR Oct 2025; Sept 2026: 27.6 x 25 / 923; scenario: computed
TOTAL_IMPORTS_ALL = 923e9   # Canada's total imports used for average-tariff points (C$923bn, as in the CPI workbook)

# ---------------- HS chapters (2-digit), short titles, for the Scenario sheet
HS_CHAPTERS = {
    "01": "Live animals", "02": "Meat and edible meat offal", "03": "Fish and seafood", "04": "Dairy, eggs, honey",
    "05": "Other animal products", "06": "Live plants, cut flowers", "07": "Vegetables", "08": "Fruit and nuts",
    "09": "Coffee, tea, spices", "10": "Cereals", "11": "Milling products, malt, starch", "12": "Oil seeds, misc. grains, seeds",
    "13": "Lac, gums, resins", "14": "Vegetable plaiting materials", "15": "Animal and vegetable fats and oils",
    "16": "Preparations of meat or fish", "17": "Sugars and confectionery", "18": "Cocoa and preparations",
    "19": "Cereal, flour, bakery preparations", "20": "Preparations of vegetables and fruit", "21": "Misc. edible preparations",
    "22": "Beverages, spirits, vinegar", "23": "Food residues, animal feed", "24": "Tobacco", "25": "Salt, sulphur, stone, cement",
    "26": "Ores, slag, ash", "27": "Mineral fuels and oils", "28": "Inorganic chemicals", "29": "Organic chemicals",
    "30": "Pharmaceutical products", "31": "Fertilizers", "32": "Tanning, dyeing extracts, paints", "33": "Essential oils, cosmetics",
    "34": "Soap, waxes, cleaning products", "35": "Albuminoids, glues, enzymes", "36": "Explosives, matches",
    "37": "Photographic goods", "38": "Misc. chemical products", "39": "Plastics", "40": "Rubber",
    "41": "Raw hides and leather", "42": "Leather articles, handbags", "43": "Furskins", "44": "Wood and wood articles",
    "45": "Cork", "46": "Basketware", "47": "Wood pulp", "48": "Paper and paperboard", "49": "Printed matter",
    "50": "Silk", "51": "Wool, animal hair", "52": "Cotton", "53": "Other vegetable textile fibres", "54": "Man-made filaments",
    "55": "Man-made staple fibres", "56": "Wadding, felt, cordage", "57": "Carpets", "58": "Special woven fabrics",
    "59": "Coated textile fabrics", "60": "Knitted fabrics", "61": "Apparel, knitted", "62": "Apparel, not knitted",
    "63": "Other made-up textiles", "64": "Footwear", "65": "Headgear", "66": "Umbrellas, walking sticks",
    "67": "Feathers, artificial flowers", "68": "Stone, plaster, cement articles", "69": "Ceramic products", "70": "Glass and glassware",
    "71": "Precious metals and stones, jewellery", "72": "Iron and steel", "73": "Articles of iron or steel", "74": "Copper",
    "75": "Nickel", "76": "Aluminum", "78": "Lead", "79": "Zinc", "80": "Tin", "81": "Other base metals",
    "82": "Tools, cutlery of base metal", "83": "Misc. articles of base metal", "84": "Machinery, boilers, computers",
    "85": "Electrical machinery and electronics", "86": "Railway equipment", "87": "Vehicles (not railway)",
    "88": "Aircraft and spacecraft", "89": "Ships and boats", "90": "Optical, medical, measuring instruments",
    "91": "Clocks and watches", "92": "Musical instruments", "93": "Arms and ammunition", "94": "Furniture, bedding, lighting",
    "95": "Toys, games, sports equipment", "96": "Misc. manufactured articles", "97": "Works of art, antiques",
}
