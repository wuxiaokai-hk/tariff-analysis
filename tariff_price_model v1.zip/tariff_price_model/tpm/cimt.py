"""Canada's imports from the United States by HS6 product for a chosen period, from the CIMT annual import files.

Each annual zip holds monthly records by HS6, country, province and U.S. state (file ODPFN015_*.csv):
YearMonth, HS6, Country, Province, State, Value (C$), Quantity, Unit of measure.
"""
import csv
import io
import os
import re
import zipfile


def _period(s):
    y, m = s.split("-")
    return int(y) * 100 + int(m)


def _hs6_descriptions(z):
    name = next((n for n in z.namelist() if "HS6MDesc" in n), None)
    out = {}
    if not name:
        return out
    pat = re.compile(r"^(\d{6})\s+(\d{6}) (\d{6}) \S*\s+(.*?)(\s{2,}|$)")
    for line in z.read(name).decode("latin-1").splitlines():
        m = pat.match(line)
        if m:
            out[m.group(1)] = (int(m.group(2)), int(m.group(3)), m.group(4).strip())
    return out


def sum_us_imports(zip_paths, start, end):
    """Sum imports from the U.S. (C$) by HS6 over months start..end ('YYYY-MM'). Returns (values, descriptions, months)."""
    a, b = _period(start), _period(end)
    vals, desc, months = {}, {}, set()
    for path in zip_paths:
        with zipfile.ZipFile(path) as z:
            name = next(n for n in z.namelist() if re.search(r"ODPFN015_.*\.csv$", n))
            for code, (s, e, d) in _hs6_descriptions(z).items():
                if s <= b and e >= a:
                    desc[code] = d
            with z.open(name) as f:
                rd = csv.reader(io.TextIOWrapper(f, encoding="utf-8-sig", errors="replace", newline=""))
                next(rd)
                for r in rd:
                    ym = int(r[0])
                    if ym < a or ym > b or r[2] != "US":
                        continue
                    months.add(ym)
                    vals[r[1]] = vals.get(r[1], 0.0) + float(r[5] or 0)
    return vals, desc, sorted(months)


def load(start, end, cache_dir, processed_dir, refresh=False):
    """Rows (HS6, description, value) of imports from the U.S. for start..end, cached in data/processed."""
    out = os.path.join(processed_dir, f"us_imports_{start}_{end}.csv")
    if os.path.exists(out) and not refresh:
        rows = list(csv.DictReader(open(out, encoding="utf-8")))
        return [(r["HS6"], r["Description"], float(r["US_imports_CAD"])) for r in rows], None
    from .download import cimt_zip
    years = range(int(start[:4]), int(end[:4]) + 1)
    paths = [cimt_zip(y, cache_dir, refresh=refresh) for y in years]
    print(f"Summing imports from the U.S. by HS6, {start} to {end} ...")
    vals, desc, months = sum_us_imports(paths, start, end)
    want = (int(end[:4]) - int(start[:4])) * 12 + int(end[5:]) - int(start[5:]) + 1
    if len(months) < want:
        have = f"{str(months[0])[:4]}-{str(months[0])[4:]} to {str(months[-1])[:4]}-{str(months[-1])[4:]}" if months else "none"
        print(f"  WARNING: only {len(months)} of {want} months are published (have {have}). Results use the months available.")
    rows = sorted((h, desc.get(h, ""), v) for h, v in vals.items())
    os.makedirs(processed_dir, exist_ok=True)
    with open(out, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["HS6", "Description", "US_imports_CAD"])
        for h, d, v in rows:
            w.writerow([h, d, round(v)])
    return rows, months
