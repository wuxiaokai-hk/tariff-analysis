"""Industry-level input-output sheets: every sector and goods total on StatCan_IO / StatCan_Goods becomes a formula.

IO_Map        NAICS (2-digit) -> sector, and industry-code prefix -> good (the mappings in static.py)
IO_Industries one row per input-output industry: Total use, household spending (each PEC column), imports by origin,
              then formulas: sector, good, household total, total imports, U.S. imports, household U.S. purchases
IO_Z          industry x industry intermediate use (C$ thousands), with each row's and column's sector
"""
from openpyxl.utils import get_column_letter as CL

from . import static


def add_io_detail(wb, D, put, hdr, note, W, fonts):
    det = D.get("detail")
    if not det:
        return False
    BLUE, BLACK, GREEN, BOLD, TITLE, H2 = fonts
    inds, names, pec, rows = det["inds"], det["names"], det["pec"], det["rows"]
    n = len(inds); R0 = 5; R1 = R0 + n - 1; npec = len(pec)

    # ---------------- IO_Map
    mp = wb.create_sheet("IO_Map"); mp["A1"] = "Mappings used to aggregate the input-output industries"; mp["A1"].font = TITLE
    note(mp, "A2", "Sector: first two NAICS digits of the industry code after BS/NP/GS (NP999999 -> Other services). "
                   "Good: longest matching prefix of a BS industry code (table sorted by prefix length; LOOKUP takes the last, i.e. longest, match).")
    hdr(mp, 4, ["NAICS (2-digit)", "Sector #", "Sector"])
    pairs = sorted(static.NAICS2_TO_SECTOR.items())
    for k, (code, idx) in enumerate(pairs):
        r = 5 + k
        put(mp, f"A{r}", code, BLUE); put(mp, f"B{r}", idx + 1, BLUE, "0"); put(mp, f"C{r}", static.SECTORS[idx])
    MAPS = f"IO_Map!$A$5:$B${4 + len(pairs)}"
    hdr(mp, 4, ["Industry-code prefix", "Length", "Good #", "Good"], col=5)
    pref = sorted(((p, g) for g, ps in static.IO_INDUSTRY_TO_GOOD for p in ps), key=lambda t: (len(t[0]), t[0]))
    for k, (p, g) in enumerate(pref):
        r = 5 + k
        put(mp, f"E{r}", p, BLUE); put(mp, f"F{r}", f"=LEN(E{r})", BLACK, "0"); put(mp, f"G{r}", g, BLUE, "0"); put(mp, f"H{r}", static.GOODS[g - 1])
    pe = 4 + len(pref)
    PREF, PLEN, PGOOD = f"IO_Map!$E$5:$E${pe}", f"IO_Map!$F$5:$F${pe}", f"IO_Map!$G$5:$G${pe}"
    hdr(mp, 4, ["Goods sectors (U.S. imports counted)"], col=10)
    for k, s in enumerate(static.GOODS_SECTORS):
        put(mp, f"J{5 + k}", s + 1, BLUE, "0")
    GS = f"IO_Map!$J$5:$J${4 + len(static.GOODS_SECTORS)}"
    W(mp, {"A": 12, "B": 9, "C": 34, "E": 14, "F": 8, "G": 8, "H": 30, "J": 14})

    # ---------------- IO_Industries
    ii = wb.create_sheet("IO_Industries")
    ii["A1"] = f"Input-output industries, Statistics Canada Table 36-10-0001-01, {D['year']}, basic prices (C$ thousands)"; ii["A1"].font = TITLE
    note(ii, "A2", "Blue = values from the table (imports are negative in the table, as a use of supply). Sector and good are formulas on IO_Map. "
                   "StatCan_IO columns C-F and StatCan_Goods columns C-D are SUMIFS on this sheet.")
    c_tot = 6; c_pec0 = 7; c_imp0 = c_pec0 + npec
    c_h, c_m, c_mus, c_gs, c_musc, c_hus = (c_imp0 + 4 + k for k in range(6))
    L = lambda c: CL(c)
    labels = (["Code", "Industry", "NAICS 2", "Sector #", "Good #", "Total use (output)"]
              + [f"{nm} [{p}]" for nm, p in zip(det["pec_names"], pec)]
              + ["Imports from U.S. [INTIMUS]", "Imports [INTIMCN]", "Imports [INTIMMX]", "Imports from rest of world [INTIMRW]",
                 "Household consumption = SUM PEC", "Total imports = -(SUM INTIM)", "Imports from U.S. = -INTIMUS",
                 "Goods sector?", "U.S. imports counted (goods sectors)", "Household purchases of U.S. imports = H x MUS / (X + M)"])
    hdr(ii, 4, labels, h=90)
    for k, code in enumerate(inds):
        r = R0 + k; v = rows[k]
        put(ii, f"A{r}", code, BLUE); put(ii, f"B{r}", names[k], BLUE)
        put(ii, f"C{r}", f"=MID(A{r},3,2)", BLACK)
        put(ii, f"D{r}", f'=IF(A{r}="NP999999",19,VLOOKUP(C{r},{MAPS},2,FALSE))', BLACK, "0")
        put(ii, f"E{r}", f'=IF(LEFT(A{r},2)<>"BS",0,IFERROR(LOOKUP(2,1/(LEFT(MID(A{r},3,10),{PLEN})={PREF}),{PGOOD}),0))', BLACK, "0")
        put(ii, f"{L(c_tot)}{r}", v[0], BLUE, "#,##0")
        for p in range(npec):
            put(ii, f"{L(c_pec0 + p)}{r}", v[1 + p], BLUE, "#,##0")
        for q in range(4):
            put(ii, f"{L(c_imp0 + q)}{r}", v[1 + npec + q], BLUE, "#,##0")
        put(ii, f"{L(c_h)}{r}", f"=SUM({L(c_pec0)}{r}:{L(c_imp0 - 1)}{r})", BLACK, "#,##0")
        put(ii, f"{L(c_m)}{r}", f"=-SUM({L(c_imp0)}{r}:{L(c_imp0 + 3)}{r})", BLACK, "#,##0")
        put(ii, f"{L(c_mus)}{r}", f"=-{L(c_imp0)}{r}", BLACK, "#,##0")
        put(ii, f"{L(c_gs)}{r}", f"=IF(COUNTIF({GS},D{r})>0,1,0)", BLACK, "0")
        put(ii, f"{L(c_musc)}{r}", f"={L(c_mus)}{r}*{L(c_gs)}{r}", BLACK, "#,##0")
        put(ii, f"{L(c_hus)}{r}", f"=IF({L(c_tot)}{r}+{L(c_m)}{r}=0,0,{L(c_h)}{r}*{L(c_mus)}{r}/({L(c_tot)}{r}+{L(c_m)}{r}))", BLACK, "#,##0")
    put(ii, f"B{R1 + 1}", "Total", BOLD)
    for c in [c_tot, c_h, c_m, c_mus, c_musc, c_hus]:
        put(ii, f"{L(c)}{R1 + 1}", f"=SUM({L(c)}{R0}:{L(c)}{R1})", BOLD, "#,##0")
    ii.freeze_panes = "C5"; ii.auto_filter.ref = f"A4:{L(c_hus)}{R1}"
    W(ii, {"A": 11, "B": 46, "C": 8, "D": 8, "E": 8, **{L(c): 14 for c in range(c_tot, c_hus + 1)}})
    rng = lambda c: f"IO_Industries!${L(c)}${R0}:${L(c)}${R1}"
    SEC, GOOD = rng(4), rng(5)

    # ---------------- IO_Z
    z = wb.create_sheet("IO_Z")
    z["A1"] = f"Intermediate use by industry, Statistics Canada Table 36-10-0001-01, {D['year']} (rows = supplying industry, columns = using industry, C$ thousands)"
    z["A1"].font = TITLE
    note(z, "A2", "Row 3: sector # of each using industry. StatCan_IO rows 30-49: SUMPRODUCT over this block by supplying and using sector.")
    put(z, "B3", "Sector #", BOLD); put(z, "A4", "Code", BOLD); put(z, "B4", "Sector #", BOLD)
    for k, code in enumerate(inds):
        cc = L(3 + k)
        put(z, f"{cc}4", code, BOLD); put(z, f"{cc}3", f"=INDEX({SEC},{k + 1})", GREEN, "0")
    for a, code in enumerate(inds):
        r = R0 + a
        z.cell(row=r, column=1, value=code).font = BLUE
        z.cell(row=r, column=2, value=f"=IO_Industries!D{r}").font = GREEN
        for b, v in enumerate(det["Z"][a]):
            if v:
                c = z.cell(row=r, column=3 + b, value=v); c.font = BLUE; c.number_format = "#,##0"
    zl = L(2 + n)
    ZROW, ZCOL, ZDAT = f"IO_Z!$B${R0}:$B${R1}", f"IO_Z!$C$3:${zl}$3", f"IO_Z!$C${R0}:${zl}${R1}"
    z.freeze_panes = "C5"; W(z, {"A": 11, "B": 9})

    # ---------------- StatCan_IO / StatCan_Goods as formulas
    sc = wb["StatCan_IO"]
    for i in range(20):
        r = 5 + i; s = i + 1
        put(sc, f"C{r}", f"=SUMIFS({rng(c_tot)},{SEC},{s})", GREEN, "#,##0")
        put(sc, f"D{r}", f"=SUMIFS({rng(c_h)},{SEC},{s})", GREEN, "#,##0")
        put(sc, f"E{r}", f"=SUMIFS({rng(c_m)},{SEC},{s})", GREEN, "#,##0")
        put(sc, f"F{r}", f"=SUMIFS({rng(c_musc)},{SEC},{s})", GREEN, "#,##0")
        for j in range(20):
            put(sc, f"{L(3 + j)}{30 + i}", f"=SUMPRODUCT(({ZROW}={s})*({ZCOL}={j + 1})*{ZDAT})", GREEN, "#,##0")
    sc["A2"] = (f"Source: Input-output tables, detail level (R2). Columns C-F and the Z table are formulas on IO_Industries and IO_Z "
                f"({n} industries, mapped to sectors on IO_Map). U.S. imports: goods sectors only (NAICS 11, 21, 22, 31-33), as R1 Table 1 covers goods.")
    sg = wb["StatCan_Goods"]
    for j in range(21):
        r = 5 + j
        put(sg, f"C{r}", f"=SUMIFS({rng(c_mus)},{GOOD},{j + 1})", GREEN, "#,##0")
        put(sg, f"D{r}", f"=SUMIFS({rng(c_hus)},{GOOD},{j + 1})", GREEN, "#,##0")
    put(sg, "B28", f"=SUM({rng(c_h)})", GREEN, "#,##0")
    sg["A2"] = "Formulas on IO_Industries: each industry's good comes from IO_Map. Sections 3, 8, 12, 14, 18, 19, 21 are not separable in the input-output table and are zero."

    # reconciliation with the Python aggregation
    rc = R1 + 4
    ii[f"A{rc}"] = "Check against the Python aggregation (statcan_io.py)"; ii[f"A{rc}"].font = H2
    hdr(ii, rc + 1, ["Item", "", "Python", "Workbook", "Difference"])
    items = [("Output, all sectors", sum(D["X"]), "=StatCan_IO!C25"), ("Household consumption", D["Htot"], "=StatCan_Goods!B28"),
             ("Total imports", sum(D["M"]), "=StatCan_IO!E25"), ("U.S. imports, goods sectors", sum(D["MUS"]), "=StatCan_IO!F25"),
             ("Intermediate use, all", sum(map(sum, D["Z"])), "=SUM(StatCan_IO!C30:V49)"),
             ("Household U.S. purchases, by good", sum(D["HUS_g"]), "=StatCan_Goods!D26")]
    for k, (lab, py, f) in enumerate(items):
        r = rc + 2 + k
        put(ii, f"A{r}", lab); put(ii, f"C{r}", py, BLUE, "#,##0"); put(ii, f"D{r}", f, GREEN, "#,##0"); put(ii, f"E{r}", f"=D{r}-C{r}", BLACK, "#,##0.00")
    return True
