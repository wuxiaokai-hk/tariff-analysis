"""Aggregate Statistics Canada Table 36-10-0001-01 (input-output, detail level, industry by industry)
to the 20 sectors and 21 goods of BoC SWP 2026-35.

Output (C$ thousands, basic prices), one dict per year:
  X      output of each sector (row "Total use")
  H      household final consumption of each sector's output (columns PEC*)
  M      total imports of each sector's products (columns INTIM*, sign reversed)
  MUS    imports from the United States (column INTIMUS, sign reversed)
  Z      20 x 20 intermediate use (rows = supplying sector, columns = using sector)
  Htot   total household consumption (PEC* over all industry rows)
  MUS_g  U.S. imports by good (21 goods; goods-producing industries only)
  HUS_g  household purchases of U.S. imports by good = SUM over industries H x MUS / (X + M) (proportionality)
"""
import csv
import io
import json
import os
import re
import zipfile

from . import static

CODE = re.compile(r"\[([^\]]+)\]\s*$")


def _code(label):
    m = CODE.search(label)
    return m.group(1) if m else label


def _sector(code):
    if code in static.SPECIAL_SECTOR:
        return static.SPECIAL_SECTOR[code]
    if code[:2] in ("BS", "NP", "GS"):
        return static.NAICS2_TO_SECTOR.get(code[2:4])
    return None


def _good(code):
    if code[:2] != "BS":
        return None
    d = code[2:]
    best = None
    for g, prefixes in static.IO_INDUSTRY_TO_GOOD:
        for p in prefixes:
            if d.startswith(p) and (best is None or len(p) > best[1]):
                best = (g, len(p))
    return best[0] if best else None


def available_years(zip_path):
    years = set()
    for row in _rows(zip_path):
        years.add(row[0])
    return sorted(years)


def _rows(zip_path):
    with zipfile.ZipFile(zip_path) as z:
        name = next(n for n in z.namelist() if n.endswith(".csv") and "MetaData" not in n)
        with z.open(name) as f:
            rd = csv.reader(io.TextIOWrapper(f, encoding="utf-8-sig", newline=""))
            header = next(rd)
            ix = {h: i for i, h in enumerate(header)}
            iy, iv, isu, ius, ival = ix["REF_DATE"], ix["Valuation"], ix["Supply"], ix["Use"], ix["VALUE"]
            for r in rd:
                yield r[iy], r[iv], r[isu], r[ius], r[ival]


def aggregate_rows(rows, year, valuation="Basic price"):
    """rows: iterable of (REF_DATE, Valuation, Supply, Use, VALUE). Returns the aggregated dict."""
    year = str(year)
    cells = {}; labels = {}
    for y, val, sup, use, v in rows:
        if y != year or val != valuation:
            continue
        try:
            x = float(v)
        except ValueError:
            continue
        cs, cu = _code(sup), _code(use)
        cells.setdefault(cs, {})[cu] = x
        labels.setdefault(cs, sup); labels.setdefault(cu, use)
    if not cells:
        raise ValueError(f"No {valuation} data for {year} in the input-output file.")
    return aggregate_cells(cells, labels, year, "Statistics Canada Table 36-10-0001-01, " + valuation.lower() + "s")


def aggregate_cells(cells, labels, year, source):
    """cells: {supply code: {use code: value}} -> sector and good aggregates (and industry detail)."""
    NS, NG = 20, 21
    X = [0.0] * NS; H = [0.0] * NS; M = [0.0] * NS; MUS = [0.0] * NS
    Z = [[0.0] * NS for _ in range(NS)]
    MUS_g = [0.0] * NG; HUS_g = [0.0] * NG; Htot = 0.0
    imp_cols = ("INTIMUS", "INTIMCN", "INTIMMX", "INTIMRW")
    for sup, row in cells.items():
        i = _sector(sup)
        if i is None:
            continue
        x = row.get("Total use", 0.0)
        h = sum(v for c, v in row.items() if c.startswith("PEC"))
        mus = -row.get("INTIMUS", 0.0)
        m = -sum(row.get(c, 0.0) for c in imp_cols)
        X[i] += x; H[i] += h; M[i] += m; Htot += h
        if i in static.GOODS_SECTORS:
            MUS[i] += mus
        for c, v in row.items():
            j = _sector(c)
            if j is not None:
                Z[i][j] += v
        g = _good(sup)
        if g is not None:
            MUS_g[g - 1] += mus
            if x + m:
                HUS_g[g - 1] += h * mus / (x + m)
    return dict(year=int(year), source=source,
                X=X, H=H, M=M, MUS=MUS, Z=Z, Htot=Htot, MUS_g=MUS_g, HUS_g=HUS_g, detail=_detail(cells, labels))


def _detail(cells, labels):
    """Industry-level data, so the workbook can rebuild every aggregate with formulas.

    inds: industries (BS/NP/GS codes) in table order; pec: household-spending columns (PEC*);
    rows: per industry [Total use, PEC values..., INTIMUS, INTIMCN, INTIMMX, INTIMRW];
    Z: industry x industry intermediate use (rows = supplying, columns = using).
    """
    inds = []
    for c in list(cells) + [u for r in cells.values() for u in r]:
        if _sector(c) is not None and c not in inds:
            inds.append(c)
    pec = sorted({u for c in inds for u in cells.get(c, {}) if u.startswith("PEC")})
    imp = ["INTIMUS", "INTIMCN", "INTIMMX", "INTIMRW"]
    rows = [[cells.get(c, {}).get("Total use", 0.0)] + [cells.get(c, {}).get(p, 0.0) for p in pec]
            + [cells.get(c, {}).get(k, 0.0) for k in imp] for c in inds]
    Z = [[cells.get(a, {}).get(b, 0.0) for b in inds] for a in inds]
    strip = lambda s: CODE.sub("", labels.get(s, s)).strip()
    return dict(inds=inds, names=[strip(c) for c in inds], pec=pec, pec_names=[strip(p) for p in pec],
                imports=imp, rows=rows, Z=Z)


def load(year, cache_dir, processed_dir, refresh=False, need_detail=True):
    """Aggregated input-output data for `year` (cached as data/processed/io_<year>.json).

    With need_detail, a cached file without the industry-level detail is rebuilt from the Statistics Canada table
    (downloading it if needed); if that fails, the cached aggregates are used and the workbook shows them as values.
    """
    out = os.path.join(processed_dir, f"io_{year}.json")
    if os.path.exists(out) and not refresh:
        d = json.load(open(out))
        if "detail" in d or not need_detail:
            return d
        try:
            return _build(year, cache_dir, processed_dir, False, out)
        except Exception as e:
            print(f"  Could not add industry detail ({e}); using the cached sector totals.")
            return d
    return _build(year, cache_dir, processed_dir, refresh, out)


def _build(year, cache_dir, processed_dir, refresh, out):
    from .download import io_zip
    path = io_zip(cache_dir, refresh=refresh)
    print(f"Aggregating input-output table for {year} ...")
    d = aggregate_rows(_rows(path), year)
    os.makedirs(processed_dir, exist_ok=True)
    json.dump(d, open(out, "w"))
    return d
