"""The two models in numpy (the Excel workbook repeats the same calculations as live formulas).

Market model (BoC SWP 2026-36): dampening ratio = exact price change / full cost, by industry and tariff rate.
Network model (BoC SWP 2026-35): dp = (I - A_CA W_CA)^-1 A_US W_US (R x dtau); dP = gamma' dp (+ consumer channel).
"""
import csv
import math

import numpy as np

from . import static

NS, NG = 20, 21
ITERS, DAMP = 50, 0.5       # same as the Excel solver sheets


# ============================================================ tariffs
def read_lists(path):
    out = {}
    for r in csv.DictReader(open(path, encoding="utf-8")):
        out[r["HS6"]] = r
    return out


def trade_table(rows, lists):
    """One record per HS6 with list flags and the Sept 2026 increase."""
    T = []
    for hs, desc, val in rows:
        L = lists.get(hs, {})
        f = lambda k: int(L.get(k) or 0)
        rate = L.get("Sep2026_rate") or ""
        steel_al = f("Mar13_steel") or f("Mar13_aluminum")
        inc = 0 if rate == "" else (max(0, int(rate) - 25) if steel_al else int(rate))
        cls = "" if inc == 0 else ("25to50" if steel_al else str(int(rate)))
        T.append(dict(hs6=hs, chapter=hs[:2], desc=desc or L.get("Description", ""), section=static.hs_section(hs), value=float(val),
                      mar4=f("Mar4_2025"), steel=f("Mar13_steel"), alum=f("Mar13_aluminum"), other=f("Mar13_other"),
                      veh=f("Vehicles_8703_8704"), sep_rate=(int(rate) if rate else None), sep_inc=inc, sep_class=cls))
    return T


def read_scenario(hs2_path, hs6_path=None):
    """Custom scenario: rate and coverage (%) by HS chapter, plus optional HS6 overrides (%)."""
    hs2 = {}
    for r in csv.DictReader(open(hs2_path, encoding="utf-8")):
        hs2[r["chapter"].zfill(2)] = (float(r.get("rate_pct") or 0), float(r.get("coverage_pct") or 100))
    hs6 = {}
    if hs6_path:
        for r in csv.DictReader(open(hs6_path, encoding="utf-8")):
            if r.get("hs6") and r.get("rate_pct") not in (None, ""):
                hs6[r["hs6"].zfill(6)] = float(r["rate_pct"])
    return dict(hs2=hs2, hs6=hs6, uniform=None)


def scenario_rate(rec, scen):
    """Tariff rate (fraction) the scenario puts on one HS6 product: HS6 override, else uniform or chapter rate x coverage."""
    if not scen or rec["section"] == 0:
        return 0.0
    if rec["hs6"] in scen["hs6"]:
        return scen["hs6"][rec["hs6"]] / 100
    rate, cov = scen["hs2"].get(rec["chapter"], (0.0, 100.0))
    if scen.get("uniform") is not None:
        rate = scen["uniform"]
    return rate * cov / 1e4


def effective_tariffs(T, scen=None):
    """Effective tariff change by good for the four packages, plus list matching details."""
    tot = lambda key: sum(r["value"] for r in T if r[key] == 1)
    matched = {k: tot(k) for k in ("mar4", "steel", "alum", "other", "veh")}
    sep_matched = sum(r["value"] for r in T if r["sep_rate"] is not None)
    L = static.LISTS
    scale = {"mar4": min(1, L["mar4"]["official"] / matched["mar4"]), "steel": min(1, L["steel"]["official"] / matched["steel"]),
             "alum": min(1, L["alum"]["official"] / matched["alum"]), "other": min(1, L["other"]["official"] / matched["other"]),
             "veh_pre": min(1, L["veh_pre"]["official"] / matched["veh"]), "veh_post": min(1, L["veh_post"]["official"] / matched["veh"]),
             "sep2026": min(1, L["sep2026"]["official"] / sep_matched)}
    C = np.zeros(NG); D = np.zeros(NG); E = np.zeros(NG); F = np.zeros(NG)
    cls = {k: np.zeros(NG) for k in ("15", "25", "50", "25to50")}
    for r in T:
        g = r["section"]
        if g == 0:
            continue
        v = r["value"]; j = g - 1
        C[j] += v
        D[j] += v * (r["mar4"] * scale["mar4"] + r["steel"] * scale["steel"] + r["alum"] * scale["alum"]
                     + r["other"] * scale["other"] + r["veh"] * scale["veh_pre"])
        E[j] += v * (r["steel"] * scale["steel"] + r["alum"] * scale["alum"] + r["veh"] * scale["veh_post"])
        F[j] += v * r["sep_inc"] / 100 * scale["sep2026"]
        if r["sep_class"]:
            cls[r["sep_class"]][j] += v * r["sep_inc"] / 100
    with np.errstate(divide="ignore", invalid="ignore"):
        tau = np.zeros((NG, 4))
        tau[:, 0] = np.where(C > 0, 0.25 * D / C, 0)
        tau[:, 1] = np.where(C > 0, 0.25 * E / C, 0)
        tau[:, 2] = np.where(C > 0, F / C, 0)
    S = np.zeros(NG)
    for r in T:
        r["scen_rate"] = scenario_rate(r, scen)
        if r["section"]:
            S[r["section"] - 1] += r["value"] * r["scen_rate"]
    tau[:, 3] = np.where(C > 0, S / np.where(C > 0, C, 1), 0)
    return dict(C=C, D=D, E=E, F=F, tau=tau, scale=scale, matched=matched, sep_matched=sep_matched, sep_class=cls,
                special=sum(r["value"] for r in T if r["section"] == 0))


# ============================================================ market model (SWP 2026-36)
def mu(w):
    return 1 / (1 - (w / static.RHO + (1 - w) / static.SIGMA))


def size_shares():
    q = np.array([v for _, v in static.SIZE_CLASSES]); return q / q.sum()


def row_ratios(io):
    M, MUS = np.array(io["M"], float), np.array(io["MUS"], float)
    return {k: (M[i] - MUS[i]) / MUS[i] for k, i in static.ROW_RATIO_SECTOR.items()}


def industry_firms(us_share, rr, N):
    """11 firm types: 5 U.S., 5 rest-of-world (size classes), 1 Canadian type with N identical firms."""
    q = size_shares(); u = us_share / 100
    row = min(rr * u, 0.9 * (1 - u)); ca = 1 - u - row
    n = np.r_[np.ones(10), N]
    w0 = np.r_[u * q, row * q, ca / N]
    us = np.r_[np.ones(5), np.zeros(6)].astype(bool)
    return n, w0, us


def solve(n, w0, us, tau, iters=ITERS, damp=DAMP):
    S = static.SIGMA
    p0 = w0 ** (1 / (1 - S)); c = p0 / mu(w0); c1 = c * np.where(us, 1 + tau, 1)
    w = w0.copy(); prev = w
    for _ in range(iters):
        prev = w
        x = (mu(w) * c1) ** (1 - S)
        w = (1 - damp) * w + damp * x / (n * x).sum()
    p = mu(w) * c1
    exact = math.log(((n * p ** (1 - S)).sum()) ** (1 / (1 - S))) * 100
    cost = (n * w0 * np.where(us, math.log(1 + tau), 0)).sum() * 100
    mk = (n * w0 * (np.log(mu(w)) - np.log(mu(w0)))).sum() * 100
    conv = max(abs(w[0] - prev[0]), abs(w[4] - prev[4]), abs(w[-1] - prev[-1]))
    return exact, cost, mk, conv, w


def run_market(rr, N, rates=static.RATES):
    out = {}
    for t in rates:
        rows = []
        for (naics, name, us, *_rest) in static.TABLE_F1:
            n, w0, usf = industry_firms(us, rr[str(naics)[:2]], N)
            e, c, m, cv, _ = solve(n, w0, usf, t)
            rows.append((e, c, m, cv))
        out[t] = np.array(rows)        # columns: exact, cost, markup, convergence
    return out


def sse_25(rr, N):
    paper = np.array([f[3] for f in static.TABLE_F1])
    e = run_market(rr, N, [0.25])[0.25][:, 0]
    return float(((e - paper) ** 2).sum())


def calibrate_N(rr, lo=2.0, hi=60.0, tol=1e-4):
    """Golden-section search on log N for the N that best matches Table F.1 at 25%."""
    a, b = math.log(lo), math.log(hi); g = (math.sqrt(5) - 1) / 2
    c, d = b - g * (b - a), a + g * (b - a)
    fc, fd = sse_25(rr, math.exp(c)), sse_25(rr, math.exp(d))
    while b - a > tol:
        if fc < fd:
            b, d, fd = d, c, fc; c = b - g * (b - a); fc = sse_25(rr, math.exp(c))
        else:
            a, c, fc = c, d, fd; d = a + g * (b - a); fd = sse_25(rr, math.exp(d))
    return math.exp((a + b) / 2)


def goods_ratios(mk):
    """Ratio by good (21) and rate, plus the 25%-to-50% increment ratio."""
    idx = {f[0]: i for i, f in enumerate(static.TABLE_F1)}
    R = np.zeros((NG, len(static.RATES) + 1))
    for g in range(1, NG + 1):
        ii = [idx[n] for n in static.GOOD_TO_INDUSTRIES[g]]
        for k, t in enumerate(static.RATES):
            R[g - 1, k] = mk[t][ii, 0].sum() / mk[t][ii, 1].sum()
        R[g - 1, -1] = (mk[0.5][ii, 0].sum() - mk[0.25][ii, 0].sum()) / (mk[0.5][ii, 1].sum() - mk[0.25][ii, 1].sum())
    return R


def interp_ratio(R, g, rate):
    """Dampening ratio of good g (1-21) at any tariff rate: linear between 5, 10, 15, 25, 50%; flat outside."""
    return float(np.interp(rate, static.RATES, R[g - 1, :len(static.RATES)]))


def package_ratios(R, tar, T=None):
    """Dampening ratio by good for each package (columns as tau)."""
    k = {t: i for i, t in enumerate(static.RATES)}
    P = np.zeros((NG, 4))
    P[:, 0] = P[:, 1] = P[:, 3] = R[:, k[0.25]]
    cl = tar["sep_class"]
    w = cl["15"] + cl["25"] + cl["50"] + cl["25to50"]
    num = cl["15"] * R[:, k[0.15]] + cl["25"] * R[:, k[0.25]] + cl["50"] * R[:, k[0.5]] + cl["25to50"] * R[:, -1]
    P[:, 2] = np.where(w > 0, num / np.where(w > 0, w, 1), R[:, k[0.25]])
    if T is not None:            # custom scenario: each product's ratio at its own rate
        full = np.zeros(NG); damp = np.zeros(NG)
        for r in T:
            if r["section"] and r.get("scen_rate", 0) > 0:
                x = r["value"] * r["scen_rate"]
                full[r["section"] - 1] += x; damp[r["section"] - 1] += x * interp_ratio(R, r["section"], r["scen_rate"])
        P[:, 3] = np.where(full > 0, damp / np.where(full > 0, full, 1), R[:, k[0.25]])
    return P


def validation(mk):
    """Aggregate results vs Table 3 (Table 1 weights split equally across 3-digit industries)."""
    two = [str(f[0])[:2] for f in static.TABLE_F1]
    cnt = {k: two.count(k) for k in static.TABLE1_WEIGHTS}
    wt = np.array([static.TABLE1_WEIGHTS[k] / cnt[k] for k in two]) / 100
    out = []
    for t, (pe, pc) in static.TABLE3.items():
        e, c = (wt * mk[t][:, 0]).sum(), (wt * mk[t][:, 1]).sum()
        out.append(dict(rate=t, exact=e, cost=c, ratio=e / c, paper_exact=pe, paper_cost=pc, paper_ratio=pe / pc))
    paper = np.array([f[3] for f in static.TABLE_F1])
    corr = float(np.corrcoef(mk[0.25][:, 0], paper)[0, 1])
    return out, corr


# ============================================================ network model (SWP 2026-35)
def omega_us_proportional(io):
    """Omega_US from the public table: each buyer's purchases of a good x that good's U.S. import share."""
    det = io.get("detail")
    if not det:
        raise ValueError("omega_us 'io' needs the industry detail of the input-output table")
    from .statcan_io import _good, _sector
    rows = np.array(det["rows"], float); Z = np.array(det["Z"], float); npec = len(det["pec"])
    X = rows[:, 0]; mus = -rows[:, 1 + npec]; m = -rows[:, 1 + npec:5 + npec].sum(1)
    ush = np.where(X + m > 0, mus / np.where(X + m > 0, X + m, 1), 0)
    W = np.zeros((NS, 21))
    for a, ca in enumerate(det["inds"]):
        g = _good(ca)
        if not g:
            continue
        for b, cb in enumerate(det["inds"]):
            if Z[a, b]:
                W[_sector(cb), g - 1] += Z[a, b] * ush[a]
    return W / np.where(W.sum(1, keepdims=True) > 0, W.sum(1, keepdims=True), 1)


def network_params(io, denominator="Intermediate inputs", omega_ca="paper", shares="proportional", omega_us="paper"):
    """aCA, aUS, gamma, domestic consumption weight, consumer channel, Omega_CA and Omega_US.

    shares = "proportional": domestic / U.S. parts of each sector's inputs and of household spending estimated from the
             public table by import proportionality (each user gets the product's economy-wide import share).
    shares = "iot":          taken directly from the Domestic and Import-from-US tables of the IOT workbook.
    omega_ca / omega_us = "paper" (BoC SWP 2026-35 Tables A1 / 1), "io" (public table, proportionality) or "iot".
    """
    X, H, M, MUS = (np.array(io[k], float) for k in ("X", "H", "M", "MUS"))
    Z = np.array(io["Z"], float)
    tot = Z.sum(0)
    den = X if denominator == "Total cost" else tot
    den = np.where(den > 0, den, 1)          # a sector with no data (e.g. a partial table) gets zero shares
    iot = io.get("iot") or {}
    need = lambda k: iot.get(k) if iot.get(k) is not None else (_ for _ in ()).throw(
        ValueError(f"'{k}' is not in the IOT data: the workbook needs a {'Domestic' if k in ('Zd', 'Hd') else 'Import from US'} table"))
    if shares == "iot":
        Zd, Hd = np.array(need("Zd")), np.array(need("Hd")); Zus_g, Hus_g = np.array(need("Zus_g")), np.array(need("HUS_g"))
        aCA, aUS = Zd.sum(0) / den, Zus_g.sum(0) / den
        gamma = Hd / Hd.sum(); w_dom = Hd.sum() / io["Htot"]; c_g = Hus_g / io["Htot"]
    else:
        d_ = np.where(X + M > 0, X + M, 1); m = np.where(X + M > 0, M / d_, 0); us = np.where(X + M > 0, MUS / d_, 0)
        aCA, aUS = (Z * (1 - m)[:, None]).sum(0) / den, (Z * us[:, None]).sum(0) / den
        Q = H * (1 - m); gamma = Q / Q.sum(); w_dom = Q.sum() / io["Htot"]
        c_g = np.array(io["HUS_g"], float) / io["Htot"]
    rs = lambda W: W / np.where(W.sum(1, keepdims=True) > 0, W.sum(1, keepdims=True), 1)
    if omega_ca == "iot":
        W_CA = rs(np.array(need("Zd")).T)
    elif omega_ca == "io":
        W_CA = rs(Z.T)
    else:
        W_CA = np.array(static.OMEGA_CA)
    if omega_us == "iot":
        W = np.array(need("Zus_g")).T; W_US = W / np.where(W.sum(1, keepdims=True) > 0, W.sum(1, keepdims=True), 1)
    elif omega_us == "io":
        W_US = omega_us_proportional(io)
    else:
        W_US = np.array(static.OMEGA_US)
    return dict(aCA=aCA, aUS=aUS, gamma=gamma, w_dom=w_dom, c_g=c_g, W_CA=W_CA, W_US=W_US)


def network(par, tau, consumer=True):
    L = np.linalg.inv(np.eye(NS) - par["aCA"][:, None] * par["W_CA"])
    d = par["aUS"][:, None] * (par["W_US"] @ tau)
    p = L @ d
    w = par["w_dom"] if consumer else 1.0
    cons = par["c_g"] @ tau if consumer else np.zeros(tau.shape[1])
    direct = (w * par["gamma"] @ d + cons) * 100
    total = (w * par["gamma"] @ p + cons) * 100
    return dict(direct=direct, total=total, d=d, p=p, L=L)


def run(io, rows, lists_path, settings):
    """Everything the workbook and the summary need."""
    T = trade_table(rows, read_lists(lists_path))
    scen = settings.get("scenario")
    tar = effective_tariffs(T, scen)
    rr = row_ratios(io)
    N = calibrate_N(rr) if settings.get("calibrate_N", True) else float(settings.get("N", 16.043))
    mk = run_market(rr, N)
    R = goods_ratios(mk)
    P = package_ratios(R, tar, T)
    damp_tau = tar["tau"] * P
    specs = {}
    for den in ("Intermediate inputs", "Total cost"):
        for cons in (True, False):
            par = network_params(io, den, settings.get("omega_ca", "paper"), settings.get("shares", "proportional"),
                                 settings.get("omega_us", "paper"))
            full, dmp = network(par, tar["tau"], cons), network(par, damp_tau, cons)
            specs[(den, cons)] = dict(full=full, damp=dmp, par=par)
    val, corr = validation(mk)
    scen_pts = sum(r["value"] * r["scen_rate"] for r in T) / static.TOTAL_IMPORTS_ALL * 100
    return dict(settings={k: settings.get(k) for k in ("shares", "omega_us", "omega_ca")}, scenario=scen, scen_points=scen_pts, T=T, tar=tar, rr=rr, N=N, mk=mk, R=R, P=P, damp_tau=damp_tau, specs=specs, validation=val, corr=corr)
