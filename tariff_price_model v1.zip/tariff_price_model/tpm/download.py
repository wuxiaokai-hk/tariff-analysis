"""Downloads from Statistics Canada, cached in data/cache.

* Input-output tables, detail level (Table 36-10-0001-01): one zip for all years (~45 MB).
* Canadian International Merchandise Trade (CIMT) annual import files: one zip per year (~80 MB),
  from the Open Government Portal dataset "Canadian International Merchandise Trade Web Application (CIMT)".
"""
import os
import re
import sys
import urllib.error
import urllib.request

IO_WDS = "https://www150.statcan.gc.ca/t1/wds/rest/getFullTableDownloadCSV/36100001/en"
IO_ZIP = "https://www150.statcan.gc.ca/n1/tbl/csv/36100001-eng.zip"
CIMT_ZIP = "https://www150.statcan.gc.ca/n1/pub/71-607-x/2021004/zip/CIMT-CICM_Imp_{year}.zip"
UA = {"User-Agent": "Mozilla/5.0 (tariff-price-model; research use)"}


def _get(url, timeout=120):
    req = urllib.request.Request(url, headers=UA)
    return urllib.request.urlopen(req, timeout=timeout)


def _save(url, path, label):
    tmp = path + ".part"
    with _get(url, timeout=600) as r, open(tmp, "wb") as f:
        ctype = r.headers.get("Content-Type", "")
        total = int(r.headers.get("Content-Length") or 0)
        first = r.read(1 << 16)
        if b"<html" in first[:2000].lower() or "html" in ctype:
            f.close(); os.remove(tmp)
            return first + r.read()          # caller handles an HTML landing page
        f.write(first); done = len(first)
        while True:
            chunk = r.read(1 << 20)
            if not chunk:
                break
            f.write(chunk); done += len(chunk)
            if total:
                sys.stdout.write(f"\r  {label}: {done/1e6:,.0f} of {total/1e6:,.0f} MB"); sys.stdout.flush()
    os.replace(tmp, path)
    sys.stdout.write("\n")
    return None


def io_zip(cache_dir, refresh=False):
    """Path to the input-output zip, downloading it if needed."""
    os.makedirs(cache_dir, exist_ok=True)
    path = os.path.join(cache_dir, "36100001-eng.zip")
    if os.path.exists(path) and not refresh:
        return path
    print("Downloading Statistics Canada input-output tables (Table 36-10-0001-01) ...")
    url = IO_ZIP
    try:   # the WDS service returns the current download link
        import json
        with _get(IO_WDS) as r:
            url = json.loads(r.read().decode())["object"] or IO_ZIP
    except Exception:
        pass
    html = _save(url, path, "input-output")
    if html is not None:   # Statistics Canada sometimes returns a landing page with a tokenised link
        m = re.search(rb'href="([^"]*36100001-eng\.zip\?st=[^"]+)"', html)
        if not m:
            raise RuntimeError("Could not find the download link for Table 36-10-0001-01. Download it manually from "
                               "https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=3610000101 (Download options > "
                               f"entire table, CSV) and save it as {path}")
        link = m.group(1).decode().replace("&amp;", "&")
        if link.startswith("/"):
            link = "https://www150.statcan.gc.ca" + link
        if _save(link, path, "input-output") is not None:
            raise RuntimeError("Statistics Canada returned a web page instead of the zip file.")
    return path


def cimt_zip(year, cache_dir, refresh=False):
    """Path to the CIMT annual import zip for `year`, downloading it if needed."""
    os.makedirs(cache_dir, exist_ok=True)
    path = os.path.join(cache_dir, f"CIMT-CICM_Imp_{year}.zip")
    if os.path.exists(path) and not refresh:
        return path
    url = CIMT_ZIP.format(year=year)
    print(f"Downloading CIMT imports {year} ...")
    try:
        html = _save(url, path, f"CIMT {year}")
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"CIMT import file for {year} is not available ({e.code}) at {url}. "
                           "Check the years listed at https://open.canada.ca/data/en/dataset/2909a648-5753-4924-878a-b069392d9cde") from e
    if html is not None:
        raise RuntimeError(f"Statistics Canada returned a web page instead of {url}.")
    return path
