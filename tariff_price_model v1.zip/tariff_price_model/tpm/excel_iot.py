"""IOT tabs (separate Domestic and Import-from-US tables) and the Settings switches that choose where the network
inputs come from. Runs before excel_layout.organize, so it uses the internal sheet names.

  IOT_Dom      industry x industry domestic intermediate flows, plus household consumption of domestic products
  IOT_US       industry x industry U.S.-imported intermediate flows, plus household purchases of U.S. imports
  IOT_Shares   sector aggregates from the two tabs -> aCA, aUS, gamma, domestic spending weight, consumer channel,
               Omega_CA (20 x 20) and Omega_US (20 x 21)

Settings rows 7-9 (yellow) switch each piece between the public-table estimate and the IOT tables:
  B7 input shares and household weights   B8 Omega_US   B9 Omega_CA
The model reads the "in use" blocks: Inputs B15 and B19:D38, StatCan_Goods F, Omega_US rows 30-49, Omega_CA rows 30-49.
"""
from openpyxl.utils import get_column_letter as CL
from openpyxl.worksheet.datavalidation import DataValidation

from . import static

IOT = "IOT tables"


def wire(wb, D, put, hdr, note, W, fonts, choice, base_us, base_ca):
    """choice: dict(shares=..., omega_us=..., omega_ca=...) as run; base_us / base_ca: labels of rows 5-24 of Omega tabs."""
    BLUE, BLACK, GREEN, BOLD, TITLE, H2 = fonts
    YEL = None
    from openpyxl.styles import PatternFill
    YEL = PatternFill("solid", fgColor="FFFF00")
    iot = D.get("iot") or {}
    has = bool(iot.get("Zd")) and bool(iot.get("Zus_g"))
    ip, sc, sg, md, ou, oc = (wb[n] for n in ("Inputs", "StatCan_IO", "StatCan_Goods", "Model", "Omega_US", "Omega_CA"))
    PUB = "Public table (proportionality)"

    # ---------------- Settings switches
    ip["A11"] = ip["A8"].value; ip["A8"] = None
    lab = {"shares": (7, "Sector input shares (aCA, aUS) and household weights from", [PUB] + ([IOT] if has else []),
                      IOT if choice.get("shares") == "iot" else PUB,
                      "Public table: domestic and U.S. parts estimated by import proportionality. IOT tables: read directly from the Domestic and Import-from-US tables (IOT_Shares)."),
           "omega_us": (8, "Omega_US (U.S. goods used by each sector) from", [base_us] + ([IOT] if has else []),
                        IOT if choice.get("omega_us") == "iot" else base_us, "Rows 5-24 of N7_Omega_US hold the base table; IOT tables: from the Import-from-US table."),
           "omega_ca": (9, "Omega_CA (domestic suppliers of each sector) from", [base_ca] + ([IOT] if has else []),
                        IOT if choice.get("omega_ca") == "iot" else base_ca, "Rows 5-24 of N8_Omega_CA hold the base table; IOT tables: from the Domestic table.")}
    for k, (r, text, opts, val, nt) in lab.items():
        ip.cell(row=r, column=1, value=text).font = BLACK
        put(ip, f"B{r}", val, BLUE, None, YEL)
        c = ip.cell(row=r, column=3, value=nt); c.font = NOTE_FONT(note, ip)
        dv = DataValidation(type="list", formula1='"' + ",".join(opts) + '"', allow_blank=False); ip.add_data_validation(dv); dv.add(f"B{r}")

    S = "Inputs!$B$7"; OUS_SW = "Inputs!$B$8"; OCA_SW = "Inputs!$B$9"

    # ---------------- IOT detail and shares
    if has:
        det = iot["detail"]; inds = D["detail"]["inds"]; n = len(inds); R0 = 5; R1 = R0 + n - 1
        for key, name, title, htitle in (("domestic", "IOT_Dom", "Domestic intermediate flows (rows = supplying industry, columns = using industry), IOT Domestic table",
                                          "Household consumption of domestic products (SUM PEC)"),
                                         ("us", "IOT_US", "U.S.-imported intermediate flows (rows = product's industry, columns = using industry), IOT Import-from-US table",
                                          "Household purchases of U.S. imports (SUM PEC)")):
            z = wb.create_sheet(name); z["A1"] = f"{title}, {D['year']}, C$ thousands"; z["A1"].font = TITLE
            note(z, "A2", "Row 3: sector # of each using industry. Columns B-C: sector # and good # of the supplying industry (from N4_IO_Industries). Column D: households.")
            put(z, "A4", "Code", BOLD); put(z, "B4", "Sector #", BOLD); put(z, "C4", "Good #", BOLD); put(z, "D4", htitle, BOLD)
            for k, code in enumerate(inds):
                cc = CL(5 + k); put(z, f"{cc}4", code, BOLD); put(z, f"{cc}3", f"=INDEX(IO_Industries!$D${R0}:$D${R1},{k + 1})", GREEN, "0")
            for a, code in enumerate(inds):
                r = R0 + a
                z.cell(row=r, column=1, value=code).font = BLUE
                z.cell(row=r, column=2, value=f"=IO_Industries!D{r}").font = GREEN
                z.cell(row=r, column=3, value=f"=IO_Industries!E{r}").font = GREEN
                h = det[key]["H"][a]
                if h:
                    c = z.cell(row=r, column=4, value=h); c.font = BLUE; c.number_format = "#,##0"
                for b, v in enumerate(det[key]["Z"][a]):
                    if v:
                        c = z.cell(row=r, column=5 + b, value=v); c.font = BLUE; c.number_format = "#,##0"
            z.freeze_panes = "E5"; W(z, {"A": 11, "B": 9, "C": 8, "D": 16})
        zl = CL(4 + n)
        rng = lambda sh, c: f"{sh}!${c}${R0}:${c}${R1}"
        DAT = lambda sh: f"{sh}!$E${R0}:${zl}${R1}"
        COLS = lambda sh: f"{sh}!$E$3:${zl}$3"

        sh = wb.create_sheet("IOT_Shares"); sh["A1"] = f"Network inputs from the IOT tables (separate Domestic and Import-from-US tables), {D['year']}"; sh["A1"].font = TITLE
        note(sh, "A2", "No import proportionality: domestic and U.S.-imported flows are read from the tables. aUS counts U.S. imports of goods (products with a good #), as tariffs apply to goods. Denominator: StatCan_IO column L (Settings B5).")
        hdr(sh, 4, ["Sector", "Domestic intermediate inputs", "U.S.-imported goods inputs", "Denominator", "aCA (IOT)", "aUS (IOT)",
                    "Household consumption of domestic products", "gamma (IOT)"], h=48)
        for i in range(20):
            r = 5 + i; s = i + 1
            put(sh, f"A{r}", static.SECTORS[i])
            put(sh, f"B{r}", f"=SUMPRODUCT(({COLS('IOT_Dom')}={s})*{DAT('IOT_Dom')})", GREEN, "#,##0")
            put(sh, f"C{r}", f"=SUMPRODUCT(({COLS('IOT_US')}={s})*({rng('IOT_US', 'C')}>0)*{DAT('IOT_US')})", GREEN, "#,##0")
            put(sh, f"D{r}", f"=StatCan_IO!L{r}", GREEN, "#,##0")
            put(sh, f"E{r}", f"=IFERROR(B{r}/D{r},0)", BLACK, "0.0000"); put(sh, f"F{r}", f"=IFERROR(C{r}/D{r},0)", BLACK, "0.0000")
            put(sh, f"G{r}", f"=SUMIFS({rng('IOT_Dom', 'D')},{rng('IOT_Dom', 'B')},{s})", GREEN, "#,##0")
            put(sh, f"H{r}", f"=G{r}/SUM($G$5:$G$24)", BLACK, "0.0000")
        put(sh, "A26", "Domestic share of household spending (IOT) = SUM G / total household consumption", BOLD)
        put(sh, "H26", "=SUM(G5:G24)/StatCan_Goods!B28", BLACK, "0.0000")
        hdr(sh, 28, ["Good", "Household purchases of U.S. imports (IOT)", "Share of household consumption (consumer channel)"], h=40)
        for g in range(21):
            r = 29 + g
            put(sh, f"A{r}", static.GOODS[g]); put(sh, f"B{r}", f"=SUMIFS({rng('IOT_US', 'D')},{rng('IOT_US', 'C')},{g + 1})", GREEN, "#,##0")
            put(sh, f"C{r}", f"=B{r}/StatCan_Goods!$B$28", BLACK, "0.0000")
        # Omega_CA (IOT): buying sector rows, supplying sector columns
        sh["A52"] = "Omega_CA (IOT): share of each buying sector's domestic inputs bought from each supplying sector"; sh["A52"].font = H2
        hdr(sh, 53, ["Buying sector"] + static.SECTOR_NAICS + ["Row sum"])
        for i in range(20):
            r = 54 + i; put(sh, f"A{r}", static.SECTORS[i])
            for k in range(20):
                put(sh, f"{CL(2 + k)}{r}", f"=IFERROR(SUMPRODUCT(({rng('IOT_Dom', 'B')}={k + 1})*({COLS('IOT_Dom')}={i + 1})*{DAT('IOT_Dom')})/$B${5 + i},0)", BLACK, "0.000")
            put(sh, f"V{r}", f"=SUM(B{r}:U{r})", BLACK, "0.000")
        # Omega_US (IOT): buying sector rows, goods columns
        sh["A76"] = "Omega_US (IOT): share of each buying sector's U.S. goods imports that is each good"; sh["A76"].font = H2
        hdr(sh, 77, ["Buying sector"] + [f"{g + 1}. {static.GOODS[g]}" for g in range(21)] + ["Row sum"], h=60)
        for i in range(20):
            r = 78 + i; put(sh, f"A{r}", static.SECTORS[i])
            for g in range(21):
                put(sh, f"{CL(2 + g)}{r}", f"=IFERROR(SUMPRODUCT(({rng('IOT_US', 'C')}={g + 1})*({COLS('IOT_US')}={i + 1})*{DAT('IOT_US')})/$C${5 + i},0)", BLACK, "0.000")
            put(sh, f"W{r}", f"=SUM(B{r}:V{r})", BLACK, "0.000")
        W(sh, {"A": 34, **{CL(c): 11 for c in range(2, 24)}})

    ou["A2"] = f"Rows 5-24: base table = {base_us}. Rows 30-49: the table the model uses (Settings B8)."
    oc["A2"] = f"Rows 5-24: base table = {base_ca}. Rows 30-49: the table the model uses (Settings B9)."

    # ---------------- "in use" blocks the model reads
    sw = lambda cond_cell, iot_ref, base_ref: f'=IF({cond_cell}="{IOT}",{iot_ref},{base_ref})' if has else f"={base_ref}"
    for i in range(20):
        r = 19 + i; s5 = 5 + i
        put(ip, f"B{r}", sw(S, f"IOT_Shares!H{s5}", f"StatCan_IO!R{s5}"), GREEN, "0.000")
        put(ip, f"C{r}", sw(S, f"IOT_Shares!F{s5}", f"StatCan_IO!O{s5}"), GREEN, "0.0000")
        put(ip, f"D{r}", sw(S, f"IOT_Shares!E{s5}", f"StatCan_IO!N{s5}"), GREEN, "0.0000")
    put(ip, "B15", sw(S, "IOT_Shares!H26", "SUM(StatCan_IO!Q5:Q24)/StatCan_Goods!B28"), BLACK, "0.000")
    hdr(sg, 4, ["Consumer channel in use"], col=6, h=45)
    for g in range(21):
        put(sg, f"F{5 + g}", sw(S, f"IOT_Shares!C{29 + g}", f"E{5 + g}"), GREEN, "0.0000")
    sg.column_dimensions["F"].width = 16
    # Omega in use: rows 30-49
    ou["A28"] = "Omega_US in use (Settings B8): base table above, or IOT_Shares rows 78-97"; ou["A28"].font = H2
    hdr(ou, 29, ["Sector", "NAICS"] + [f"{j + 1}. {static.GOODS[j]}" for j in range(21)] + ["Row sum"], h=60)
    oc["A28"] = "Omega_CA in use (Settings B9): base table above, or IOT_Shares rows 54-73"; oc["A28"].font = H2
    hdr(oc, 29, ["Buying sector", "NAICS"] + static.SECTOR_NAICS + ["Row sum"])
    for i in range(20):
        r = 30 + i; b = 5 + i
        put(ou, f"A{r}", static.SECTORS[i]); put(ou, f"B{r}", static.SECTOR_NAICS[i])
        for j in range(21):
            put(ou, f"{CL(3 + j)}{r}", sw(OUS_SW, f"IOT_Shares!{CL(2 + j)}{78 + i}", f"{CL(3 + j)}{b}"), BLACK, "0.000")
        put(ou, f"X{r}", f"=SUM(C{r}:W{r})", BLACK, "0.00")
        put(oc, f"A{r}", static.SECTORS[i]); put(oc, f"B{r}", static.SECTOR_NAICS[i])
        for j in range(20):
            put(oc, f"{CL(3 + j)}{r}", sw(OCA_SW, f"IOT_Shares!{CL(2 + j)}{54 + i}", f"{CL(3 + j)}{b}"), BLACK, "0.000")
        put(oc, f"W{r}", f"=SUM(C{r}:V{r})", BLACK, "0.00")
    # point the network at the in-use blocks
    for i in range(20):
        for j in range(20):
            c = md.cell(row=5 + i, column=3 + j)
            c.value = c.value.replace(f"Omega_CA!{CL(3 + j)}{5 + i}", f"Omega_CA!{CL(3 + j)}{30 + i}")
    from openpyxl.worksheet.formula import ArrayFormula
    for ref, rng_ in (("C53", "C53:F72"), ("C77", "C77:F96")):
        t = md[ref].value.text.replace("Omega_US!C5:W24", "Omega_US!C30:W49")
        md[ref] = ArrayFormula(rng_, t)
    return has


def NOTE_FONT(note, ws):
    from openpyxl.styles import Font
    return Font(name="Arial", italic=True, size=9, color="595959")
