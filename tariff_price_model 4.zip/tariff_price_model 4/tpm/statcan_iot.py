"""Read Statistics Canada's input-output workbook with separate tables by origin ("IOT" file, available on request).

The workbook holds up to four tables in the same wide layout, one per sheet:
  Total            all products, domestic + imported          (needed)
  Domestic         domestically produced products only       (needed for aCA, Omega_CA, domestic consumption)
  Import from US   products imported from the United States  (needed for aUS, Omega_US, consumer channel)
  Imports          products imported from all countries      (optional; used for checks)

Layout of each sheet (as in the "simlate" sample):
  rows    = supplying industries (products): code in column B, title in column C (or the code in brackets at the end
            of the title, e.g. "Aerospace product and parts manufacturing [BS336400]")
  columns = using industries and final demand: code in row 6, title in row 7 (or the code in brackets in the title)
  values  = C$ thousands, from the first column after the titles and the first row after the column titles.
Pivot-table helper lines ("Grand Total", "Row Labels", "Sum of VALUE") are ignored.
"""
import json
import os
import re

import numpy as np

from . import static
from .statcan_io import _good, _sector

BRACKET = re.compile(r"\[([^\]]+)\]\s*$")
KINDS = ("total", "domestic", "us", "imports")


def _code_of(code_cell, title_cell):
    """Code from its own cell if it looks like one, else from '[CODE]' at the end of the title, else the title."""
    for v in (code_cell,):
        if isinstance(v, str) and v.strip() and (v.strip() in ("Total use", "Total supply") or re.fullmatch(r"[A-Z]{2,4}[A-Za-z0-9]{3,8}", v.strip())):
            return v.strip()
    t = str(title_cell or "").strip()
    m = BRACKET.search(t)
    return m.group(1) if m else t


def _kind(sheet_name):
    s = sheet_name.lower().replace("_", " ")
    if "domestic" in s:
        return "domestic"
    if "import" in s and ("us" in s.split() or "u.s" in s or "united states" in s or s.endswith(" us") or "from us" in s):
        return "us"
    if "import" in s:
        return "imports"
    if "total" in s:
        return "total"
    return None


IND = re.compile(r"^(BS|NP|GS)[A-Za-z0-9]{4,8}$")


def find_layout(ws, look=30):
    """(code_row, code_col): the row with the most industry codes (BS/NP/GS...) across the top, and the column with
    the most industry codes down the left. Titles are taken from the next row / column."""
    best_r = max(range(1, look + 1), key=lambda r: sum(1 for c in range(1, ws.max_column + 1)
                                                        if isinstance(v := ws.cell(row=r, column=c).value, str) and IND.match(v.strip())))
    best_c = max(range(1, 11), key=lambda c: sum(1 for r in range(1, min(ws.max_row, 400) + 1)
                                                if isinstance(v := ws.cell(row=r, column=c).value, str) and IND.match(v.strip())))
    return best_r, best_c


def read_sheet(ws, code_row=None, title_row=None, code_col=None, title_col=None):
    """{supply code: {use code: value}}, plus code -> title for rows and columns.
    Header rows and code column are found automatically (find_layout) unless given."""
    if code_row is None or code_col is None:
        r0, c0 = find_layout(ws)
        code_row = code_row or r0; code_col = code_col or c0
    title_row = title_row or code_row + 1; title_col = title_col or code_col + 1
    print(f"  sheet '{ws.title}': use codes in row {code_row}, titles row {title_row}; "
          f"supply codes in column {code_col}, titles column {title_col}; data from row {title_row + 1}")
    data_col = title_col + 1
    cols, titles = {}, {}
    for c in range(data_col, ws.max_column + 1):
        code = _code_of(ws.cell(row=code_row, column=c).value, ws.cell(row=title_row, column=c).value)
        if str(code).strip().lower() in ("total", "total use", "total uses"):  # output column ("TOTAL" / "Total")
            code = "Total use"
        if code and code not in ("Grand Total", "Column Labels", "None"):
            cols[c] = code; titles[code] = str(ws.cell(row=title_row, column=c).value or code)
    cells = {}
    for r in range(title_row + 1, ws.max_row + 1):
        code = _code_of(ws.cell(row=r, column=code_col).value, ws.cell(row=r, column=title_col).value)
        if not code or code in ("Grand Total", "Row Labels", "None"):
            continue
        titles.setdefault(code, str(ws.cell(row=r, column=title_col).value or code))
        row = cells.setdefault(code, {})
        for c, uc in cols.items():
            v = ws.cell(row=r, column=c).value
            if isinstance(v, (int, float)) and v != 0:
                row[uc] = row.get(uc, 0.0) + float(v)
    return cells, titles


def read_workbook(path, sheets=None):
    """{kind: (cells, titles)}. sheets: optional {kind: sheet name}; otherwise sheet names are recognised, and a
    workbook with a single unrecognised sheet is read as the Total table."""
    from openpyxl import load_workbook
    wb = load_workbook(path, read_only=False, data_only=True)
    out = {}
    if sheets:
        for k, name in sheets.items():
            out[k] = read_sheet(wb[name])
    else:
        for ws in wb.worksheets:
            k = _kind(ws.title)
            if k and k not in out:
                out[k] = read_sheet(ws)
        if not out and len(wb.worksheets) == 1:
            out["total"] = read_sheet(wb.worksheets[0])
    if "total" not in out:
        raise ValueError(f"No Total table found in {path}. Sheets: {wb.sheetnames}. Use --iot-sheets total=<sheet name>,...")
    return out


def aggregate(tables, year):
    """Sector/good aggregates. Total table -> the same keys as statcan_io (X, H, M, MUS, Z, Htot, MUS_g, HUS_g, detail);
    Domestic and Import-from-US tables -> io['iot'] with domestic and U.S.-imported flows (no proportionality needed)."""
    from .statcan_io import aggregate_cells
    tot_cells, titles = tables["total"]
    io = aggregate_cells(tot_cells, titles, year, source="Statistics Canada IOT workbook (Total table)")
    NS, NG = 20, 21
    iot = {"has": [k for k in KINDS if k in tables]}

    def flows(cells):
        Zs = np.zeros((NS, NS)); H = np.zeros(NS); Zg = np.zeros((NG, NS)); Hg = np.zeros(NG)
        for sup, row in cells.items():
            i = _sector(sup)
            if i is None:
                continue
            g = _good(sup)
            h = sum(v for c, v in row.items() if c.startswith("PEC"))
            H[i] += h
            if g:
                Hg[g - 1] += h
            for c, v in row.items():
                j = _sector(c)
                if j is not None:
                    Zs[i, j] += v
                    if g:
                        Zg[g - 1, j] += v
        return Zs, H, Zg, Hg

    if "domestic" in tables:
        Zd, Hd, _, _ = flows(tables["domestic"][0])
        iot.update(Zd=Zd.tolist(), Hd=Hd.tolist())
    if "us" in tables:
        _, _, Zus_g, Hus_g = flows(tables["us"][0])
        iot.update(Zus_g=Zus_g.tolist(), HUS_g=Hus_g.tolist())
    if "imports" in tables:
        Zm, Hm, _, _ = flows(tables["imports"][0])
        iot.update(Zm=Zm.tolist(), Hm=Hm.tolist())
    iot["detail"] = _detail(tables, io["detail"]["inds"])
    io["iot"] = iot
    return io


def _detail(tables, inds):
    """Industry-level domestic and U.S.-imported flows for the workbook (same industry order as the Total detail)."""
    out = {}
    for k in ("domestic", "us"):
        if k not in tables:
            continue
        cells = tables[k][0]
        out[k] = dict(Z=[[cells.get(a, {}).get(b, 0.0) for b in inds] for a in inds],
                      H=[sum(v for c, v in cells.get(a, {}).items() if c.startswith("PEC")) for a in inds])
    return out


def load(path, year, processed_dir, sheets=None, refresh=False):
    out = os.path.join(processed_dir, f"iot_{year}.json")
    if os.path.exists(out) and not refresh and os.path.getmtime(out) > os.path.getmtime(path):
        return json.load(open(out))
    print(f"Reading the IOT workbook {os.path.basename(path)} ...")
    io = aggregate(read_workbook(path, sheets), year)
    os.makedirs(processed_dir, exist_ok=True)
    json.dump(io, open(out, "w"))
    return io
