"""Tab names, order, colours and the sheet map on the README tab.

The workbook is built with short internal names; organize() renames every sheet and rewrites every formula and
text reference to the new names, so users see tabs grouped by step: inputs, T (tariffs), D (dampening), N (network).
"""
import re

from openpyxl.worksheet.formula import ArrayFormula

GROUPS = {  # colour (tab), label
    "start": ("1F3A5F", "Start here"), "input": ("FFC000", "Inputs you can change"), "result": ("00B050", "Results"),
    "T": ("4472C4", "Step 1 - Tariffs by good"), "D": ("ED7D31", "Step 2 - Market dampening (SWP 2026-36)"),
    "N": ("7030A0", "Step 3 - Supply-chain network (SWP 2026-35)"), "check": ("7F7F7F", "Checks and sources"),
}
# internal name -> (new name, group, what it is)
SHEETS = [
    ("Guide", "README", "start", "What the workbook does, the method, and this sheet map"),
    ("Results", "Results", "result", "CPI effect of each package: full pass-through and with dampening; by sector; ratios by good"),
    ("Scenario", "Scenario", "input", "YOUR SCENARIO: tariff rate and coverage by HS chapter (2-digit); results in Results row 9"),
    ("Inputs", "Settings", "input", "Switches: cost-share denominator, consumer channel; sector parameters in use"),
    ("Tariffs", "T1_Tariffs_by_Good", "T", "Effective tariff on each of 21 goods for each package; dampening ratios; dampened tariffs"),
    ("Tariff_Lists", "T2_Tariff_Lists", "T", "Finance Canada lists: official values, matched imports, scale factors"),
    ("CIMT_HS6", "T3_Trade_HS6", "T", "Imports from the U.S. by HS6 product with list flags; scenario rate by product (column P to override)"),
    ("Goods_Ratios", "D1_Damping_by_Good", "D", "Dampening ratio for each good at 5, 10, 15, 25, 50% (used by T1)"),
    ("Mkt_Results", "D2_Market_Results", "D", "Market model results for 32 industries at each tariff rate"),
    ("Mkt_Validation", "D3_Market_Validation", "D", "Comparison with SWP 2026-36 Tables 3 and F.1"),
    ("Mkt_Calibration", "D4_Market_Calibration", "D", "The one calibrated number: Canadian firms per industry (N)"),
    ("Mkt_Inputs", "D5_Market_Inputs", "D", "sigma, rho, N, firm-size distribution"),
    ("Mkt_Industry", "D6_Market_Industries", "D", "U.S., rest-of-world and Canadian shares by industry"),
    ("Mkt_Firms", "D7_Market_Firms", "D", "Initial shares, markups and costs of the 11 firm types"),
    ("Mkt_Solve_5", "D8_Solve_5pct", "D", "Market equilibrium at a 5% tariff (50 iterations)"),
    ("Mkt_Solve_10", "D9_Solve_10pct", "D", "Market equilibrium at 10%"),
    ("Mkt_Solve_15", "D10_Solve_15pct", "D", "Market equilibrium at 15%"),
    ("Mkt_Solve_25", "D11_Solve_25pct", "D", "Market equilibrium at 25%"),
    ("Mkt_Solve_50", "D12_Solve_50pct", "D", "Market equilibrium at 50%"),
    ("Model", "N1_Network_Model", "N", "Leontief inverse and sector price changes (full and dampened)"),
    ("StatCan_IO", "N2_IO_Sectors", "N", "Input-output table by sector: output, consumption, imports, aCA, aUS, gamma, Z"),
    ("StatCan_Goods", "N3_IO_Goods", "N", "U.S. imports and household U.S. purchases by good"),
    ("IO_Industries", "N4_IO_Industries", "N", "Input-output table by detailed industry (source of N2 and N3)"),
    ("IO_Z", "N5_IO_Flows", "N", "Industry-by-industry intermediate flows (source of the Z table in N2)"),
    ("IO_Map", "N6_IO_Mapping", "N", "Industry -> sector and industry -> good mappings"),
    ("Omega_US", "N7_Omega_US", "N", "SWP 2026-35 Table 1: U.S. goods used by each sector"),
    ("Omega_CA", "N8_Omega_CA", "N", "SWP 2026-35 Table A1: domestic input shares"),
    ("Checks", "Checks", "check", "Automatic checks (PASS / REVIEW)"),
    ("References", "References", "check", "Sources"),
]


def _ref_pattern(old):
    return re.compile(r"(?<![A-Za-z0-9_'])" + re.escape(old) + r"!")


def organize(wb, has_detail, put, hdr, note, W, fonts):
    BLUE, BLACK, GREEN, BOLD, TITLE, H2 = fonts
    present = [t for t in SHEETS if t[0] in wb.sheetnames]
    # longest names first so "Mkt_Results" is replaced before "Results"
    pats = [(_ref_pattern(o), n + "!") for o, n, *_ in sorted(present, key=lambda t: -len(t[0])) if o != n]
    text_names = [(o, n) for o, n, *_ in sorted(present, key=lambda t: -len(t[0])) if "_" in o or o in ("Tariffs", "Inputs", "Model", "Guide")]
    text_pats = [(re.compile(r"(?<![A-Za-z0-9_])" + re.escape(o) + r"(?![A-Za-z0-9_])"), n) for o, n in text_names]
    fixed = [("all Mkt_Solve sheets", "all D8-D12 solve tabs"), ("(Mkt_ sheets)", "(D tabs)"), ("Mkt_ sheets", "D tabs")]
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for c in row:
                v = c.value
                if isinstance(v, ArrayFormula):
                    t = v.text
                    for p, n in pats: t = p.sub(n, t)
                    v.text = t
                elif isinstance(v, str) and v.startswith("="):
                    for p, n in pats: v = p.sub(n, v)
                    c.value = v
                elif isinstance(v, str):
                    for a, b in fixed: v = v.replace(a, b)
                    for p, n in text_pats:
                        if p.search(v) and (" " in v):
                            v = p.sub(n, v)
                    c.value = v
    for o, n, g, _ in present:
        ws = wb[o]; ws.title = n; ws.sheet_properties.tabColor = GROUPS[g][0]; ws.sheet_view.showGridLines = False
    order = ["start", "result", "input", "T", "D", "N", "check"]
    wb._sheets = sorted(wb._sheets, key=lambda ws: next((order.index(g) * 100 + i for i, (o, n, g, _) in enumerate(present) if n == ws.title), 999))
    # sheet map on README
    g = wb["README"]; r0 = g.max_row + 2
    g.cell(row=r0, column=1, value="Sheet map").font = H2
    note(g, f"A{r0 + 1}", "Tabs are coloured by step: yellow = inputs you can change, green = results, blue = Step 1 tariffs, orange = Step 2 market dampening, purple = Step 3 supply-chain network, grey = checks and sources.")
    hdr(g, r0 + 2, ["Tab", "Step and contents"])
    for i, (o, n, grp, what) in enumerate(present):
        r = r0 + 3 + i
        c = g.cell(row=r, column=1, value=n); c.font = BOLD; c.hyperlink = f"#'{n}'!A1"
        g.cell(row=r, column=2, value=f"{GROUPS[grp][1]}: {what}").font = BLACK
    g.cell(row=r0 + 4 + len(present), column=1, value="Flow").font = BOLD
    g.cell(row=r0 + 4 + len(present), column=2,
           value="Scenario / tariff lists -> T1 effective tariff by good -> D1 dampening ratio -> T1 dampened tariff -> N1 network (N2-N8 data) -> Results").font = BLACK
