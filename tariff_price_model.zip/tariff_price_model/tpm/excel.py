"""Writes the combined workbook (network model of BoC SWP 2026-35 + market model of BoC SWP 2026-36) with live formulas.

Generated from the workbook build scripts used during development; every number that comes from data is written as a
blue input value, everything else is an Excel formula, so the workbook recalculates by itself when opened in Excel.
"""
import datetime

import numpy as np
from openpyxl import Workbook
from openpyxl.chart import Reference, ScatterChart, Series
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter as CL
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.worksheet.formula import ArrayFormula

from . import static
from .model import sse_25

F = "Arial"
BLUE = Font(name=F, color="0000FF"); BLACK = Font(name=F); GREEN = Font(name=F, color="008000"); BOLD = Font(name=F, bold=True)
TITLE = Font(name=F, bold=True, size=14, color="1F3A5F"); H2 = Font(name=F, bold=True, size=11, color="1F3A5F")
HDR = Font(name=F, bold=True, color="FFFFFF"); NOTE = Font(name=F, italic=True, size=9, color="595959")
HF = PatternFill("solid", fgColor="1F3A5F"); YEL = PatternFill("solid", fgColor="FFFF00")
thin = Side(style="thin", color="BFBFBF"); BOX = Border(top=thin, bottom=thin, left=thin, right=thin)
WRAP = Alignment(wrap_text=True, vertical="top")


def hdr(ws, row, labels, col=1, h=None):
    for i, t in enumerate(labels):
        c = ws.cell(row=row, column=col + i, value=t); c.font = HDR; c.fill = HF
        c.alignment = Alignment(wrap_text=True, vertical="center"); c.border = BOX
    if h: ws.row_dimensions[row].height = h


def put(ws, ref, v, font=BLACK, fmt=None, fill=None, box=True):
    c = ws[ref]; c.value = v; c.font = font
    if box: c.border = BOX
    if fmt: c.number_format = fmt
    if fill: c.fill = fill


def note(ws, ref, t):
    ws[ref] = t; ws[ref].font = NOTE


def W(ws, d):
    for k, v in d.items(): ws.column_dimensions[k].width = v


def write(path, io, res, period_label, n_months, omega_ca="paper"):
    """io: aggregated input-output dict; res: model.run() output; period_label: e.g. 'Jan 2024 to Dec 2024'."""
    D = io
    SECT, NAICS, GOODS = static.SECTORS, static.SECTOR_NAICS, static.GOODS
    OUS = np.array(static.OMEGA_US)
    OCA = res["specs"][("Intermediate inputs", True)]["par"]["W_CA"]
    F1 = static.TABLE_F1
    NI = len(F1); R0 = 5; RL = R0 + NI - 1; RATES = static.RATES; NIT = 50; NT = 11
    CIM = res["T"]
    SCEN = res.get("scenario"); SC0 = 12; SC1 = SC0 + len(static.HS_CHAPTERS) - 1
    N_CAL = res["N"]
    rr_ = res["rr"]
    GRID = {float(n): sse_25(rr_, float(n)) for n in (4, 6, 8, 10, 12, 14, 16, 18, 20, 25, 30, 40)}
    SPEC2 = {}
    for den in ("Intermediate inputs", "Total cost"):
        for cons in (True, False):
            s = res["specs"][(den, cons)]
            SPEC2[f"{den}|{'Yes' if cons else 'No'}"] = [round(float(x), 4) for x in list(s["full"]["total"][:3]) + list(s["damp"]["total"][:3])]
    sc_ = res["tar"]["scale"]; mt_ = res["tar"]["matched"]
    COVERED_EXPECTED = (sum(min(static.LISTS[k]["official"], mt_[k]) for k in ("mar4", "steel", "alum", "other"))
                        + min(static.LISTS["veh_pre"]["official"], mt_["veh"])
                        + min(static.LISTS["steel"]["official"], mt_["steel"]) + min(static.LISTS["alum"]["official"], mt_["alum"])
                        + min(static.LISTS["veh_post"]["official"], mt_["veh"])) / 1e9
    wb = Workbook()
    g = wb.active; g.title = "Guide"
    NS=20; NG=21
    PK=["Pre-Sept 2025 package (C$96bn at 25%)","Post-Sept 2025 package (C$50bn at 25%)","Sept 8, 2026 round (C$27.6bn at 15/25/50%)","Custom scenario (Scenario sheet)"]
    pre=[0,1,2,3,5,6,7,8,14,16]; post=[14,16]

    # ---------------- Guide
    g["A1"]="Combined tariff price model: supply-chain pass-through (BoC SWP 2026-35) with market dampening (BoC SWP 2026-36)"; g["A1"].font=TITLE
    rows=[("Purpose","Computes the consumer-price effect of Canada's counter-tariffs in two stages. Stage 1 (market, R6): how much of a tariff on U.S. goods reaches the price of each good once buyers switch suppliers and firms adjust markups (dampening ratio). Stage 2 (network, R1): how the dampened price increases pass through Canadian supply chains into consumer prices."),
    ("Combined equation","dp = (I - A_CA W_CA)^-1 A_US W_US (R x dtau), where R x dtau = each good's effective tariff times its dampening ratio (Tariffs columns K-R). With R = 1 this is the full cost pass-through of R1."),
    ("Stage 1: market model (Mkt_ sheets)","R6 model: Canadian, U.S. and rest-of-world firms compete in each of 32 industries (Cournot, nested CES, sigma = 10.5, rho = 1.24). A tariff raises U.S. firms' costs; shares and markups adjust (50 iterations). Ratio = exact price change / full cost. Industries are mapped to the 21 goods in Goods_Ratios. One parameter is calibrated: the number of equivalent Canadian firms per industry (N = «N», Mkt_Inputs B8), fitted to R6 Table F.1; validated against R6 Table 3 (Mkt_Validation)."),
    ("Which ratio is used","Pre- and post-Sept 2025 packages: ratio at 25%. Custom scenario: each product's ratio at its own rate (Scenario sheet). Sept 2026 round: by item, weighted by tariff increase x imports: 15% items use the 15% ratio, new 25% and 50% items the 25% and 50% ratios, steel and aluminum items going from 25% to 50% use the ratio of the 25-to-50% increment."),
    ("Equations (R1)","Eq. 3: dp_s = aUS_s x SUM_g wUS(s,g) dtau_g + aCA_s x SUM_j wCA(s,j) dp_j.  Eq. 4: dp = (I - A_CA W_CA)^-1 A_US W_US dtau.  Eq. 5: dP = SUM_s gamma_s dp_s. Optional consumer channel: + SUM_g (household purchases of U.S. good g / household consumption) x dtau_g."),
    ("From the paper","W_US = Table 1 (20 sectors x 21 goods); W_CA = Table A1 (20 x 20); package totals (Table 2)."),
    ("Tariffs","CIMT_HS6 holds imports from the U.S. («TP») for «NHS» HS6 products (Statistics Canada CIMT, R9) with flags for each Finance Canada list (R3a-d). Tariff_Lists and Tariffs are formulas on that sheet: matched imports, scaled to the official C$ values."),
    ("From Statistics Canada","Table 36-10-0001-01, «IO», basic prices, aggregated from 220 industries to the paper's 20 sectors: output, intermediate use, household consumption, imports (total and from the U.S.) -> aCA_s, aUS_s, gamma_s, tariff coverage and the consumer channel. Downloaded «DL»."),
    ("Two choices the paper leaves open","1) Cost-share denominator: Section 2.2 and Table A1 measure shares in total intermediate inputs (default); Eq. 2 implies shares of total cost (switch Inputs B5). 2) Consumer goods bought directly from the U.S.: in the paper they enter through retailers' and wholesalers' firm-level imports; in public data they are household imports, so they are added as a consumer channel (default Yes, switch Inputs B6)."),
    ("Result","See Results: full pass-through (as in R1) and with market dampening, for each package and specification."),
    ("",""),
    ("How to use",""),
    ("Step 1: your scenario","Scenario tab: type a tariff rate (%) for any HS chapter (2-digit) in column E, and the share of the chapter covered in column F; or one rate for everything in C6. Single HS6 products can be overridden in T3_Trade_HS6 column P."),
    ("Step 2: read the results","Results row 9 (Custom scenario): full pass-through and with dampening, plus the official packages in rows 6-8, and effects by sector below."),
    ("Step 3: settings (optional)","Settings tab: cost-share denominator and consumer channel. Market model parameters in D5_Market_Inputs (sigma, rho, N)."),
    ("",""),
    ("Colour code","Blue = data; black = formulas; green = links; yellow = switches, calibrated parameter and inputs to review.")]
    for i,(a,b) in enumerate(rows):
        r=3+i; g.cell(row=r,column=1,value=a).font=BOLD if b else H2
        c=g.cell(row=r,column=2,value=b); c.font=BLACK; c.alignment=WRAP
    W(g,{"A":24,"B":130})

    # ---------------- Omega tables
    ou=wb.create_sheet("Omega_US"); ou["A1"]="Table 1 (R1): shares of U.S.-imported goods used by each sector (rows sum to 1)"; ou["A1"].font=TITLE
    note(ou,"A2","Transcribed from BoC SWP 2026-35, Table 1. Goods = Canadian Export Classification sections (Table A4).")
    hdr(ou,4,["Sector","NAICS"]+[f"{j+1}. {GOODS[j]}" for j in range(NG)]+["Row sum"],h=75)
    for i in range(NS):
        r=5+i; put(ou,f"A{r}",SECT[i],BLUE); put(ou,f"B{r}",NAICS[i],BLUE)
        for j in range(NG): put(ou,f"{CL(3+j)}{r}",float(OUS[i,j]),BLUE,"0.00")
        put(ou,f"X{r}",f"=SUM(C{r}:W{r})",BLACK,"0.00")
    W(ou,{"A":34,"B":7,**{CL(3+j):9 for j in range(NG)},"X":8})
    oc=wb.create_sheet("Omega_CA"); oc["A1"]="Table A1 (R1): shares of domestic inputs by supplying sector (rows = buying sector)"; oc["A1"].font=TITLE
    note(oc,"A2","Transcribed from BoC SWP 2026-35, Table A1 (2022, 2-digit NAICS, from Statistics Canada Table 36-10-0001-01).")
    hdr(oc,4,["Buying sector","NAICS"]+NAICS+["Row sum"])
    for i in range(NS):
        r=5+i; put(oc,f"A{r}",SECT[i],BLUE); put(oc,f"B{r}",NAICS[i],BLUE)
        for j in range(NS): put(oc,f"{CL(3+j)}{r}",float(OCA[i,j]),BLUE,"0.00")
        put(oc,f"W{r}",f"=SUM(C{r}:V{r})",BLACK,"0.00")
    W(oc,{"A":34,"B":7,**{CL(3+j):6.5 for j in range(NS)},"W":8})

    # ---------------- Inputs
    ip=wb.create_sheet("Inputs"); ip["A1"]="Inputs and switches"; ip["A1"].font=TITLE
    hdr(ip,3,["Parameter","Value","Note"])
    P=[(5,"Cost-share denominator","Intermediate inputs",None,True,"Intermediate inputs: as measured in R1 Section 2.2 and Table A1 (default). Total cost: as implied by R1 Eq. 2 (labour and other costs in the residual)."),
       (6,"Include U.S. consumer goods bought directly by households?","Yes",None,True,"In R1 these enter through retailers' and wholesalers' firm-level imports; in the public input-output table they are household imports, so they are added here (StatCan_Goods column D)."),
       (15,"Household consumption of domestic output / total household consumption","=SUM(StatCan_IO!Q5:Q24)/StatCan_Goods!B28","0.000",False,"Weight on the domestic-producer effect when the consumer channel is on.")]
    for row,lab,v,fmt,yel,nt in P:
        ip.cell(row=row,column=1,value=lab).font=BLACK
        put(ip,f"B{row}",v,BLUE if not str(v).startswith("=") else BLACK,fmt,YEL if yel else None)
        c=ip.cell(row=row,column=3,value=nt); c.font=NOTE; c.alignment=WRAP
    ip["A4"]="Switches"; ip["A4"].font=H2; ip["A14"]="Consumer channel"; ip["A14"].font=H2; note(ip,"A8","Effective tariffs by good are built from the official tariff lists and 2024 trade data: see Tariff_Lists and Tariffs.")
    dv1=DataValidation(type="list",formula1='"Intermediate inputs,Total cost"',allow_blank=False); dv2=DataValidation(type="list",formula1='"Yes,No"',allow_blank=False)
    ip.add_data_validation(dv1); ip.add_data_validation(dv2); dv1.add("B5"); dv2.add("B6")
    ip["A17"]="Sector parameters in use (from StatCan_IO)"; ip["A17"].font=H2
    hdr(ip,18,["Sector","gamma (consumption weight)","aUS (U.S. input share)","aCA (domestic input share)"],h=32)
    for i in range(NS):
        r=19+i; put(ip,f"A{r}",SECT[i])
        put(ip,f"B{r}",f"=StatCan_IO!R{5+i}",GREEN,"0.000"); put(ip,f"C{r}",f"=StatCan_IO!O{5+i}",GREEN,"0.0000"); put(ip,f"D{r}",f"=StatCan_IO!N{5+i}",GREEN,"0.0000")
    W(ip,{"A":62,"B":22,"C":80,"D":22})

    # ---------------- StatCan_IO
    sc=wb.create_sheet("StatCan_IO"); sc["A1"]="Statistics Canada Table 36-10-0001-01, «IO», basic prices (C$ thousands), aggregated to the paper's 20 sectors"; sc["A1"].font=TITLE
    note(sc,"A2","Source: Input-output tables, detail level (R2), downloaded «DL»; 220 active industries mapped by NAICS (BS/NP/GS codes; NP 999999 to Other services). U.S. imports: goods sectors only (NAICS 11, 21, 22, 31-33), as R1 Table 1 covers goods.")
    note(sc,"A3","Import shares by proportionality (R8): each sector buys the same import share of a product as the economy. Denominator for the cost shares set by Inputs B5.")
    hdr(sc,4,["Sector","NAICS","Output","Household final consumption of this sector's output","Total imports of this sector's products","Imports from U.S. (goods)","Import share m = E/(C+E)","U.S. import share = F/(C+E)","Domestic intermediate inputs = SUM Z x (1-m)","U.S.-imported intermediate inputs = SUM Z x U.S. share","Total intermediate inputs = SUM Z","Denominator","","aCA = I / L","aUS = J / L","Total intermediate / output","Household consumption of domestic output = D x (1-m)","gamma = Q / SUM Q","aCA + aUS"],h=95)
    for i in range(NS):
        r=5+i; col=CL(3+i)
        put(sc,f"A{r}",SECT[i]); put(sc,f"B{r}",NAICS[i])
        put(sc,f"C{r}",D['X'][i],BLUE,"#,##0"); put(sc,f"D{r}",D['H'][i],BLUE,"#,##0"); put(sc,f"E{r}",D['M'][i],BLUE,"#,##0"); put(sc,f"F{r}",D['MUS'][i],BLUE,"#,##0")
        put(sc,f"G{r}",f"=E{r}/(C{r}+E{r})",BLACK,"0.000"); put(sc,f"H{r}",f"=F{r}/(C{r}+E{r})",BLACK,"0.000")
        put(sc,f"I{r}",f"=SUMPRODUCT({col}$30:{col}$49,1-$G$5:$G$24)",BLACK,"#,##0")
        put(sc,f"J{r}",f"=SUMPRODUCT({col}$30:{col}$49,$H$5:$H$24)",BLACK,"#,##0")
        put(sc,f"K{r}",f"=SUM({col}$30:{col}$49)",BLACK,"#,##0")
        put(sc,f"L{r}",f'=IF(Inputs!$B$5="Total cost",C{r},K{r})',BLACK,"#,##0")
        put(sc,f"N{r}",f"=I{r}/L{r}",BLACK,"0.000"); put(sc,f"O{r}",f"=J{r}/L{r}",BLACK,"0.0000"); put(sc,f"P{r}",f"=K{r}/C{r}",BLACK,"0.000")
        put(sc,f"Q{r}",f"=D{r}*(1-G{r})",BLACK,"#,##0"); put(sc,f"R{r}",f"=Q{r}/SUM($Q$5:$Q$24)",BLACK,"0.000"); put(sc,f"S{r}",f"=N{r}+O{r}",BLACK,"0.000")
    put(sc,"A25","Total",BOLD)
    for c in "CDEFIJKQ": put(sc,f"{c}25",f"=SUM({c}5:{c}24)",BOLD,"#,##0")
    sc["A28"]="Z: intermediate use (rows = supplying sector, columns = using sector), C$ thousands"; sc["A28"].font=H2
    hdr(sc,29,["Supplying sector","NAICS"]+NAICS)
    for i in range(NS):
        r=30+i; put(sc,f"A{r}",SECT[i]); put(sc,f"B{r}",NAICS[i])
        for j in range(NS): put(sc,f"{CL(3+j)}{r}",D['Z'][i][j],BLUE,"#,##0")
    W(sc,{"A":34,"B":7,**{CL(3+j):12 for j in range(NS)},"M":2})

    # ---------------- StatCan_Goods
    sg=wb.create_sheet("StatCan_Goods"); sg["A1"]="U.S. imports by good (CEC section), Statistics Canada Table 36-10-0001-01, «IO» (C$ thousands)"; sg["A1"].font=TITLE
    note(sg,"A2","Detail industries mapped to the paper's 21 goods by NAICS (e.g. 331-332 base metals, 336 transport equipment, 325 chemicals, 311-312 food and beverages). Sections 3, 8, 12, 14, 18, 19, 21 are not separable in the input-output table and are zero.")
    hdr(sg,4,["#","Good","U.S. imports","Household purchases of U.S. imports (proportionality)","Share of total household consumption"],h=45)
    for j in range(NG):
        r=5+j; put(sg,f"A{r}",j+1,BLUE,"0"); put(sg,f"B{r}",GOODS[j],BLUE)
        put(sg,f"C{r}",D['MUS_g'][j],BLUE,"#,##0"); put(sg,f"D{r}",D['HUS_g'][j],BLUE,"#,##0"); put(sg,f"E{r}",f"=D{r}/$B$28",BLACK,"0.0000")
    put(sg,"A26","Total",BOLD); put(sg,"C26","=SUM(C5:C25)",BOLD,"#,##0"); put(sg,"D26","=SUM(D5:D25)",BOLD,"#,##0")
    put(sg,"A28","Total household final consumption expenditure (all products, domestic and imported)",BOLD); put(sg,"B28",D['Htot'],BLUE,"#,##0")
    note(sg,"A29","Check: column C total equals U.S. goods imports in StatCan_IO F25.")
    W(sg,{"A":5,"B":34,"C":16,"D":22,"E":16})

    # ---------------- CIMT_HS6 (product-level data)
    cm=wb.create_sheet("CIMT_HS6"); cm["A1"]="Canada's imports from the U.S., «TP», by 6-digit HS product (C$), with tariff-list flags"; cm["A1"].font=TITLE
    note(cm,"A2","Source: Statistics Canada CIMT annual import files (R9), imports, United States, HS6, «TP» («NM» months summed). Flags: 1 = at least one 8-digit tariff item of this HS6 is on the list (R3a-d). Section 0 = HS chapters 98-99 (special classifications), not one of the 21 goods.")
    hdr(cm,4,["HS6","Description","Section (1-21)","U.S. imports «TP» (C$)","Mar 4, 2025 list","Mar 13 steel","Mar 13 aluminum","Mar 13 other","Vehicles (HS 8703, 8704)","Sept 2026 rate (%)","Sept 2026 listed","Sept 2026 increase (pts)","Sept 2026: imports x increase (C$)","Sept 2026 rate class (for dampening)","HS chapter","Scenario: HS6 override rate (%) [input]","Scenario: rate on this product","Scenario: imports x rate (C$)","Scenario: dampening ratio at this rate","Scenario: imports x rate x ratio (C$)"],h=60)
    CM0=5
    for i,r in enumerate(CIM):
        rr=CM0+i
        cm.cell(row=rr,column=1,value=r['hs6']); cm.cell(row=rr,column=2,value=r['desc']); cm.cell(row=rr,column=3,value=r['section'])
        cm.cell(row=rr,column=4,value=round(r['value']))
        for j,k in enumerate(['mar4','steel','alum','other','veh']): cm.cell(row=rr,column=5+j,value=r[k])
        cm.cell(row=rr,column=10,value=r['sep_rate'])
        cm.cell(row=rr,column=11,value=f'=IF(J{rr}="",0,1)')
        cm.cell(row=rr,column=12,value=f'=IF(J{rr}="",0,IF(OR(F{rr}=1,G{rr}=1),MAX(0,J{rr}-25),J{rr}))')
        cm.cell(row=rr,column=13,value=f'=D{rr}*L{rr}/100')
        cm.cell(row=rr,column=14,value=f'=IF(L{rr}=0,"",IF(OR(F{rr}=1,G{rr}=1),"25to50",J{rr}&""))')
        cm.cell(row=rr,column=15,value=f'=LEFT(A{rr},2)')
        ov=SCEN["hs6"].get(r['hs6']) if SCEN else None
        c_=cm.cell(row=rr,column=16,value=ov); c_.fill=YEL; c_.font=BLUE
        cm.cell(row=rr,column=17,value=f'=IF(C{rr}=0,0,IF(P{rr}<>"",P{rr}/100,IFERROR(VLOOKUP(O{rr},Scenario!$A${SC0}:$H${SC1},8,FALSE),0)/100))')
        cm.cell(row=rr,column=18,value=f'=D{rr}*Q{rr}')
        k_=f'MATCH(Q{rr},Goods_Ratios!$D$3:$H$3,1)'
        GR_='Goods_Ratios!$D$5:$H$25'; RT_='Goods_Ratios!$D$3:$H$3'
        cm.cell(row=rr,column=19,value=(f'=IF(OR(C{rr}=0,Q{rr}<=0),0,IF(Q{rr}<=0.05,INDEX({GR_},C{rr},1),IF(Q{rr}>=0.5,INDEX({GR_},C{rr},5),'
            f'INDEX({GR_},C{rr},{k_})+(Q{rr}-INDEX({RT_},{k_}))*(INDEX({GR_},C{rr},{k_}+1)-INDEX({GR_},C{rr},{k_}))/(INDEX({RT_},{k_}+1)-INDEX({RT_},{k_})))))'))
        cm.cell(row=rr,column=20,value=f'=R{rr}*S{rr}')
    CM1=CM0+len(CIM)-1
    for col,fmt in [("D","#,##0"),("M","#,##0"),("Q","0.0%"),("R","#,##0"),("S","0.000"),("T","#,##0")]:
        for rr in range(CM0,CM1+1): cm[f"{col}{rr}"].number_format=fmt
    for rr in range(CM0,CM1+1):
        cm[f"A{rr}"].font=BLUE; cm[f"D{rr}"].font=BLUE
    put(cm,f"B{CM1+2}","Total",BOLD); put(cm,f"D{CM1+2}",f"=SUM(D{CM0}:D{CM1})",BOLD,"#,##0")
    cm.freeze_panes="C5"; cm.auto_filter.ref=f"A4:T{CM1}"
    W(cm,{"A":9,"B":60,"C":10,"D":16,"E":10,"F":10,"G":10,"H":10,"I":12,"J":11,"K":10,"L":11,"M":16,"N":14,"O":9,"P":14,"Q":12,"R":16,"S":12,"T":16})
    RD=f"CIMT_HS6!$D${CM0}:$D${CM1}"; RC=f"CIMT_HS6!$C${CM0}:$C${CM1}"; col=lambda c: f"CIMT_HS6!${c}${CM0}:${c}${CM1}"; ccol=col

    # ---------------- Tariff_Lists
    tl=wb.create_sheet("Tariff_Lists"); tl["A1"]="Official counter-tariff lists matched to imports from the U.S. («TP») (from CIMT_HS6)"; tl["A1"].font=TITLE
    note(tl,"A2","Matched = imports («TP») of the HS6 products flagged on the list (CIMT_HS6). A 6-digit product can include 8-digit items not on the list, so each list is scaled to its official value: scale = MIN(1, official / matched).")
    hdr(tl,4,["List","Tariff items (8-digit)","Official value (C$)","Matched imports (C$)","Scale factor","Rate","Flag column in CIMT_HS6","Source"],h=45)
    LL=[("March 4, 2025: C$30bn list",1258,30e9,"E","25%","E","R3a"),
        ("March 13, 2025: steel",None,12.6e9,"F","25%","F","R3b (539 items in total)"),
        ("March 13, 2025: aluminum",None,3.0e9,"G","25%","G","R3b"),
        ("March 13, 2025: other goods",None,14.2e9,"H","25%","H","R3b"),
        ("April 9, 2025: vehicles, pre-Sept 2025",None,"=96E9-SUM(C5:C8)","I","25%","I","R3c; value implied: C$96bn (R1, Table 2) less the lists above"),
        ("Vehicles, post-Sept 2025",None,"=50E9-C6-C7","I","25%","I","Implied: C$50bn (R1, Table 2) less steel and aluminum"),
        ("Sept 8, 2026 round",629,27.6e9,"K","15/25/50% by item","K, L","R3d; steel and aluminum items add 25 points (already at 25%)")]
    for i,(n,items,off,fc,rate,fl,src) in enumerate(LL):
        r=5+i; put(tl,f"A{r}",n); put(tl,f"B{r}",items,BLUE,"#,##0"); put(tl,f"C{r}",off,BLUE if not str(off).startswith("=") else BLACK,"#,##0")
        put(tl,f"D{r}",f"=SUMIFS({RD},{col(fc)},1)",GREEN,"#,##0"); put(tl,f"E{r}",f"=MIN(1,C{r}/D{r})",BLACK,"0.0000")
        put(tl,f"F{r}",rate); put(tl,f"G{r}",fl); put(tl,f"H{r}",src)
    note(tl,"A13","Scale factor below 1: the matched HS6 products include 8-digit items not on the list. Scale factor of 1: matched imports are below the official value (e.g. a different trade period), so the list is not scaled up.")
    W(tl,{"A":42,"B":12,"C":18,"D":20,"E":11,"F":16,"G":14,"H":56})

    # ---------------- Tariffs
    tf=wb.create_sheet("Tariffs"); tf["A1"]="Effective tariff change by good = tariff-weighted value of listed U.S. imports / all U.S. imports of that good («TP»)"; tf["A1"].font=TITLE
    note(tf,"A2","All columns are formulas on CIMT_HS6 and Tariff_Lists. Covered = SUM over lists of (matched imports of the good on that list x the list's scale factor).")
    hdr(tf,4,["#","Good (HS section)","U.S. imports «TP» (C$)","Covered, pre-Sept 2025 (C$)","Covered, post-Sept 2025 (C$)","Sept 2026: increase x covered (C$)"]+["Effective tariff: "+p for p in ["pre-Sept 2025","post-Sept 2025","Sept 2026 round","custom scenario"]]+["Dampening ratio: "+p for p in ["pre (25%)","post (25%)","Sept 2026 (mixed)","custom scenario (at each product's rate)"]]+["Dampened tariff: "+p for p in ["pre-Sept 2025","post-Sept 2025","Sept 2026 round","custom scenario"]],h=75)
    sm=lambda g,c: f"SUMIFS({RD},{RC},{g},{col(c)},1)"
    for j in range(NG):
        r=5+j; g=f"$A{r}"; put(tf,f"A{r}",j+1,BLUE,"0"); put(tf,f"B{r}",GOODS[j],BLUE)
        put(tf,f"C{r}",f"=SUMIFS({RD},{RC},{g})",GREEN,"#,##0")
        put(tf,f"D{r}",f"={sm(g,'E')}*Tariff_Lists!$E$5+{sm(g,'F')}*Tariff_Lists!$E$6+{sm(g,'G')}*Tariff_Lists!$E$7+{sm(g,'H')}*Tariff_Lists!$E$8+{sm(g,'I')}*Tariff_Lists!$E$9",GREEN,"#,##0")
        put(tf,f"E{r}",f"={sm(g,'F')}*Tariff_Lists!$E$6+{sm(g,'G')}*Tariff_Lists!$E$7+{sm(g,'I')}*Tariff_Lists!$E$10",GREEN,"#,##0")
        put(tf,f"F{r}",f"=SUMIFS({col('M')},{RC},{g})*Tariff_Lists!$E$11",GREEN,"#,##0")
        put(tf,f"G{r}",f"=IFERROR(0.25*D{r}/C{r},0)",BLACK,"0.0%"); put(tf,f"H{r}",f"=IFERROR(0.25*E{r}/C{r},0)",BLACK,"0.0%"); put(tf,f"I{r}",f"=IFERROR(F{r}/C{r},0)",BLACK,"0.0%")
        put(tf,f"J{r}",f"=IFERROR(SUMIFS({col('R')},{RC},{g})/C{r},0)",GREEN,"0.0%")
        put(tf,f"K{r}",f"=Goods_Ratios!G{r}",GREEN,"0.000"); put(tf,f"L{r}",f"=Goods_Ratios!G{r}",GREEN,"0.000")
        cls=lambda k: f'SUMIFS({col("M")},{RC},{g},{col("N")},"{k}")'
        put(tf,f"M{r}",f"=IFERROR(({cls('15')}*Goods_Ratios!F{r}+{cls('25')}*Goods_Ratios!G{r}+{cls('50')}*Goods_Ratios!H{r}+{cls('25to50')}*Goods_Ratios!I{r})/({cls('15')}+{cls('25')}+{cls('50')}+{cls('25to50')}),Goods_Ratios!G{r})",BLACK,"0.000")
        put(tf,f"N{r}",f"=IFERROR(SUMIFS({col('T')},{RC},{g})/SUMIFS({col('R')},{RC},{g}),Goods_Ratios!G{r})",GREEN,"0.000")
        for a,b,c in zip("GHIJ","KLMN","OPQR"): put(tf,f"{c}{r}",f"={a}{r}*{b}{r}",BLACK,"0.00%")
    put(tf,"B26","Total (21 goods)",BOLD)
    for c in "CDEF": put(tf,f"{c}26",f"=SUM({c}5:{c}25)",BOLD,"#,##0")
    put(tf,"B27","HS 98-99 special classifications (not used)",BLACK); put(tf,"C27",f"=SUMIFS({RD},{RC},0)",GREEN,"#,##0")
    note(tf,"A29","Covered totals equal the official values (C$96bn pre, C$50bn post) unless matched imports are smaller. Column J: the custom scenario set on the Scenario sheet (rates by HS chapter).")
    note(tf,"A30","Columns K-N: share of the tariff cost that reaches the good's price (R6 market model, Goods_Ratios). Sept 2026: weighted by imports x tariff increase within each rate class (CIMT_HS6 column N). Columns O-R = effective tariff x ratio; used in the dampened model.")
    for c,f in [("O","=SUMPRODUCT(C5:C25,O5:O25)/C26"),("P","=SUMPRODUCT(C5:C25,P5:P25)/C26"),("Q","=SUMPRODUCT(C5:C25,Q5:Q25)/C26"),("G","=SUMPRODUCT(C5:C25,G5:G25)/C26"),("H","=SUMPRODUCT(C5:C25,H5:H25)/C26"),("I","=SUMPRODUCT(C5:C25,I5:I25)/C26")]: put(tf,f"{c}28",f,BOLD,"0.00%")
    put(tf,"F28","Import-weighted average",BOLD)
    for c,a,b in [("K","O","G"),("L","P","H"),("M","Q","I")]: put(tf,f"{c}28",f"={a}28/{b}28",BOLD,"0.000")
    W(tf,{"A":5,"B":34,"C":16,"D":16,"E":16,"F":16,**{x:12 for x in "GHIJKLMNOPQR"}})

    # ---------------- Model
    md=wb.create_sheet("Model"); md["A1"]="Model: Leontief inverse and sector price changes"; md["A1"].font=TITLE
    note(md,"A2","Block 1: I - diag(aCA) x W_CA.  Block 2: L = MINVERSE(block 1).  Block 3: exposure = W_US x dtau; d = aUS x exposure; dp = L x d.")
    md["A4"]="1. I - A_CA"; md["A4"].font=H2
    for j in range(NS): md.cell(row=4,column=3+j,value=NAICS[j]).font=BOLD
    for i in range(NS):
        r=5+i; md.cell(row=r,column=1,value=SECT[i]).font=BLACK
        for j in range(NS): put(md,f"{CL(3+j)}{r}",f"={1 if i==j else 0}-Inputs!$D${19+i}*Omega_CA!{CL(3+j)}{r}",BLACK,"0.000")
    md["A28"]="2. Leontief inverse L"; md["A28"].font=H2
    for i in range(NS): md.cell(row=29+i,column=1,value=SECT[i]).font=BLACK
    md["C29"]=ArrayFormula("C29:V48","=MINVERSE(C5:V24)")
    for i in range(NS):
        for j in range(NS):
            c=md.cell(row=29+i,column=3+j); c.number_format="0.000"; c.border=BOX; c.font=BLACK
    md["A51"]="3. Sector price changes (fractions)"; md["A51"].font=H2
    labs=[f"{a}: {p}" for a in ["Exposure W_US x dtau","Direct d = aUS x exposure","Total dp = L x d"] for p in ["pre","post","Sept 2026","scenario"]]
    hdr(md,52,["Sector",""]+labs,h=60)
    for i in range(NS): md.cell(row=53+i,column=1,value=SECT[i]).font=BLACK
    md["C53"]=ArrayFormula("C53:F72","=MMULT(Omega_US!C5:W24,Tariffs!G5:J25)")
    md["K53"]=ArrayFormula("K53:N72","=MMULT(C29:V48,G53:J72)")
    for i in range(NS):
        r=53+i
        for k in range(4): put(md,f"{CL(7+k)}{r}",f"=Inputs!$C${19+i}*{CL(3+k)}{r}",BLACK,"0.0000")
        for col in list("CDEF")+list("KLMN"):
            c=md[f"{col}{r}"]; c.number_format="0.0000"; c.border=BOX; c.font=BLACK
    md["A75"]="4. Sector price changes with market dampening (tariffs x dampening ratio, Tariffs O-R)"; md["A75"].font=H2
    hdr(md,76,["Sector",""]+labs,h=60)
    for i in range(NS): md.cell(row=77+i,column=1,value=SECT[i]).font=BLACK
    md["C77"]=ArrayFormula("C77:F96","=MMULT(Omega_US!C5:W24,Tariffs!O5:R25)")
    md["K77"]=ArrayFormula("K77:N96","=MMULT(C29:V48,G77:J96)")
    for i in range(NS):
        r=77+i
        for k in range(4): put(md,f"{CL(7+k)}{r}",f"=Inputs!$C${19+i}*{CL(3+k)}{r}",BLACK,"0.0000")
        for col_ in list("CDEF")+list("KLMN"):
            c=md[f"{col_}{r}"]; c.number_format="0.0000"; c.border=BOX; c.font=BLACK
    W(md,{"A":34,"B":2,**{CL(3+j):9 for j in range(NS)}})

    # ---------------- Results
    # ---------------- Scenario (custom tariff rates by HS chapter)
    sn=wb.create_sheet("Scenario"); sn["A1"]="Scenario: set tariff rates on U.S. goods by HS chapter (2-digit)"; sn["A1"].font=TITLE
    for i_,t_ in enumerate(["How to use: type a rate (%) in column E for any chapter (yellow). Coverage (column F) is the share of the chapter's U.S. imports hit (100 = all products).",
                            "Optional: a rate in C6 applies to every chapter (leave blank to use column E). Single products: type a rate in T3_Trade_HS6 column P (overrides the chapter).",
                            "Results row 9 (Custom scenario) updates: full pass-through and dampened. Each product's dampening ratio is taken at its own rate (interpolated between 5, 10, 15, 25 and 50%; flat above 50%)."]):
        note(sn,f"A{3+i_}",t_)
    put(sn,"A6","Uniform rate for all chapters (%), optional",BOLD); put(sn,"C6",SCEN.get("uniform") if SCEN else None,BLUE,"0.0",YEL)
    put(sn,"A7","U.S. imports, 21 goods (C$)",BOLD); put(sn,"C7",f"=SUM(D{SC0}:D{SC1})",GREEN,"#,##0")
    put(sn,"A8","Tariff-weighted imports (C$)",BOLD); put(sn,"C8",f"=SUM(I{SC0}:I{SC1})",GREEN,"#,##0")
    put(sn,"A9","Average-tariff points (tariff-weighted imports / C$923bn total imports x 100)",BOLD); put(sn,"C9","=C8/923E9*100",BLACK,"0.00")
    put(sn,"E7","CPI effect, full pass-through (pp)",BOLD); put(sn,"H7","=Results!D9",GREEN,"0.00")
    put(sn,"E8","CPI effect, with dampening (pp)",BOLD); put(sn,"H8","=Results!G9",GREEN,"0.00",PatternFill("solid",fgColor="E2EFDA"))
    hdr(sn,SC0-1,["HS chapter","Description","Good (section)","U.S. imports (C$)","Rate (%) [input]","Coverage (%) [input]","Rate in use (%)","Effective rate on chapter (%) = rate x coverage","Tariff-weighted imports (C$, incl. HS6 overrides)","Effective tariff on chapter","Dampening ratio (weighted)"],h=60)
    for i_,(ch_,nm_) in enumerate(static.HS_CHAPTERS.items()):
        r_=SC0+i_; rt_,cv_=(SCEN["hs2"].get(ch_,(0.0,100.0)) if SCEN else (0.0,100.0))
        put(sn,f"A{r_}",ch_,BLUE); put(sn,f"B{r_}",nm_,BLUE); put(sn,f"C{r_}",static.hs_section(ch_+"0000"),BLUE,"0")
        put(sn,f"D{r_}",f'=SUMIFS({RD},{ccol("O")},A{r_})',GREEN,"#,##0")
        put(sn,f"E{r_}",rt_,BLUE,"0.0",YEL); put(sn,f"F{r_}",cv_,BLUE,"0",YEL)
        put(sn,f"G{r_}",f'=IF($C$6<>"",$C$6,E{r_})',BLACK,"0.0"); put(sn,f"H{r_}",f"=G{r_}*F{r_}/100",BLACK,"0.00")
        put(sn,f"I{r_}",f'=SUMIFS({ccol("R")},{ccol("O")},A{r_})',GREEN,"#,##0"); put(sn,f"J{r_}",f"=IFERROR(I{r_}/D{r_},0)",BLACK,"0.0%")
        put(sn,f"K{r_}",f'=IFERROR(SUMIFS({ccol("T")},{ccol("O")},A{r_})/I{r_},"")',BLACK,"0.000")
    sn.freeze_panes=f"C{SC0}"; W(sn,{"A":12,"B":38,"C":12,"D":16,"E":11,"F":11,"G":11,"H":16,"I":20,"J":12,"K":12})
    rs=wb.create_sheet("Results",1); rs["A1"]="Results: consumer-price effect of each tariff package (pp of the consumer price level)"; rs["A1"].font=TITLE
    note(rs,"A2","Full pass-through = R1 method (every tariff dollar reaches the importer's price). With dampening = tariffs first multiplied by the market model's dampening ratio (R6 method, Tariffs K-R). Paper values: R1, Table 2 (full pass-through).")
    put(rs,"A3","Specification in use",BOLD); put(rs,"B3",'=Inputs!B5&" shares; consumer channel "&Inputs!B6',GREEN)
    hdr(rs,5,["Package","Full pass-through: direct","Full: indirect","Full: total","With dampening: direct","Dampened: indirect","Dampened: total (recommended)","Dampened / full","Paper (R1): direct","Paper: indirect","Paper: total","Average-tariff points","pp per tariff point, dampened"],h=48)
    paper={0:(0.55,1.01,1.56),1:(0.24,0.48,0.72)}; pts={0:2.6,1:1.0,2:0.75,3:"=Scenario!C9"}
    for k in range(4):
        r=6+k; dc=CL(7+k); pc=CL(11+k); tc=CL(7+k); tq=CL(15+k)
        w='IF(Inputs!$B$6="Yes",Inputs!$B$15,1)'
        cons=lambda t: f'IF(Inputs!$B$6="Yes",SUMPRODUCT(StatCan_Goods!$E$5:$E$25,Tariffs!{t}5:{t}25),0)'
        put(rs,f"A{r}",PK[k])
        put(rs,f"B{r}",f"=({w}*SUMPRODUCT(Inputs!$B$19:$B$38,Model!{dc}53:{dc}72)+{cons(tc)})*100",GREEN,"0.00")
        put(rs,f"D{r}",f"=({w}*SUMPRODUCT(Inputs!$B$19:$B$38,Model!{pc}53:{pc}72)+{cons(tc)})*100",GREEN,"0.00")
        put(rs,f"C{r}",f"=D{r}-B{r}",BLACK,"0.00")
        put(rs,f"E{r}",f"=({w}*SUMPRODUCT(Inputs!$B$19:$B$38,Model!{dc}77:{dc}96)+{cons(tq)})*100",GREEN,"0.00")
        put(rs,f"G{r}",f"=({w}*SUMPRODUCT(Inputs!$B$19:$B$38,Model!{pc}77:{pc}96)+{cons(tq)})*100",GREEN,"0.00",PatternFill("solid",fgColor="E2EFDA"))
        rs[f"G{r}"].font=Font(name=F,bold=True,color="008000")
        put(rs,f"F{r}",f"=G{r}-E{r}",BLACK,"0.00"); put(rs,f"H{r}",f'=IF(D{r}=0,"",G{r}/D{r})',BLACK,"0.000")
        if k in paper:
            for c,v in zip("IJK",paper[k]): put(rs,f"{c}{r}",v,BLUE,"0.00")
        else:
            for c in "IJK": put(rs,f"{c}{r}","n/a")
        put(rs,f"L{r}",pts[k],GREEN if k==3 else BLUE,"0.00",YEL if k==2 else None)
        put(rs,f"M{r}",f'=IF(OR(L{r}="",L{r}=0),"",G{r}/L{r})',BLACK,"0.00")
    note(rs,"A10","Average-tariff points: 2.6 and 1.0 from BoC MPR October 2025 (R5); 0.75 for the Sept 2026 round (C$27.6bn x 25% / C$923bn x 100). Paper values are full pass-through; R6 Section 5 gives about 0.53 for the share reaching prices at 25%.")
    rs["A12"]="All four specifications (computed when the workbook was built)"; rs["A12"].font=H2
    hdr(rs,13,["Cost-share denominator / consumer channel","Full: pre total","Full: post total","Full: Sept 2026 total","Dampened: pre total","Dampened: post total","Dampened: Sept 2026 total"],h=30)
    for i,key in enumerate(["Intermediate inputs|Yes","Intermediate inputs|No","Total cost|Yes","Total cost|No"]):
        r=14+i; b,cn=key.split("|"); put(rs,f"A{r}",f"{b} / consumer channel {cn}"+(" (default)" if i==0 else ""))
        for j,v in enumerate(SPEC2[key]): put(rs,f"{CL(2+j)}{r}",v,BLUE,"0.00")
    put(rs,"A18","Paper (R1, Table 2), full pass-through",BOLD)
    for j,v in enumerate([1.56,0.72,"n/a"]): put(rs,f"{CL(2+j)}18",v,BLUE,"0.00")
    note(rs,"A19","Computed in Python by the same model when the workbook was built (run.py). Change Inputs B5 and B6 to switch the live results above.")
    rs["A21"]="Sector price changes (%)"; rs["A21"].font=H2
    hdr(rs,22,["Sector","Consumption weight","aUS","aCA"]+["Full: "+p for p in ["pre","post","Sept 2026","scenario"]]+["Dampened: "+p for p in ["pre","post","Sept 2026","scenario"]],h=30)
    for i in range(NS):
        r=23+i; put(rs,f"A{r}",SECT[i]); put(rs,f"B{r}",f"=Inputs!B{19+i}",GREEN,"0.000"); put(rs,f"C{r}",f"=Inputs!C{19+i}",GREEN,"0.000"); put(rs,f"D{r}",f"=Inputs!D{19+i}",GREEN,"0.000")
        for k in range(4):
            put(rs,f"{CL(5+k)}{r}",f"=Model!{CL(11+k)}{53+i}*100",GREEN,"0.00"); put(rs,f"{CL(9+k)}{r}",f"=Model!{CL(11+k)}{77+i}*100",GREEN,"0.00")
    rs["A45"]="Dampening ratios by good (from Tariffs K-M)"; rs["A45"].font=H2
    hdr(rs,46,["Good","U.S. imports «TP» (C$bn)","Ratio: pre / post (25%)","Ratio: Sept 2026 round"],h=30)
    for j in range(NG):
        r=47+j; put(rs,f"A{r}",f"=Tariffs!B{5+j}",GREEN); put(rs,f"B{r}",f"=Tariffs!C{5+j}/1E9",GREEN,"0.0"); put(rs,f"C{r}",f"=Tariffs!K{5+j}",GREEN,"0.000"); put(rs,f"D{r}",f"=Tariffs!M{5+j}",GREEN,"0.000")
    W(rs,{"A":46,**{x:13 for x in "BCDEFGHIJKLM"}})

    # ---------------- Checks
    ck=wb.create_sheet("Checks"); ck["A1"]="Checks"; ck["A1"].font=TITLE
    hdr(ck,3,["#","Test","Value","Result"])
    CK=[("1","Table 1 rows sum to 1 (largest deviation)","=MAX(ABS(MAX(Omega_US!X5:X24)-1),ABS(MIN(Omega_US!X5:X24)-1))",'=IF(C4<=0.03,"PASS","REVIEW")'),
        ("2","Table A1 rows sum to 1 (largest deviation)","=MAX(ABS(MAX(Omega_CA!W5:W24)-1),ABS(MIN(Omega_CA!W5:W24)-1))",'=IF(C5<=0.03,"PASS","REVIEW")'),
        ("3","Intermediate inputs below output in every sector (largest ratio)","=MAX(StatCan_IO!P5:P24)",'=IF(C6<1,"PASS","REVIEW")'),
        ("4","U.S. goods imports by good = by sector (difference, C$ thousands)","=StatCan_Goods!C26-StatCan_IO!F25",'=IF(ABS(C7)<=10,"PASS","REVIEW")'),
        ("5","Largest sector aCA + aUS below 1 (network converges)","=MAX(StatCan_IO!S5:S24)",'=IF(C8<1,"PASS","REVIEW")'),
        ("6","Leontief inverse non-negative (smallest element)","=MIN(Model!C29:V48)",'=IF(C9>=-0.000001,"PASS","REVIEW")'),
        ("7","Consumption weights sum to 1","=SUM(Inputs!B19:B38)",'=IF(ABS(C10-1)<0.000001,"PASS","REVIEW")'),
        ("8","INFO: full pass-through model / paper, pre-Sept total","=Results!D6/Results!K6",'="INFO"'),
        ("10","Covered imports equal official package values, capped at matched imports (C$bn: pre + post)","=Tariffs!D26/1E9+Tariffs!E26/1E9",f'=IF(ABS(C12-{COVERED_EXPECTED:.6f})<0.01,"PASS","REVIEW")'),
        ("11","CIMT_HS6 total = 21 goods + HS 98-99 (difference, C$)",f"=CIMT_HS6!D{5+len(CIM)+1}-Tariffs!C26-Tariffs!C27",'=IF(ABS(C13)<1,"PASS","REVIEW")'),
        ("9","INFO: full pass-through model / paper, post-Sept total","=Results!D7/Results!K7",'="INFO"'),
        ("12","Market model converged (largest change in last iteration, all Mkt_Solve sheets)","=Mkt_Validation!B20",'=IF(C15<0.000001,"PASS","REVIEW")'),
        ("13","Dampening ratios between 0 and 1.5 (all goods, packages)","=MAX(Tariffs!K5:N25)",'=IF(AND(C16<1.5,MIN(Tariffs!K5:N25)>0),"PASS","REVIEW")'),
        ("14","Dampened total below full total (pre-Sept)","=Results!G6-Results!D6",'=IF(C17<0,"PASS","REVIEW")'),
        ("15","INFO: market model vs R6 Table F.1, correlation of industry results at 25%","=Mkt_Validation!B14",'="INFO"'),
        ("16","INFO: market model vs R6 Table 3, ratio at 25% (model minus paper)","=Mkt_Validation!H8",'="INFO"')]
    for i,(n,t,v,res) in enumerate(CK):
        r=4+i; put(ck,f"A{r}",n); put(ck,f"B{r}",t); put(ck,f"C{r}",v,GREEN,"0.000"); put(ck,f"D{r}",res,BOLD)
    W(ck,{"A":4,"B":68,"C":12,"D":12})

    # ---------------- References
    rf=wb.create_sheet("References"); rf["A1"]="References"; rf["A1"].font=TITLE
    hdr(rf,3,["Code","Reference","Used for","Link"])
    REFS=[("R1","Bustamante et al. (2026), 'The Production Network Amplification of Retaliatory Tariffs', BoC Staff Working Paper 2026-35.","Eq. 2-5; Section 2.2; Table 1 (W_US); Table A1 (W_CA); Table 2; Section 4.2.","https://www.bankofcanada.ca/2026/10/staff-working-paper-2026-35/"),
    ("R2","Statistics Canada, Table 36-10-0001-01, 'Input-output tables, detail level' («IO», basic prices). DOI 10.25318/3610000101-eng.","StatCan_IO and StatCan_Goods: output, intermediate use, household consumption, imports by partner.","https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=3610000101"),
    ("R3d","Department of Finance Canada (2026), 'List of products from the United States subject to counter-tariffs effective September 8, 2026'.","Sept 8, 2026 list (R3d): 629 lines at 15/25/50%.","https://www.canada.ca/en/department-finance/news/2026/08/list-of-products-from-the-united-states-subject-to-counter-tariffs-effective-september-8-2026.html"),
    ("R3a","Department of Finance Canada (2025), 'List of products from the United States subject to 25 per cent tariffs effective March 4, 2025'.","March 4, 2025 list (1,258 lines).","https://www.canada.ca/en/department-finance/news/2025/03/list-of-products-from-the-united-states-subject-to-25-per-cent-tariffs-effective-march-4-2025.html"),
    ("R3b","Department of Finance Canada (2025), 'List of products from the United States subject to 25 per cent tariffs effective March 13, 2025'.","Steel, aluminum and other goods (539 lines).","https://www.canada.ca/en/department-finance/news/2025/03/list-of-products-from-the-united-states-subject-to-25-per-cent-tariffs-effective-march-13-2025.html"),
    ("R3c","Department of Finance Canada (2025), 'Canada announces entry into force of countermeasures against auto imports from the United States', April 8, 2025.","Vehicle counter-tariffs.","https://www.canada.ca/en/department-finance/news/2025/04/canada-announces-entry-into-force-of-countermeasures-against-auto-imports-from-the-united-states.html"),
    ("R9","Statistics Canada, Canadian International Merchandise Trade Web Application (71-607-X2021004).","Imports from the U.S. by 6-digit HS, «TP».","https://www150.statcan.gc.ca/n1/en/catalogue/71-607-X2021004"),
    ("R5","Bank of Canada, MPR October 2025, 'Tariff and other assumptions', Table 1.","Average tariff 2.6% (July 2025) and 1.0% (October 2025).","https://www.bankofcanada.ca/publications/mpr/mpr-2025-10-29/section-8/"),
    ("R6","Bustamante et al. (2026), 'How Do Import Tariffs Affect Aggregate Prices? Theory and Evidence from Canada', BoC Staff Working Paper 2026-36.","Market model (Eq. 2.1-3.5), sigma and rho, Table 1 weights, Table 3 and Table F.1 (Mkt_ sheets).","https://www.bankofcanada.ca/2026/10/staff-working-paper-2026-36/"),
    ("R10","U.S. Census Bureau (2023), 'A Profile of U.S. Importing and Exporting Companies, 2021-2022', Table 1a.","Size distribution of U.S. export value by employment size (Mkt_Inputs).","https://www.census.gov/foreign-trade/Press-Release/edb/edbrel2022.pdf"),
    ("R11","Edmond, C., V. Midrigan and D. Y. Xu (2015), 'Competition, Markups, and the Gains from International Trade', American Economic Review 105(10): 3183-3221.","Source of sigma and rho used by R6.","https://doi.org/10.1257/aer.20120549"),
    ("R12","Atkeson, A. and A. Burstein (2008), 'Pricing-to-Market, Trade Costs, and International Relative Prices', American Economic Review 98(5): 1998-2031.","Oligopoly markup structure (R6).","https://doi.org/10.1257/aer.98.5.1998"),
    ("R8","Johnson, R. C. and G. Noguera (2012), 'Accounting for intermediates: Production sharing and trade in value added', Journal of International Economics 86(2): 224-236.","Import proportionality assumption.","https://doi.org/10.1016/j.jinteco.2011.10.003")]
    for i,row in enumerate(REFS):
        r=4+i
        for j,v in enumerate(row):
            c=rf.cell(row=r,column=1+j,value=v); c.font=BLACK; c.alignment=WRAP; c.border=BOX
        rf.cell(row=r,column=4).hyperlink=row[3]; rf.cell(row=r,column=4).font=Font(name=F,color="1F5FA8",underline="single")
    note(rf,"A20","Built «DL» by tariff_price_model (run.py): input-output year «IO», trade period «TP». Tables 1 and A1 were transcribed from the PDF by text extraction (row sums check out). Staff papers are the authors' views, not official BoC positions.")
    W(rf,{"A":6,"B":70,"C":60,"D":60})

    # ---------------- Inputs
    ip=wb.create_sheet("Mkt_Inputs"); ip["A1"]="Inputs"; ip["A1"].font=TITLE
    hdr(ip,3,["Parameter","Value","Source / note"])
    P=[(5,"sigma: substitution between firms within an industry",10.5,"0.00",None,"R6 Section 3.2 (from Edmond, Midrigan and Xu, 2015)."),
       (6,"rho: substitution across industries",1.24,"0.00",None,"R6 Section 3.2."),
       (8,"N: number of equivalent Canadian firms per industry (calibrated)",round(N_CAL,3),"0.00",YEL,"Fitted to R6 Table F.1 at 25% (Calibration sheet). Not published in R6."),
       (9,"Damping in the iteration",0.5,"0.00",None,"Numerical setting; 50 iterations converge to within 1e-12."),
       (11,"Size distribution of U.S. and rest-of-world firms (share of export value)",None,None,None,None)]
    for row,lab,v,fmt,fill,nt in P:
        ip.cell(row=row,column=1,value=lab).font=BLACK if v is not None else H2
        if v is not None: put(ip,f"B{row}",v,BLUE,fmt,fill); c=ip.cell(row=row,column=3,value=nt); c.font=NOTE; c.alignment=WRAP
    SZ=[("Unknown employment or 1-19 employees",12.1+5.1),("20-99 employees",2.9+2.8),("100-249 employees",6.2),("250-499 employees",6.7),("500 or more employees",64.3)]
    hdr(ip,12,["Size class","Share of known U.S. export value (%)","Normalized share"])
    for i,(n,v) in enumerate(SZ):
        r=13+i; put(ip,f"A{r}",n); put(ip,f"B{r}",v,BLUE,"0.0"); put(ip,f"C{r}",f"=B{r}/SUM($B$13:$B$17)",BLACK,"0.0000")
    note(ip,"A18","R10: U.S. Census Bureau, A Profile of U.S. Importing and Exporting Companies, 2021-2022, Table 1a (2022 exports by employment size). Grouped into five classes because R6 uses five size groups per origin; the same distribution is used for rest-of-world firms (R6 does the same).")
    W(ip,{"A":62,"B":20,"C":80})

    # ---------------- Mkt_Industry
    idt=wb.create_sheet("Mkt_Industry"); idt["A1"]="Industry data: R6 Table F.1 (25% tariff) and rest-of-world import shares"; idt["A1"].font=TITLE
    note(idt,"A2","Columns C-H transcribed from R6 Table F.1. Rest-of-world/U.S. import ratio from Statistics Canada Table 36-10-0001-01 («IO»): (total imports - U.S. imports) / U.S. imports for the sector's products (R2).")
    hdr(idt,4,["NAICS","Industry","U.S. share (%)","Paper: exact price change (%)","Paper: first-order (%)","Paper: markup part (%)","Paper: cost part (%)","2-digit sector","Rest-of-world / U.S. import ratio","Rest-of-world share","Canadian share","Paper ratio: exact / cost"],h=48)
    for i,(n,name,us,ex,fo,mk_,cost) in enumerate(F1):
        r=R0+i; two=str(n)[:2]
        put(idt,f"A{r}",n,BLUE,"0"); put(idt,f"B{r}",name,BLUE)
        for c,v in zip("CDEFG",(us,ex,fo,mk_,cost)): put(idt,f"{c}{r}",v,BLUE,"0.00")
        put(idt,f"H{r}",two,BLUE)
        put(idt,f"I{r}",f"=VLOOKUP(H{r},$O$5:$P$11,2,FALSE)",BLACK,"0.000")
        put(idt,f"J{r}",f"=MIN(I{r}*C{r}/100,0.9*(1-C{r}/100))",BLACK,"0.0000")
        put(idt,f"K{r}",f"=1-C{r}/100-J{r}",BLACK,"0.0000")
        put(idt,f"L{r}",f'=IF(G{r}>0,D{r}/G{r},"")',BLACK,"0.000")
    hdr(idt,4,["2-digit","ROW/US ratio","Statistics Canada basis"],col=15)
    SRC={'11':(0,'Agriculture: total vs U.S. imports'),'21':(1,'Mining'),'22':(2,'Utilities'),'31':(4,'Manufacturing'),'32':(4,'Manufacturing'),'33':(4,'Manufacturing'),'41':(4,'Wholesale: manufacturing ratio (wholesalers import manufactured goods)')}
    for i,(k,(idx,lab)) in enumerate(SRC.items()):
        r=5+i; put(idt,f"O{r}",k,BLUE); put(idt,f"P{r}",f"=({D['M'][idx]}-{D['MUS'][idx]})/{D['MUS'][idx]}",BLACK,"0.000"); put(idt,f"Q{r}",lab)
    W(idt,{"A":8,"B":30,"C":10,"D":12,"E":11,"F":11,"G":10,"H":9,"I":12,"J":12,"K":10,"L":12,"O":8,"P":12,"Q":56})

    # ---------------- Firms
    fm=wb.create_sheet("Mkt_Firms"); fm["A1"]="Firms: 11 firm types per industry (5 U.S., 5 rest-of-world, 1 Canadian type with N firms)"; fm["A1"].font=TITLE
    note(fm,"A2","Initial share per firm w0, number of firms n, U.S. flag, pre-tariff price p0 = w0^(1/(1-sigma)) (industry index normalized to 1), markup mu0, marginal cost c = p0/mu0 (R6 Eq. 3.3-3.4).")
    types=[f"US{k+1}" for k in range(5)]+[f"ROW{k+1}" for k in range(5)]+["CA"]
    blk=lambda b: [CL(3+b*NT+j) for j in range(NT)]   # b: 0 w0, 1 n, 2 usflag, 3 c
    labels=["NAICS","Industry"]+[f"w0 {t}" for t in types]+[f"n {t}" for t in types]+[f"US? {t}" for t in types]+[f"cost {t}" for t in types]
    hdr(fm,4,labels,h=40)
    MU=lambda w: f"(1/(1-(({w})/Mkt_Inputs!$B$6+(1-({w}))/Mkt_Inputs!$B$5)))"
    for i in range(NI):
        r=R0+i; put(fm,f"A{r}",f"=Mkt_Industry!A{r}",GREEN,"0"); put(fm,f"B{r}",f"=Mkt_Industry!B{r}",GREEN)
        for j in range(NT):
            w,nn,us,cc=(blk(b)[j] for b in range(4))
            if j<5: put(fm,f"{w}{r}",f"=Mkt_Industry!$C{r}/100*Mkt_Inputs!$C${13+j}",BLACK,"0.000000")
            elif j<10: put(fm,f"{w}{r}",f"=Mkt_Industry!$J{r}*Mkt_Inputs!$C${13+j-5}",BLACK,"0.000000")
            else: put(fm,f"{w}{r}",f"=Mkt_Industry!$K{r}/Mkt_Inputs!$B$8",BLACK,"0.000000")
            put(fm,f"{nn}{r}",1 if j<10 else "=Mkt_Inputs!$B$8",BLUE if j<10 else GREEN,"0.00")
            put(fm,f"{us}{r}",1 if j<5 else 0,BLUE,"0")
            put(fm,f"{cc}{r}",f"={w}{r}^(1/(1-Mkt_Inputs!$B$5))/{MU(f'{w}{r}')}",BLACK,"0.000000")
    W(fm,{"A":8,"B":28}); fm.freeze_panes="C5"

    # ---------------- Solve sheets
    def solve_sheet(tau):
        nm=f"Mkt_Solve_{int(round(tau*100))}"; ws=wb.create_sheet(nm)
        ws["A1"]=f"Equilibrium with a {int(round(tau*100))}% tariff on U.S. firms: 50 iterations of w_next = (1-d) w + d x (mu(w) c)^(1-sigma) / SUM n (mu(w) c)^(1-sigma)"; ws["A1"].font=TITLE
        put(ws,"A2","Tariff rate",BOLD); put(ws,"B2",tau,BLUE,"0%")
        cT=[CL(3+j) for j in range(NT)]; nC=[CL(3+NT+j) for j in range(NT)]
        it0=3+2*NT
        hdr(ws,4,["NAICS","Industry"]+[f"cost after tariff {t}" for t in types]+[f"n {t}" for t in types],h=40)
        for k in range(NIT+1):
            for j in range(NT): ws.cell(row=4,column=it0+k*NT+j,value=f"it{k} {types[j]}").font=BOLD
        fw,fn,fu,fc=(blk(b) for b in range(4))
        for i in range(NI):
            r=R0+i; put(ws,f"A{r}",f"=Mkt_Firms!A{r}",GREEN,"0"); put(ws,f"B{r}",f"=Mkt_Firms!B{r}",GREEN)
            for j in range(NT):
                put(ws,f"{cT[j]}{r}",f"=Mkt_Firms!{fc[j]}{r}*(1+$B$2*Mkt_Firms!{fu[j]}{r})",GREEN,"0.000000")
                put(ws,f"{nC[j]}{r}",f"=Mkt_Firms!{fn[j]}{r}",GREEN,"0.00")
            for j in range(NT):
                ws.cell(row=r,column=it0+j,value=f"=Mkt_Firms!{fw[j]}{r}").font=GREEN
            for k in range(1,NIT+1):
                prev=[CL(it0+(k-1)*NT+j) for j in range(NT)]
                pr=f"{prev[0]}{r}:{prev[-1]}{r}"
                den=f"SUMPRODUCT(${nC[0]}{r}:${nC[-1]}{r},({MU(pr)}*${cT[0]}{r}:${cT[-1]}{r})^(1-Mkt_Inputs!$B$5))"
                for j in range(NT):
                    pj=f"{prev[j]}{r}"
                    ws.cell(row=r,column=it0+k*NT+j,value=f"=(1-Mkt_Inputs!$B$9)*{pj}+Mkt_Inputs!$B$9*({MU(pj)}*${cT[j]}{r})^(1-Mkt_Inputs!$B$5)/{den}")
        last=[CL(it0+NIT*NT+j) for j in range(NT)]; pl=[CL(it0+(NIT-1)*NT+j) for j in range(NT)]
        oc=it0+(NIT+1)*NT+1; O=[CL(oc+x) for x in range(5)]
        hdr(ws,4,["Exact price change (%)","Cost term (%)","Markup term (%)","Ratio exact / cost","Convergence (max change)"],col=oc,h=40)
        for i in range(NI):
            r=R0+i; L=f"{last[0]}{r}:{last[-1]}{r}"
            put(ws,f"{O[0]}{r}",f"=LN(SUMPRODUCT(${nC[0]}{r}:${nC[-1]}{r},({MU(L)}*${cT[0]}{r}:${cT[-1]}{r})^(1-Mkt_Inputs!$B$5))^(1/(1-Mkt_Inputs!$B$5)))*100",BLACK,"0.000")
            put(ws,f"{O[1]}{r}",f"=Mkt_Industry!C{r}/100*LN(1+$B$2)*100",GREEN,"0.000")
            put(ws,f"{O[2]}{r}",f"=SUMPRODUCT(${nC[0]}{r}:${nC[-1]}{r},Mkt_Firms!{fw[0]}{r}:{fw[-1]}{r},LN({MU(L)})-LN({MU(f'Mkt_Firms!{fw[0]}{r}:{fw[-1]}{r}')}))*100",BLACK,"0.000")
            put(ws,f"{O[3]}{r}",f'=IF({O[1]}{r}>0,{O[0]}{r}/{O[1]}{r},"")',BLACK,"0.000")
            put(ws,f"{O[4]}{r}",f"=MAX(ABS({last[0]}{r}-{pl[0]}{r}),ABS({last[4]}{r}-{pl[4]}{r}),ABS({last[-1]}{r}-{pl[-1]}{r}))",BLACK,"0.0E+00")
        W(ws,{"A":8,"B":28}); ws.freeze_panes="C5"
        return nm,O
    SOL={}
    for t in RATES: SOL[t]=solve_sheet(t)

    # ---------------- Results
    rs=wb.create_sheet("Mkt_Results"); rs["A1"]="Results: actual price effect vs full cost pass-through, by industry"; rs["A1"].font=TITLE
    note(rs,"A2","Exact = change in the industry price index (%). Ratio = exact / cost term = share of the tariff cost that reaches prices (dampening ratio). Paper values from R6 Table F.1 (25%).")
    hdr(rs,4,["NAICS","Industry","U.S. share (%)"]+[f"Exact, {int(t*100)}%" for t in RATES]+[f"Ratio, {int(t*100)}%" for t in RATES]+["Markup term, 25%","Paper: exact, 25%","Paper: ratio, 25%","Paper: markup, 25%"],h=40)
    for i in range(NI):
        r=R0+i; put(rs,f"A{r}",f"=Mkt_Industry!A{r}",GREEN,"0"); put(rs,f"B{r}",f"=Mkt_Industry!B{r}",GREEN); put(rs,f"C{r}",f"=Mkt_Industry!C{r}",GREEN,"0.00")
        for k,t in enumerate(RATES):
            nm,O=SOL[t]; put(rs,f"{CL(4+k)}{r}",f"={nm}!{O[0]}{r}",GREEN,"0.00"); put(rs,f"{CL(9+k)}{r}",f"={nm}!{O[3]}{r}",GREEN,"0.000")
        nm,O=SOL[0.25]; put(rs,f"N{r}",f"={nm}!{O[2]}{r}",GREEN,"0.00")
        put(rs,f"O{r}",f"=Mkt_Industry!D{r}",GREEN,"0.00"); put(rs,f"P{r}",f"=Mkt_Industry!L{r}",GREEN,"0.000"); put(rs,f"Q{r}",f"=Mkt_Industry!F{r}",GREEN,"0.00")
    W(rs,{"A":8,"B":30,**{CL(c):11 for c in range(3,18)}})
    ch=ScatterChart(); ch.title="Exact price change at 25%: model vs paper (Table F.1)"; ch.x_axis.title="Paper (%)"; ch.y_axis.title="Model (%)"; ch.height=9; ch.width=14
    s=Series(Reference(rs,min_col=7,min_row=R0,max_row=RL),Reference(rs,min_col=15,min_row=R0,max_row=RL),title="Industries"); s.marker.symbol="circle"; s.graphicalProperties.line.noFill=True; ch.series.append(s)
    rs.add_chart(ch,"S4")

    # ---------------- Validation
    vl=wb.create_sheet("Mkt_Validation"); vl["A1"]="Validation against R6"; vl["A1"].font=TITLE
    vl["A3"]="1. Aggregate results by tariff rate (R6 Table 3), not used in calibration (except 25%)"; vl["A3"].font=H2
    note(vl,"A4","Aggregate = SUM(industry weight x industry result). Weights: R6 Table 1 expenditure weight of each 2-digit sector, split equally across its 3-digit industries (R6 does not publish 3-digit weights).")
    hdr(vl,5,["Tariff","Model: exact (%)","Model: cost (%)","Model: ratio","Paper: exact (%)","Paper: cost (%)","Paper: ratio","Model ratio - paper ratio"],h=32)
    T3={0.05:(0.20,0.27),0.10:(0.36,0.53),0.25:(0.66,1.25),0.50:(0.88,2.28)}
    hdr(vl,5,["2-digit","Table 1 weight (%)","Industries","Weight per industry (%)"],col=11)
    for i,(k,wt) in enumerate({'11':0.68,'21':5.91,'22':0.67,'31':3.28,'32':5.54,'33':10.18,'41':16.36}.items()):
        r=6+i; put(vl,f"K{r}",k,BLUE); put(vl,f"L{r}",wt,BLUE,"0.00"); put(vl,f"M{r}",f'=COUNTIF(Mkt_Industry!$H$5:$H${RL},K{r})',BLACK,"0"); put(vl,f"N{r}",f"=L{r}/M{r}",BLACK,"0.000")
    put(vl,"K13","Weight used for each industry: Mkt_Industry H -> this table.",NOTE,box=False)
    for i,t in enumerate([0.05,0.10,0.25,0.50]):
        r=6+i; nm,O=SOL[t]
        wv=f"SUMIF($K$6:$K$12,Mkt_Industry!$H$5:$H${RL},$N$6:$N$12)"
        put(vl,f"A{r}",t,BLUE,"0%")
        put(vl,f"B{r}",f"=SUMPRODUCT({wv},{nm}!{O[0]}5:{O[0]}{RL})/100",BLACK,"0.000")
        put(vl,f"C{r}",f"=SUMPRODUCT({wv},{nm}!{O[1]}5:{O[1]}{RL})/100",BLACK,"0.000")
        put(vl,f"D{r}",f"=B{r}/C{r}",BLACK,"0.000")
        put(vl,f"E{r}",T3[t][0],BLUE,"0.00"); put(vl,f"F{r}",T3[t][1],BLUE,"0.00"); put(vl,f"G{r}",f"=E{r}/F{r}",BLACK,"0.000"); put(vl,f"H{r}",f"=D{r}-G{r}",BLACK,"+0.000;-0.000")
    vl["A12"]="2. Industry results at 25% (R6 Table F.1), the calibration target"; vl["A12"].font=H2
    hdr(vl,13,["Statistic","Value"])
    ST=[("Correlation, exact: model vs paper",f"=CORREL(Mkt_Results!G5:G{RL},Mkt_Results!O5:O{RL})","0.000"),
        ("Sum of exact effects: model",f"=SUM(Mkt_Results!G5:G{RL})","0.00"),("Sum of exact effects: paper",f"=SUM(Mkt_Results!O5:O{RL})","0.00"),
        ("Correlation, markup term: model vs paper",f"=CORREL(Mkt_Results!N5:N{RL},Mkt_Results!Q5:Q{RL})","0.000"),
        ("Median ratio, model (industries with paper exact > 0.3%)",f'=MEDIAN(IF(Mkt_Results!O5:O{RL}>0.3,Mkt_Results!L5:L{RL}))',"0.000"),
        ("Median ratio, paper (same industries)",f'=MEDIAN(IF(Mkt_Results!O5:O{RL}>0.3,Mkt_Results!P5:P{RL}))',"0.000"),
        ("Largest convergence error, all sheets","=MAX("+",".join(f"{SOL[t][0]}!{SOL[t][1][4]}5:{SOL[t][1][4]}{RL}" for t in RATES)+")","0.0E+00")]
    for i,(lab,f,fmt) in enumerate(ST):
        r=14+i; put(vl,f"A{r}",lab)
        if "MEDIAN(IF" in f: vl[f"B{r}"]=ArrayFormula(f"B{r}",f); vl[f"B{r}"].number_format=fmt; vl[f"B{r}"].border=BOX
        else: put(vl,f"B{r}",f,BLACK,fmt)
    W(vl,{"A":52,"B":14,"C":14,"D":14,"E":14,"F":14,"G":14,"H":16,"K":10,"L":14,"M":10,"N":14})

    # ---------------- Calibration
    cb=wb.create_sheet("Mkt_Calibration"); cb["A1"]="Calibration of N (number of equivalent Canadian firms)"; cb["A1"].font=TITLE
    rowsC=[("What is calibrated","Only N (Mkt_Inputs B8). R6 uses Canadian firm data (NALMF) that is not public and does not report the number of Canadian firms per industry."),
    ("Target","Sum of squared differences between model and paper exact price changes at 25%, over R6's 32 industries (Table F.1)."),
    ("Result","N = «N» minimizes the target. To re-check, change Mkt_Inputs B8 and watch B8 below, or run Excel Solver: minimize Mkt_Calibration!B8 by changing Mkt_Inputs!B8. The table at right shows the target at other N."),
    ("Why it matters","With few Canadian firms (N = 3-5), they are large, gain share when U.S. prices rise and raise markups, offsetting U.S. markup cuts; effects come out about 40-75% above the paper. With N around 16-20 the model matches the paper's industry pattern and its aggregate results at other tariff rates.")]
    for i,(a,b) in enumerate(rowsC):
        r=3+i; cb.cell(row=r,column=1,value=a).font=BOLD; c=cb.cell(row=r,column=2,value=b); cb.row_dimensions[r].height=32; c.font=BLACK; c.alignment=WRAP
    put(cb,"A8","Sum of squared differences at the current N",BOLD); put(cb,"B8",f"=SUMXMY2(Mkt_Results!G5:G{RL},Mkt_Results!O5:O{RL})",BLACK,"0.000")
    hdr(cb,10,["N","Sum of squared differences (same model run in Python at each N)"],col=4)
    G=GRID
    for i,(k,v) in enumerate(G.items()):
        put(cb,f"D{11+i}",float(k),BLUE,"0"); put(cb,f"E{11+i}",v,BLUE,"0.00")
    W(cb,{"A":28,"B":110,"D":8,"E":40})

    # ---------------- Goods_Ratios
    gr=wb.create_sheet("Goods_Ratios"); gr["A1"]="Dampening ratio by good, for the network model (R in dp = L A_US W_US R dtau)"; gr["A1"].font=TITLE
    note(gr,"A2","Each of the network model's 21 goods (HS sections) is mapped to the industries that produce it. Ratio = cost-weighted average of the industries' ratios: SUM(cost term x ratio) / SUM(cost term) = SUM(exact) / SUM(cost).")
    MAPG=static.GOOD_TO_INDUSTRIES
    hdr(gr,4,["#","Good","Producing industries (NAICS)"]+[f"Ratio at {int(t*100)}%" for t in RATES],h=32)
    idx={n:R0+i for i,(n,*_) in enumerate(F1)}
    for j in range(21):
        r=5+j; inds=MAPG[j+1]; put(gr,f"A{r}",j+1,BLUE,"0"); put(gr,f"B{r}",GOODS[j],BLUE); put(gr,f"C{r}",", ".join(map(str,inds)),BLUE)
        for k,t in enumerate(RATES):
            nm,O=SOL[t]
            num="+".join(f"{nm}!{O[0]}{idx[n]}" for n in inds); den="+".join(f"{nm}!{O[1]}{idx[n]}" for n in inds)
            put(gr,f"{CL(4+k)}{r}",f"=({num})/({den})",BLACK,"0.000")
    note(gr,"A27","Mapping is approximate (HS sections vs NAICS industries; e.g. animal products -> animal production and fishing; mineral products -> oil and gas, mining, petroleum products). For mixed-rate packages (Sept 2026: 15/25/50%), weight the ratios by each rate's share of covered imports.")
    W(gr,{"A":5,"B":32,"C":26,"D":12,"E":12,"F":12,"G":12,"H":12})


    gr=wb["Goods_Ratios"]
    put(gr,"C3","Rate (for interpolation)",BOLD)
    for k_,t_ in enumerate(static.RATES): put(gr,f"{CL(4+k_)}3",t_,BLUE,"0%")
    hdr(gr,4,["Ratio, 25% to 50% increment"],col=9,h=32)
    for j in range(21):
        r=5+j; inds=MAPG[j+1]; n50,o50=SOL[0.5]; n25,o25=SOL[0.25]
        e=lambda nm,O,k: "+".join(f"{nm}!{O[k]}{idx[n]}" for n in inds)
        put(gr,f"I{r}",f"=(({e(n50,o50,0)})-({e(n25,o25,0)}))/(({e(n50,o50,1)})-({e(n25,o25,1)}))",BLACK,"0.000")
    gr.column_dimensions["I"].width=14
    note(gr,"A28","Column I: for steel and aluminum items raised from 25% to 50% in the Sept 2026 round: (exact at 50% - exact at 25%) / (cost at 50% - cost at 25%).")
    from .excel_io import add_io_detail
    has_detail = add_io_detail(wb, D, put, hdr, note, W, (BLUE, BLACK, GREEN, BOLD, TITLE, H2))
    if has_detail:
        n_ = len(D["detail"]["inds"]); rc_ = 5 + n_ - 1 + 4
        put(ck, "A20", "17"); put(ck, "B20", "Input-output aggregation in the workbook = Python aggregation (largest difference, C$ thousands)")
        put(ck, "C20", f"=MAX(ABS(IO_Industries!E{rc_+2}:E{rc_+7}))", GREEN, "0.000"); put(ck, "D20", '=IF(C20<1,"PASS","REVIEW")', BOLD)
        ck["C20"] = ArrayFormula("C20", f"=MAX(ABS(IO_Industries!E{rc_+2}:E{rc_+7}))"); ck["C20"].number_format = "0.000"
    else:
        note(wb["StatCan_IO"], "A3", "Sector totals stored as values: the industry-level detail was not available for this run (run with a downloaded input-output table to get IO_Industries and IO_Z).")
    from .excel_layout import organize
    organize(wb, has_detail, put, hdr, note, W, (BLUE, BLACK, GREEN, BOLD, TITLE, H2))

    # period-dependent text
    subs = {"«IO»": str(D["year"]), "«TP»": period_label, "«NHS»": f"{len(CIM):,}", "«NM»": str(n_months),
            "«DL»": datetime.date.today().strftime("%B %d, %Y"), "«N»": f"{N_CAL:.1f}"}
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for c in row:
                if isinstance(c.value, str) and "«" in c.value:
                    v = c.value
                    for k, s in subs.items(): v = v.replace(k, s)
                    c.value = v
    if omega_ca == "io":
        wb["Omega_CA"]["A1"] = "Domestic input shares by supplying sector, computed from the input-output table (rows = buying sector)"
        wb["Omega_CA"]["A2"] = f"Column shares of intermediate use Z, Statistics Canada Table 36-10-0001-01, {D['year']} (option omega_ca: io). In 2022 these differ from R1 Table A1 by 0.006 on average."
    wb.save(path)
