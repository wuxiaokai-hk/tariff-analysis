"""Run with:  python -m pytest tests   (or: python tests/test_model.py)

1. Parsers on small files in the exact Statistics Canada formats.
2. Regression: input-output 2022 + trade 2024 reproduces the published workbook results.
"""
import csv
import io
import json
import os
import sys
import tempfile
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
from tpm import cimt, model, statcan_io  # noqa: E402

IO_HEADER = '"REF_DATE","GEO","DGUID","Valuation","Supply","Use","UOM","UOM_ID","SCALAR_FACTOR","SCALAR_ID","VECTOR","COORDINATE","VALUE","STATUS","SYMBOL","TERMINATED","DECIMALS"'


def io_line(year, val, sup, use, v):
    return f'"{year}","Canada","2021A000011124","{val}","{sup}","{use}","Dollars","81","thousands","3","v1","1.1.1.1","{v}","","","","0"'


def test_io_parser():
    crop = "Crop production (except cannabis, greenhouse, nursery and floriculture production) [BS111A00]"
    lines = [IO_HEADER,
             io_line(2022, "Basic price", crop, "Total use", 63318748),
             io_line(2022, "Basic price", crop, "Household final consumption expenditure, food [PEC01100]", 9085583),
             io_line(2022, "Basic price", crop, "Imports from United States [INTIMUS]", -11935059),
             io_line(2022, "Basic price", crop, "Imports from rest of the world [INTIMRW]", -5077846),
             io_line(2022, "Basic price", crop, "Meat product manufacturing [BS311600]", 1000),
             io_line(2022, "Basic price", "Other activities of the construction industry [BS23E000]", "Imports from United States [INTIMUS]", -127784),
             io_line(2022, "Basic price", "Wages and salaries [PRM100000]", "Total use", 5),
             io_line(2022, "Purchaser price", crop, "Total use", 99),
             io_line(2021, "Basic price", crop, "Total use", 99)]
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "36100001-eng.zip")
        with zipfile.ZipFile(p, "w") as z:
            z.writestr("36100001.csv", "\n".join(lines) + "\n"); z.writestr("36100001_MetaData.csv", "x")
        r = statcan_io.aggregate_rows(statcan_io._rows(p), 2022)
        assert statcan_io.available_years(p) == ["2021", "2022"]
    assert r["X"][0] == 63318748 and r["H"][0] == 9085583
    assert r["M"][0] == 17012905 and r["MUS"][0] == 11935059
    assert r["MUS"][3] == 0 and r["M"][3] == 127784          # construction: no U.S. goods imports counted
    assert r["Z"][0][4] == 1000 and r["MUS_g"][1] == 11935059
    assert abs(r["HUS_g"][1] - 9085583 * 11935059 / (63318748 + 17012905)) < 1e-6
    det = r["detail"]                                        # industry detail for the IO_Industries / IO_Z sheets
    assert det["inds"] == ["BS111A00", "BS23E000", "BS311600"] and det["pec"] == ["PEC01100"]
    assert det["rows"][0] == [63318748, 9085583, -11935059, 0, 0, -5077846] and det["Z"][0][2] == 1000


def test_cimt_parser():
    hdr = "YearMonth/AnnéeMois,HS6,Country/Pays,Province,State/État,Value/Valeur,Quantity/Quantité,Unit of Measure/Unité de Mesure\r\n"
    rows = ['"202312","010121","US","ON","KY",5,1,"NMB"', '"202401","010121","US","ON","KY",153452,12,"NMB"',
            '"202401","010121","AU","ON",,13297,1,"NMB"', '"202402","720851","US","QC","PA",1000,1,"KGM"']
    desc = ("010121     202201 999912 NMB Horses; live, pure-bred breeding animals                                          Chevaux vivants\r\n"
            "720851     200201 999912 KGM Flat-rolled iron, width >=600mm, >10mm thick                                     Produits laminés\r\n")
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "CIMT-CICM_Imp_2024.zip")
        with zipfile.ZipFile(p, "w") as z:
            z.writestr("CIMT-CICM_Imp_2024/ODPFN015_202412N.csv", (hdr + "\r\n".join(rows) + "\r\n").encode("utf-8"))
            z.writestr("CIMT-CICM_Imp_2024/ODPF_3_HS6MDesc.TXT", desc.encode("latin-1"))
        vals, de, months = cimt.sum_us_imports([p], "2024-01", "2024-01")
    assert vals == {"010121": 153452.0} and months == [202401]
    assert de["010121"].startswith("Horses")


def test_regression_2022_2024():
    io_ = json.load(open(os.path.join(ROOT, "data", "processed", "io_2022.json")))
    rows = [(r["HS6"], r["Description"], float(r["US_imports_CAD"]))
            for r in csv.DictReader(open(os.path.join(ROOT, "data", "processed", "us_imports_2024-01_2024-12.csv"), encoding="utf-8"))]
    res = model.run(io_, rows, os.path.join(ROOT, "data", "tariff_lists_hs6.csv"), {"calibrate_N": True})
    s = res["specs"][("Intermediate inputs", True)]
    assert abs(res["N"] - 16.04) < 0.01
    for got, want in zip(s["full"]["total"][:3], (2.9227, 1.4703, 1.0235)):
        assert abs(got - want) < 1e-3
    for got, want in zip(s["damp"]["total"][:3], (1.5767, 0.7800, 0.3830)):
        assert abs(got - want) < 1e-3
    assert abs(res["corr"] - 0.955) < 0.002
    # custom scenario: no scenario -> zero; 25% on HS chapters 72-83 = 25% on all base metals
    assert abs(s["full"]["total"][3]) < 1e-12
    scen = model.read_scenario(os.path.join(ROOT, "data", "scenario_hs2.csv"))
    res2 = model.run(io_, rows, os.path.join(ROOT, "data", "tariff_lists_hs6.csv"), {"calibrate_N": False, "N": res["N"], "scenario": scen})
    s2 = res2["specs"][("Intermediate inputs", True)]
    assert abs(s2["full"]["total"][3] - 0.6367) < 1e-3 and abs(s2["damp"]["total"][3] - 0.3446) < 1e-3
    scen["uniform"] = 10.0                                       # uniform rate overrides every chapter
    res3 = model.run(io_, rows, os.path.join(ROOT, "data", "tariff_lists_hs6.csv"), {"calibrate_N": False, "N": res["N"], "scenario": scen})
    assert abs(res3["tar"]["tau"][0, 3] - 0.10) < 1e-9


if __name__ == "__main__":
    for f in (test_io_parser, test_cimt_parser, test_regression_2022_2024):
        f(); print("passed:", f.__name__)
