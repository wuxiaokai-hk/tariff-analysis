#!/usr/bin/env python3
"""Tariff price model: supply-chain pass-through (BoC SWP 2026-35) with market dampening (BoC SWP 2026-36).

Examples
  python run.py                                         # input-output 2024, trade Jan-Dec 2024
  python run.py --io-year 2022                          # the papers' input-output year
  python run.py --uniform-rate 10                       # custom scenario: 10% on all U.S. goods
  python run.py --scenario my_scenario.csv              # custom scenario by HS chapter (copy data/scenario_hs2.csv)
  python run.py --io-year 2023 --trade-start 2025-01 --trade-end 2025-12
  python run.py --trade-start 2025-09 --trade-end 2026-08   # latest 12 months
  python run.py --list-years                            # which input-output years Statistics Canada publishes

Downloads go to data/cache; aggregated data to data/processed (reused on later runs; --refresh downloads again).
Results: an Excel workbook with live formulas and a CSV summary in output/.
"""
import argparse
import csv
import datetime
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from tpm import cimt, excel, model, statcan_io, static  # noqa: E402

CACHE = os.path.join(HERE, "data", "cache")
PROCESSED = os.path.join(HERE, "data", "processed")
LISTS = os.path.join(HERE, "data", "tariff_lists_hs6.csv")
MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


def month(s):
    if not re.fullmatch(r"\d{4}-\d{2}", s) or not 1 <= int(s[5:]) <= 12:
        raise argparse.ArgumentTypeError("use YYYY-MM, e.g. 2025-01")
    return s


def label(start, end):
    f = lambda s: f"{MONTHS[int(s[5:]) - 1]} {s[:4]}"
    if start[5:] == "01" and end[5:] == "12" and start[:4] == end[:4]:
        return start[:4]
    return f"{f(start)} to {f(end)}"


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--io-year", type=int, default=2024, help="input-output table year (default 2024; the papers use 2022)")
    ap.add_argument("--trade-start", type=month, default="2024-01", help="first month of trade data, YYYY-MM (default 2024-01)")
    ap.add_argument("--trade-end", type=month, default="2024-12", help="last month of trade data, YYYY-MM (default 2024-12)")
    ap.add_argument("--omega-ca", choices=["paper", "io"], default="paper",
                    help="domestic input shares: 'paper' = BoC Table A1 (2022); 'io' = computed from the chosen input-output year")
    ap.add_argument("--scenario", default=os.path.join(HERE, "data", "scenario_hs2.csv"),
                    help="custom scenario: tariff rate and coverage (%%) by HS chapter (default data/scenario_hs2.csv)")
    ap.add_argument("--scenario-hs6", default=os.path.join(HERE, "data", "scenario_hs6_overrides.csv"),
                    help="optional HS6 rates (%%) that override the chapter rate")
    ap.add_argument("--uniform-rate", type=float, default=None, help="custom scenario: one rate (%%) on every chapter")
    ap.add_argument("--N", type=float, default=None, help="fix the number of Canadian firms instead of calibrating it")
    ap.add_argument("--refresh", action="store_true", help="download the Statistics Canada files again")
    ap.add_argument("--out", default=None, help="output workbook path")
    ap.add_argument("--no-excel", action="store_true", help="only print and save the CSV summary")
    ap.add_argument("--list-years", action="store_true", help="list input-output years in the Statistics Canada file and exit")
    a = ap.parse_args()

    if a.list_years:
        from tpm.download import io_zip
        print("Input-output years available:", ", ".join(statcan_io.available_years(io_zip(CACHE, a.refresh))))
        print("CIMT annual import files: see https://open.canada.ca/data/en/dataset/2909a648-5753-4924-878a-b069392d9cde")
        return
    if a.trade_end < a.trade_start:
        ap.error("--trade-end is before --trade-start")

    io = statcan_io.load(a.io_year, CACHE, PROCESSED, refresh=a.refresh)
    rows, months = cimt.load(a.trade_start, a.trade_end, CACHE, PROCESSED, refresh=a.refresh)
    n_months = len(months) if months else ((int(a.trade_end[:4]) - int(a.trade_start[:4])) * 12 + int(a.trade_end[5:]) - int(a.trade_start[5:]) + 1)
    scen = model.read_scenario(a.scenario, a.scenario_hs6 if os.path.exists(a.scenario_hs6) else None)
    scen["uniform"] = a.uniform_rate
    settings = {"calibrate_N": a.N is None, "N": a.N, "omega_ca": a.omega_ca, "scenario": scen}
    print("Running the market model (calibrating N) and the network model ...")
    res = model.run(io, rows, LISTS, settings)
    per = label(a.trade_start, a.trade_end)

    # ---------------- summary
    os.makedirs(os.path.join(HERE, "output"), exist_ok=True)
    tag = f"IO{a.io_year}_trade{a.trade_start}_{a.trade_end}" + ("_omegaIO" if a.omega_ca == "io" else "")
    s = res["specs"][("Intermediate inputs", True)]
    print(f"\nInput-output year {a.io_year}; trade {per}; Canadian firms per industry N = {res['N']:.2f}")
    print(f"{'Package':45s} {'Full':>7s} {'Damp.':>7s} {'Ratio':>7s}   (CPI pp, default specification)")
    for k, p in enumerate(static.PACKAGES):
        f, d = s["full"]["total"][k], s["damp"]["total"][k]
        print(f"{p:45s} {f:7.2f} {d:7.2f} {d / f if f else 0:7.3f}")
    print(f"Custom scenario: average tariff {res['scen_points']:.2f} points on total imports "
          f"({'uniform ' + str(a.uniform_rate) + '%' if a.uniform_rate is not None else os.path.basename(a.scenario)})")
    print("Paper (SWP 2026-35, full pass-through): pre 1.56, post 0.72")
    v = {x["rate"]: x for x in res["validation"]}
    print("Market model vs SWP 2026-36 Table 3 (ratio model / paper): " +
          ", ".join(f"{int(t * 100)}% {v[t]['ratio']:.2f}/{v[t]['paper_ratio']:.2f}" for t in v) + f"; Table F.1 correlation {res['corr']:.3f}")

    summ = os.path.join(HERE, "output", f"summary_{tag}.csv")
    with open(summ, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["io_year", a.io_year, "trade_period", per, "N", round(res["N"], 4), "built", datetime.date.today().isoformat()])
        w.writerow([])
        w.writerow(["Package", "Specification", "Full direct", "Full indirect", "Full total", "Dampened direct", "Dampened indirect", "Dampened total"])
        for (den, cons), sp in res["specs"].items():
            for k, p in enumerate(static.PACKAGES):
                fd, ft = sp["full"]["direct"][k], sp["full"]["total"][k]
                dd, dt = sp["damp"]["direct"][k], sp["damp"]["total"][k]
                w.writerow([p, f"{den}; consumer channel {'Yes' if cons else 'No'}", round(fd, 4), round(ft - fd, 4), round(ft, 4),
                            round(dd, 4), round(dt - dd, 4), round(dt, 4)])
        w.writerow([])
        w.writerow(["Good", "U.S. imports (C$)"] + [f"Effective tariff: {p}" for p in ("pre", "post", "Sept 2026", "scenario")]
                   + [f"Ratio at {int(t * 100)}%" for t in static.RATES] + ["Ratio 25% to 50%", "Ratio used: Sept 2026"])
        for j, gname in enumerate(static.GOODS):
            w.writerow([gname, round(res["tar"]["C"][j])] + [round(x, 5) for x in res["tar"]["tau"][j]]
                       + [round(x, 4) for x in res["R"][j]] + [round(res["P"][j, 2], 4)])
        w.writerow([])
        w.writerow(["Sector", "gamma", "aUS", "aCA"] + [f"Full total %: {p}" for p in ("pre", "post", "Sept 2026")]
                   + [f"Dampened total %: {p}" for p in ("pre", "post", "Sept 2026")] + [f"Implied sector ratio: {p}" for p in ("pre", "post", "Sept 2026")])
        par = s["par"]
        for i, sec in enumerate(static.SECTORS):
            fd, dd = s["full"]["d"][i, :3], s["damp"]["d"][i, :3]
            w.writerow([sec, round(par["gamma"][i], 5), round(par["aUS"][i], 5), round(par["aCA"][i], 5)]
                       + [round(x * 100, 4) for x in s["full"]["p"][i, :3]] + [round(x * 100, 4) for x in s["damp"]["p"][i, :3]]
                       + [round(b / a_, 4) if a_ else "" for a_, b in zip(fd, dd)])
    print(f"\nSummary: {summ}")

    if not a.no_excel:
        out = a.out or os.path.join(HERE, "output", f"Tariff_Model_{tag}.xlsx")
        print("Writing workbook ...")
        excel.write(out, io, res, per, n_months, a.omega_ca)
        print(f"Workbook: {out}  (open in Excel; formulas calculate on opening)")


if __name__ == "__main__":
    main()
