"""Run the whole project: download (optional) -> calculate -> write results.

    python run_all.py                    # uses cached data in data/
    python run_all.py --download         # re-downloads DataWeb data first (needs DATAWEB_TOKEN)
    python run_all.py --download-statcan # re-downloads the StatCan CMA employment and manufacturing sales tables
"""
import argparse
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import pandas as pd  # noqa: E402

from tariff import model, report, cma  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--download", action="store_true", help="download fresh data from DataWeb (needs DATAWEB_TOKEN)")
    ap.add_argument("--download-statcan", action="store_true", help="download StatCan CMA employment and manufacturing sales")
    ap.add_argument("--data", default=os.path.join(HERE, "data"))
    ap.add_argument("--out", default=os.path.join(HERE, "results"))
    a = ap.parse_args()

    if a.download:
        token = os.environ.get("DATAWEB_TOKEN", "").strip()
        if not token:
            sys.exit("Set DATAWEB_TOKEN first (DataWeb > API tab). See tariff/dataweb.py for steps.")
        from tariff import dataweb
        dataweb.download_all(token, a.data)
    if a.download_statcan:
        from tariff import statcan
        statcan.download_all(a.data)

    # 1) National effective rate and scenarios
    R = model.run(a.data)
    report.write_all(R, a.out)
    report.print_summary(R)

    # 2) Ontario CMAs, built up from HTS10 lines
    emp_file = os.path.join(a.data, "statcan_cma_employment_naics4_2021.csv")
    if os.path.exists(emp_file):
        h, _, _, _ = model.load_data(a.data)
        u8708 = R["summary"]["usmca_8708"]
        CR = cma.run(h, a.data, u8708)
        sens = []
        for s in (1.0, 2.0, 4.0):
            o = cma.run(h, a.data, u8708, sigma=s)["cma"]
            sens.append(o[["geo", "export_loss_pct_today", "export_loss_pct_C"] +
                          [c for c in o.columns if c.startswith("mfg_jobs_at_risk")]].assign(sigma=s))
        names = pd.read_csv(os.path.join(a.data, "naics2017_names.csv"), dtype=str).set_index("code")["desc"].to_dict()
        report.write_cma_markdown(CR, R, os.path.join(a.out, "CMA_RESULTS.md"), names)
        report.write_cma_excel(CR, os.path.join(a.out, "cma_results.xlsx"), pd.concat(sens))
        print("\nOntario CMAs (Scenario C, cumulative), ranked by export loss:")
        for _, r in CR["cma"].sort_values("export_loss_pct_C", ascending=False).iterrows():
            jobs = f"  jobs at risk {r['mfg_jobs_at_risk_C']:,.0f}" if "mfg_jobs_at_risk_C" in r else ""
            print(f"  {r['geo']:<24} exports US${r['exports_to_us'] / 1e9:6.2f}bn  rate {r['rate_today'] * 100:5.2f}% -> {r['rate_C'] * 100:5.2f}%"
                  f"  export loss {r['export_loss_pct_C'] * 100:5.1f}%{jobs}")
    else:
        print("\n(No StatCan CMA data yet: run with --download-statcan to add the CMA analysis.)")
    print(f"\nResults written to {a.out}")


if __name__ == "__main__":
    main()
