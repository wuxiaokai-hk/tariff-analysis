# Canada-U.S. tariff model (Python)

This project calculates the U.S. effective tariff rate on Canadian goods:

- the rate today, with Section 338 in force;
- three scenarios for the January 1, 2027 threat, each with a probability;
- the mapping of those scenarios to Moody's Baseline, S3 and S4;
- a check of the 2.6% realized rate for 2025 against outside sources.

Every number is computed in code from U.S. import data and the White House HTS code lists. Nothing is typed in by hand except the assumptions in `tariff/config.py`.

## Run it

```bash
pip install -r requirements.txt
python run_all.py              # uses the data in data/ (pulled from DataWeb Oct 12, 2026)
python run_all.py --download   # downloads fresh data from USITC DataWeb first
python run_all.py --download-statcan   # re-downloads the StatCan tables for the CMA analysis (no key needed)
```

`--download` needs a free DataWeb API token:

1. Sign in at https://dataweb.usitc.gov.
2. Open the **API** tab and copy the token.
3. Run `export DATAWEB_TOKEN="..."`. On Windows PowerShell, use `$env:DATAWEB_TOKEN="..."`.

The download sends one request per HS chapter, because DataWeb caps each report at 20,000 rows. It also pauses between calls to stay under DataWeb's rate limit, so it takes about 15-20 minutes.

## What's in the folder

| Path | What it is |
|---|---|
| `run_all.py` | One command: download (optional), calculate, write results |
| `tariff/dataweb.py` | DataWeb API client. It pulls HTS10 value, calculated duty and dutiable value; monthly totals; and the USMCA vs non-USMCA split |
| `tariff/annex_codes.py` | HTS lines from the White House Section 338 annexes: the July 20 lists, the September 15 additions and removals, and the September 29 import bans |
| `tariff/model.py` | All calculations, step by step |
| `tariff/config.py` | Assumptions, each with its source. Change these and re-run |
| `tariff/report.py` | Writes the results |
| `data/` | DataWeb HTS10 2025 (20,131 lines), monthly totals for 2025-26, the USMCA split, and UN Comtrade HS6 values (used only to reconcile the earlier 8.48%) |
| `tariff/cma.py` | Ontario CMA analysis: HTS10 tariff changes -> NAICS industries -> CMAs |
| `tariff/statcan.py` | Statistics Canada downloader (tables 98-10-0448 and 16-10-0117, via the Web Data Service) |
| `data/statcan_*.csv`, `data/hs6_naics_concordance.csv` | 2021 Census employment by industry for Ontario's 16 CMAs; 2024 manufacturing revenue; HS6-to-NAICS concordance (Pierce-Schott, via the `concordance` R package) |
| `results/CMA_RESULTS.md`, `results/cma_results.xlsx` | Tariff rate, export loss and jobs at risk for each CMA, with the industries and HTS lines driving them |
| `results/RESULTS.md` | The report: headline table, Moody's mapping, the 2.6% check, every calculation with numbers plugged in, and sensitivity |
| `results/tariff_results.xlsx` | The same results as values, in tabs |
| `results/matched_hts_lines.csv` | Each annex HTS line with its 2025 import value and the duty paid |
| `results/all_calculations.csv` | Every step: result, formula and worked numbers |

## Method in one paragraph

**Realized rate** = calculated duty / customs value. This is what Census, USAFacts and RBC measure.

**Today's rate:**
- Start from the realized rate in July 2026, the last full month before Section 338.
- Add 50% × (2025 imports on the tariffed HTS lines ÷ all imports from Canada).
- The tariffed lines are matched exactly at 8 or 10 digits. The coverage comes to US$20.26bn, close to the official US$20bn.

**Statutory rate:** the same calculation, but starting from the Bank of Canada's 5.0% statutory base instead of the July 2026 realized rate.

**Scenarios:** each scenario adds value × affected share × (new rate − current rate) ÷ all imports, using DataWeb values:
- A: HS 8703/8704/8701, cars, trucks and tractors.
- B: HS 8708, auto parts, using the 2025 USMCA claim share for parts.
- C: HS chapter 73, as a proxy for steel derivatives.

**Probabilities:** P(any increase) × a conditional split across A/B/C.

**Moody's mapping:** each Moody's scenario is assigned the outcome sitting at its percentile in the cumulative distribution.

## CMA analysis in one paragraph

**Each HTS10 line** gets:
- its 2025 realized rate;
- the new tariff for today and for Scenarios A, B and C;
- an export response of ((1+t1)/(1+t0))^-σ − 1, with σ = 2 (results also shown for σ = 1 and 4). Banned lines lose 100%.

**From lines to CMAs:**
- Lines map to NAICS 4-digit industries through the HS6 concordance. Vehicles and parts headings are assigned directly.
- Each industry's exports are split across CMAs by the CMA's share of Canadian employment in that industry (2021 Census).

**Jobs at risk** = CMA employment in the industry × export intensity (U.S. exports ÷ Canadian manufacturing revenue) × export loss.
