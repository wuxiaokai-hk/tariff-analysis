"""Run with:  python tests/test_model.py   (or: python -m pytest tests)

1. IOT reader on a small workbook in both layouts (codes in row 6 or row 7; output column "Total use" or "TOTAL").
2. BS-HS8 reader: header row, HS8 written as numbers (leading zero lost), an HS8 split between two industries.
3. Tariffs: value split across HS8 lines, list scaling, import-weighted industry tariff.
4. Network: a 2-industry example solved by hand.
5. Tariff-list builder on small pages in the Finance Canada format.
6. Regression on the simulated files in data/simulated (IOT workbook + BS-HS8 file + 2024 trade).
"""
import csv
import os
import sys
import tempfile

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
from tim import concordance, iot, model, network, tariffs  # noqa: E402

INDS = [("BS111A00", "Crop production"), ("BS331100", "Iron and steel mills"), ("GS911100", "Defence services")]
DOM = {"BS111A00": {"BS111A00": 6, "BS331100": 1, "GS911100": 2, "PEC01100": 30},
       "BS331100": {"BS111A00": 3, "BS331100": 20, "GS911100": 5, "PEC01100": 1},
       "GS911100": {"GS911100": 1}}
US = {"BS111A00": {"BS111A00": 2, "PEC01100": 10}, "BS331100": {"BS111A00": 1, "BS331100": 10, "GS911100": 1}}


def _workbook(path, code_row, total_label):
    from openpyxl import Workbook
    uses = INDS + [("PEC01100", "Household consumption expenditure, food"), ("INTIMUS", "Imports from United States"),
                   ("INTIMRW", "Imports from the rest of the world"), (total_label, "Total")]
    tot = {k: {u: DOM.get(k, {}).get(u, 0) + US.get(k, {}).get(u, 0) for u, _ in uses[:4]} for k, _ in INDS}
    tot["BS111A00"].update({"INTIMUS": -12, "INTIMRW": 0, total_label: 100})
    tot["BS331100"].update({"INTIMUS": -11, "INTIMRW": -5, total_label: 200})
    tot["GS911100"].update({total_label: 50})
    wb = Workbook(); wb.remove(wb.active)
    for name, tab in (("Total", tot), ("Domestic", DOM), ("Import from US", US)):
        ws = wb.create_sheet(name)
        ws.cell(row=1, column=1, value=f"IOT test table: {name}")
        for k, (c, t) in enumerate(uses):
            ws.cell(row=code_row, column=4 + k, value=c); ws.cell(row=code_row + 1, column=4 + k, value=t)
        for i, (c, t) in enumerate(INDS):
            r = code_row + 2 + i
            ws.cell(row=r, column=2, value=c); ws.cell(row=r, column=3, value=t)
            for k, (u, _) in enumerate(uses):
                v = tab.get(c, {}).get(u)
                if v:
                    ws.cell(row=r, column=4 + k, value=v)
        ws.cell(row=code_row + 2 + len(INDS), column=2, value="Grand Total")
    wb.save(path)


def test_iot_reader():
    with tempfile.TemporaryDirectory() as d:
        out = []
        for row, lab in ((6, "Total use"), (7, "TOTAL")):
            p = os.path.join(d, f"iot_{row}.xlsx"); _workbook(p, row, lab)
            out.append(iot.load(p, d, log=lambda *_: None))
        a, b = out
        for k in ("X", "Z", "Zd", "Zus", "Hd", "Hus", "IMP"):
            assert np.allclose(a[k], b[k]), k
        assert a["inds"] == [c for c, _ in INDS] and a["X"] == [100, 200, 50]
        assert a["Zd"][1][0] == 3 and a["Zus"][1][1] == 10 and a["Hd"][0] == 30 and a["Hus"][0] == 10 and a["Htot"] == 41
        assert a["IMP"][1] == [11, 0, 0, 5]


def test_concordance():
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "c.csv")
        with open(p, "w", newline="") as f:
            w = csv.writer(f); w.writerow(["IOIC", "HS8 code"])
            w.writerows([["BS111A00", "1012100"], ["BS111A00", "0101.29.00"], ["BS331100", "72085100"], ["BS332B00", "72085100"]])
        pairs, info = concordance.read(p)
        assert info["lines"] == 4 and info["hs8"] == 3 and info["split"] == 1
        assert ("01012100", "BS111A00", 1.0) in pairs and ("72085100", "BS332B00", 0.5) in pairs


def test_tariffs():
    conc = [("72085100", "BS331100", 1.0), ("72085190", "BS331100", 1.0), ("01012100", "BS111A00", 1.0)]
    trade = [("720851", "Flat-rolled", 100.0), ("010121", "Horses", 50.0)]
    lists = {"720851": {"Mar13_steel": "1", "Sep2026_rate": "50"}}
    L = tariffs.lines_table(conc, trade, lists)
    assert [r["value"] for r in L] == [50.0, 50.0, 50.0]          # HS6 value split equally between its two HS8 lines
    assert L[0]["sep_inc"] == 25 and L[0]["sep_class"] == "25to50"
    sc = dict(mar4=1, steel=0.5, alum=1, other=1, veh_pre=1, veh_post=1, sep2026=1)
    T = tariffs.line_tariffs(L, sc)
    assert np.isclose(T[0, 0], 0.125) and np.isclose(T[0, 2], 0.25) and T[2, 0] == 0
    tau, V = tariffs.industry_tariffs(L, T, ["BS111A00", "BS331100"])
    assert np.isclose(tau[1, 0], 0.125) and tau[0, 0] == 0 and list(V) == [50, 100]


def test_network_hand():
    io = dict(Z=[[10, 5], [20, 15]], Zd=[[8, 4], [10, 10]], Zus=[[2, 1], [5, 5]], X=[100, 100], Hd=[40, 20], Hus=[5, 5], Htot=80)
    par = network.params(io)
    # den = column sums of Z = [30, 20]; A = Zd / den; B = Zus / den
    A = np.array([[8 / 30, 4 / 20], [10 / 30, 10 / 20]]); B = np.array([[2 / 30, 1 / 20], [5 / 30, 5 / 20]])
    tau = np.array([[0.1], [0.0]])
    d = B.T @ tau; dp = np.linalg.solve(np.eye(2) - A.T, d)
    s = network.solve(par, tau)
    assert np.allclose(s["d"], d) and np.allclose(s["p"], dp)
    assert np.isclose(s["total"][0], (np.array([0.5, 0.25]) @ dp[:, 0] + 5 / 80 * 0.1) * 100)


def test_tariff_list_parser():
    from tim import tariff_lists as tl
    row = lambda it, *rest: "<tr><td>" + it + "</td>" + "".join(f"<td>{x}</td>" for x in rest) + "</tr>"
    head = "<thead><tr><th>Tariff Item</th><th>Harmonized System (HS) Heading</th><th>Indicative Description</th></tr></thead>"
    mar4 = "<table>" + head + "<tbody>" + row("0105.11.22", "Live poultry", "x") + "</tbody></table>"
    mar13 = "<table>" + head + "<tbody>" + row("7208.51.00", "Flat-rolled", "x") + row("9506.62.00", "Balls", "x") + "</tbody></table>"
    sep = ("<h3>Products subject to a 50 per cent surtax</h3><table>" + head + "<tbody>" + row("7208.51.00", "Steel", "x") + "</tbody></table>")
    items, flags, counts = tl.build({"mar4": mar4, "mar13": mar13, "sep2026": sep}, ["870323"])
    assert flags["720851"]["Mar13_steel"] == 1 and flags["720851"]["Sep2026_rate"] == 50 and flags["870323"]["Vehicles_8703_8704"] == 1
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "h8.csv"); tl.write_hs8(items, {}, p)
        rows = {r["HS8"]: r for r in csv.DictReader(open(p))}
        assert rows["72085100"]["Mar13_steel"] == "1" and rows["72085100"]["Sep2026_rate"] == "50" and "01051122" in rows


def test_regression_simulated():
    sim = os.path.join(ROOT, "data", "simulated")
    iot_path, conc_path = os.path.join(sim, "SIMULATED_IOT_2024.xlsx"), os.path.join(sim, "SIMULATED_BS_HS8.xlsx")
    trade_path = os.path.join(ROOT, "data", "processed", "us_imports_2024-01_2024-12.csv")
    if not all(map(os.path.exists, (iot_path, conc_path, trade_path))):
        print("  (simulated files not found: regression skipped)"); return
    with tempfile.TemporaryDirectory() as d:
        io = iot.load(iot_path, d, log=lambda *_: None)
    conc, _ = concordance.read(conc_path)
    trade = [(r["HS6"], r["Description"], float(r["US_imports_CAD"])) for r in csv.DictReader(open(trade_path, encoding="utf-8"))]
    res = model.run(io, conc, trade, tariffs.read_lists(os.path.join(ROOT, "data", "tariff_lists_hs6.csv")),
                    dict(scenario=tariffs.read_scenario(os.path.join(ROOT, "data", "scenario_hs2.csv"))))
    s = res["specs"][("Intermediate inputs", True)]
    assert abs(res["N"] - 15.98) < 0.01
    assert np.allclose(s["full"]["total"], [2.0818, 0.8001, 1.2216, 0.7903], atol=1e-3), s["full"]["total"]
    assert np.allclose(s["damp"]["total"], [1.1402, 0.4319, 0.4313, 0.4314], atol=1e-3), s["damp"]["total"]
    assert abs(sum(r["value"] * t for r, t in zip(res["L"], res["T"][:, 0])) - 24e9) < 1      # C$96bn x 25%


if __name__ == "__main__":
    for name, f in list(globals().items()):
        if name.startswith("test_"):
            f(); print("passed:", name)
