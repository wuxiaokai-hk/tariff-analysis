"""Tariffs on U.S. products: HS8 tariff items -> input-output industries (BS codes), for the four packages.

Steps
  1. HS8 lines: every (HS8, BS code) pair of the BS-HS8 file.
  2. U.S. import value of each line (C$): the HS8 value if an HS8 trade file is given; otherwise the HS6 value from
     CIMT split equally between the HS8 lines of that HS6 (CIMT publishes HS6 in its bulk files).
     An HS8 listed with two industries is split equally between them.
  3. List flags of each line: from the HS8 list file if given, else from the HS6 list file (every HS8 of a flagged HS6).
  4. Effective tariff change of each line in each package (as in the earlier project):
       pre-Sept 2025   25% x (Mar 4 + steel + aluminum + other + vehicles), each list scaled to its official value
       post-Sept 2025  25% x (steel + aluminum + vehicles)
       Sept 8, 2026    the increase over the rate already in force (steel and aluminum items: rate - 25)
       Custom scenario chapter rate x coverage, or an HS6 / HS8 override (Scenario sheet / scenario files)
  5. Industry tariff tau_k = SUM over lines of k (value x tariff) / SUM over lines of k (value): the import-weighted
     tariff on the U.S. products of industry k, applied to row k of the Import-from-US table.
Lines of HS6 products with no HS8 line in the BS-HS8 file are reported as unmapped and get no tariff.
"""
import csv

import numpy as np

from . import static

FLAGS = ("Mar4_2025", "Mar13_steel", "Mar13_aluminum", "Mar13_other", "Vehicles_8703_8704")


def read_lists(path, key="HS6", width=6):
    """{code: row} of a list-flag file (columns as data/tariff_lists_hs6.csv; key column HS6 or HS8)."""
    return {r[key].strip().zfill(width): r for r in csv.DictReader(open(path, encoding="utf-8"))}


def read_scenario(hs2_path, overrides_path=None, uniform=None):
    """Chapter rates and coverage (%), plus overrides by HS6 or HS8 code (rate %)."""
    hs2 = {}
    for r in csv.DictReader(open(hs2_path, encoding="utf-8")):
        hs2[r["chapter"].zfill(2)] = (float(r.get("rate_pct") or 0), float(r.get("coverage_pct") or 100))
    ov = {}
    if overrides_path:
        for r in csv.DictReader(open(overrides_path, encoding="utf-8")):
            code = (r.get("code") or r.get("hs8") or r.get("hs6") or "").strip()
            if code and r.get("rate_pct") not in (None, ""):
                ov[code.zfill(8 if len(code) > 6 else 6)] = float(r["rate_pct"])
    return dict(hs2=hs2, overrides=ov, uniform=uniform)


def lines_table(conc, trade6, lists6, lists8=None, trade8=None, scen=None):
    """One record per (HS8, BS) line."""
    per6 = {}
    for h8, bs, sh in conc:
        per6[h8[:6]] = per6.get(h8[:6], 0) + sh
    desc = {h: d for h, d, _ in trade6}
    v6 = {h: v for h, _, v in trade6}
    L = []
    for h8, bs, sh in conc:
        h6 = h8[:6]
        if trade8 is not None:
            value = trade8.get(h8, 0.0) * sh
        else:
            value = v6.get(h6, 0.0) * sh / per6[h6]
        src = (lists8.get(h8) if lists8 else lists6.get(h6)) or {}
        f = {k: int(src.get(k) or 0) for k in FLAGS}
        if lists8:      # vehicles are defined by product (headings 8703 and 8704), not by list items
            f["Vehicles_8703_8704"] = int(h8[:4] in ("8703", "8704"))
        rate = src.get("Sep2026_rate") or ""
        steel_al = f["Mar13_steel"] or f["Mar13_aluminum"]
        inc = 0 if rate == "" else (max(0, int(rate) - 25) if steel_al else int(rate))
        cls = "" if inc == 0 else ("25to50" if steel_al else str(int(rate)))
        L.append(dict(hs8=h8, hs6=h6, chapter=h8[:2], bs=bs, share=sh, desc=desc.get(h6, ""), value=value, **f,
                      sep_rate=int(rate) if rate else None, sep_inc=inc, sep_class=cls))
    for r in L:
        r["scen_rate"] = scenario_rate(r, scen)
    return L


def scenario_rate(r, scen):
    """Nominal scenario rate (fraction) on a line: HS8 override, HS6 override, else uniform or chapter rate x coverage."""
    if not scen:
        return 0.0
    ov = scen["overrides"]
    if r["hs8"] in ov:
        return ov[r["hs8"]] / 100
    if r["hs6"] in ov:
        return ov[r["hs6"]] / 100
    rate, cov = scen["hs2"].get(r["chapter"], (0.0, 100.0))
    if scen.get("uniform") is not None:
        rate = scen["uniform"]
    return rate * cov / 1e4


def scales(L):
    """Official value / matched value (capped at 1) for each list, as in the earlier project."""
    m = lambda k: sum(r["value"] for r in L if r[k])
    S = static.LISTS
    sep = sum(r["value"] for r in L if r["sep_rate"] is not None)
    cap = lambda off, mt: min(1.0, off / mt) if mt else 0.0
    return dict(mar4=cap(S["mar4"]["official"], m("Mar4_2025")), steel=cap(S["steel"]["official"], m("Mar13_steel")),
                alum=cap(S["alum"]["official"], m("Mar13_aluminum")), other=cap(S["other"]["official"], m("Mar13_other")),
                veh_pre=cap(S["veh_pre"]["official"], m("Vehicles_8703_8704")),
                veh_post=cap(S["veh_post"]["official"], m("Vehicles_8703_8704")), sep2026=cap(S["sep2026"]["official"], sep),
                matched=dict(mar4=m("Mar4_2025"), steel=m("Mar13_steel"), alum=m("Mar13_aluminum"), other=m("Mar13_other"),
                             veh=m("Vehicles_8703_8704"), sep2026=sep))


def line_tariffs(L, sc):
    """Effective tariff change (fraction) of each line in the 4 packages: array (lines x 4)."""
    T = np.zeros((len(L), 4))
    for i, r in enumerate(L):
        T[i, 0] = 0.25 * (r["Mar4_2025"] * sc["mar4"] + r["Mar13_steel"] * sc["steel"] + r["Mar13_aluminum"] * sc["alum"]
                          + r["Mar13_other"] * sc["other"] + r["Vehicles_8703_8704"] * sc["veh_pre"])
        T[i, 1] = 0.25 * (r["Mar13_steel"] * sc["steel"] + r["Mar13_aluminum"] * sc["alum"] + r["Vehicles_8703_8704"] * sc["veh_post"])
        T[i, 2] = r["sep_inc"] / 100 * sc["sep2026"]
        T[i, 3] = r["scen_rate"]
    return T


def industry_tariffs(L, T, inds):
    """tau (industries x columns of T): import-weighted tariff on each industry's U.S. products."""
    ix = {c: k for k, c in enumerate(inds)}
    V = np.zeros(len(inds)); VT = np.zeros((len(inds), T.shape[1]))
    for i, r in enumerate(L):
        k = ix.get(r["bs"])
        if k is not None:
            V[k] += r["value"]; VT[k] += r["value"] * T[i]
    tau = np.where(V[:, None] > 0, VT / np.where(V > 0, V, 1)[:, None], 0.0)
    return tau, V
