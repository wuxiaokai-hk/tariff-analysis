"""Everything in one call: tariffs by HS8 line and industry, market dampening, network model, CPI."""
import numpy as np

from . import market, network, static, tariffs


def run(io, conc, trade6, lists6, settings):
    inds = io["inds"]
    L = tariffs.lines_table(conc, trade6, lists6, settings.get("lists8"), settings.get("trade8"), settings.get("scenario"))
    sc = tariffs.scales(L)
    T = tariffs.line_tariffs(L, sc)
    rr = market.row_ratios(io)
    N = market.calibrate_N(rr) if settings.get("N") is None else float(settings["N"])
    mk = market.run_market(rr, N)
    R, rules = market.industry_ratios(mk, inds)
    P = market.line_ratios(L, R, inds)
    tau, V = tariffs.industry_tariffs(L, np.c_[T, T * P], inds)
    tau_full, tau_damp = tau[:, :4], tau[:, 4:]
    specs = {}
    for den in ("Intermediate inputs", "Total output"):
        par = network.params(io, den)
        for cons in (True, False):
            specs[(den, cons)] = dict(par=par, full=network.solve(par, tau_full, cons), damp=network.solve(par, tau_damp, cons))
    val, corr = market.validation(mk)
    mapped6 = {r["hs6"] for r in L}
    unmapped = [(h, d, v) for h, d, v in trade6 if h not in mapped6]
    unknown = sorted({r["bs"] for r in L} - set(inds))
    scen_pts = sum(r["value"] * r["scen_rate"] for r in L) / static.TOTAL_IMPORTS_ALL * 100
    return dict(L=L, T=T, P=P, scales=sc, rr=rr, N=N, mk=mk, R=R, rules=rules, tau_full=tau_full, tau_damp=tau_damp, V=V,
                specs=specs, validation=val, corr=corr, unmapped=unmapped, unknown_bs=unknown, scen_points=scen_pts,
                settings=settings)
