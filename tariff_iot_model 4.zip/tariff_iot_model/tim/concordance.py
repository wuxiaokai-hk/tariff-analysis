"""Read the BS-HS8 file: which input-output industry (BS code) makes each HS8 tariff item.

Two columns, CSV or Excel (first sheet, or --concordance-sheet). The columns are found by their content: the column
with the most BS/NP/GS industry codes, and the column with the most 8-digit HS codes (written 01012100, 0101.21.00 or
as a number, where Excel has dropped the leading zero). A header row is skipped automatically.
An HS8 code listed with more than one industry is split equally between them (the file lists the split).
"""
import csv
import os
import re

from .iot import IND

HS8 = re.compile(r"^\d{8}$")


def _hs8(v):
    if v is None:
        return None
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    s = re.sub(r"[.\s]", "", str(v).strip())
    if s.isdigit() and 7 <= len(s) <= 8:
        s = s.zfill(8)
    return s if HS8.match(s) else None


def _rows(path, sheet=None):
    if path.lower().endswith((".xlsx", ".xlsm")):
        from openpyxl import load_workbook
        wb = load_workbook(path, read_only=True, data_only=True)
        ws = wb[sheet] if sheet else wb.worksheets[0]
        return [list(r) for r in ws.iter_rows(values_only=True)]
    with open(path, encoding="utf-8-sig", newline="") as f:
        return [r for r in csv.reader(f)]


def read(path, sheet=None):
    """[(hs8, bs code, share)] with share = 1 / (number of industries listed for that HS8)."""
    rows = _rows(path, sheet)
    if not rows:
        raise ValueError(f"{path} is empty")
    ncol = max(len(r) for r in rows)
    col = lambda c: [r[c] if c < len(r) else None for r in rows]
    bs_col = max(range(ncol), key=lambda c: sum(1 for v in col(c) if isinstance(v, str) and IND.match(v.strip())))
    hs_col = max((c for c in range(ncol) if c != bs_col), key=lambda c: sum(1 for v in col(c) if _hs8(v)))
    pairs, seen = [], set()
    for r in rows:
        bs = str(r[bs_col]).strip() if bs_col < len(r) and r[bs_col] is not None else ""
        h = _hs8(r[hs_col] if hs_col < len(r) else None)
        if IND.match(bs) and h and (h, bs) not in seen:
            seen.add((h, bs)); pairs.append((h, bs))
    if not pairs:
        raise ValueError(f"No (BS code, HS8) pairs found in {path}")
    n = {}
    for h, _ in pairs:
        n[h] = n.get(h, 0) + 1
    info = dict(path=os.path.basename(path), bs_column=bs_col + 1, hs8_column=hs_col + 1, lines=len(pairs),
                hs8=len(n), split=sum(1 for v in n.values() if v > 1))
    return [(h, bs, 1.0 / n[h]) for h, bs in pairs], info
