"""Network model (BoC SWP 2026-35, eq. 3-5) at the level of the input-output industries.

For each using industry i (all ~220 industries of the IOT tables):
    dp_i = SUM_k  b_ki tau_k  +  SUM_j  a_ji dp_j
    b_ki = Zus[k, i] / den_i   U.S. product of industry k used by i, from the Import-from-US table
    a_ji = Zd[j, i] / den_i    domestic product of industry j used by i, from the Domestic table
    den_i = SUM_j Z[j, i] (total intermediate inputs, Total table; default) or output of i (Total use)
In matrix form: dp = (I - A')^-1 B' tau, with the direct effect d = B' tau.

This is the paper's equation with aUS_i x W_US(i, k) = b_ki and aCA_i x W_CA(i, j) = a_ji: no goods sections are
needed, because the Import-from-US table already says which industry's U.S. product each industry buys.

CPI (households):
    dP = SUM_i (Hd_i / H) dp_i  +  SUM_k (Hus_k / H) tau_k   (second term: consumer channel, optional)
    Hd_i: household spending on domestic output of i (Domestic table, PEC columns); Hus_k: household purchases of U.S.
    products of industry k (Import-from-US table); H: total household spending (Total table).
"""
import numpy as np

from . import static


def params(io, denominator="Intermediate inputs"):
    Z, Zd, Zus = (np.array(io[k], float) for k in ("Z", "Zd", "Zus"))
    X = np.array(io["X"], float)
    den = X if denominator == "Total output" else Z.sum(0)
    den_ = np.where(den > 0, den, 1.0)
    A = Zd / den_[None, :]; B = Zus / den_[None, :]
    A[:, den <= 0] = 0; B[:, den <= 0] = 0
    H = io["Htot"]
    return dict(den=den, A=A, B=B, aCA=A.sum(0), aUS=B.sum(0), hd=np.array(io["Hd"], float) / H,
                hus=np.array(io["Hus"], float) / H, X=X)


def solve(par, tau, consumer=True):
    """tau: industries x packages. Returns d, dp (fractions) and CPI direct / total (pp)."""
    n = len(par["den"])
    L = np.linalg.inv(np.eye(n) - par["A"].T)
    d = par["B"].T @ tau
    p = L @ d
    cons = par["hus"] @ tau if consumer else np.zeros(tau.shape[1])
    return dict(d=d, p=p, L=L, cons=cons * 100, direct=(par["hd"] @ d + cons) * 100, total=(par["hd"] @ p + cons) * 100)


def sector_of(code):
    if code in static.SPECIAL_SECTOR:
        return static.SPECIAL_SECTOR[code]
    return static.NAICS2_TO_SECTOR.get(code[2:4])


def by_sector(inds, X, v):
    """Output-weighted average of v (industries x packages) for the 20 sectors of the paper."""
    out = np.zeros((20, v.shape[1])); w = np.zeros(20)
    for k, c in enumerate(inds):
        s = sector_of(c)
        if s is not None:
            out[s] += X[k] * v[k]; w[s] += X[k]
    return out / np.where(w > 0, w, 1)[:, None]
