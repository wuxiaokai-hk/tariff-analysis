"""Build data/tariff_lists_hs6.csv from the Department of Finance Canada counter-tariff list pages.

Steps
  1. Download each list page (or read a saved copy of the page from --html-dir).
  2. Read every HTML table on the page and keep the rows whose "Tariff Item" cell is an 8-digit Canadian tariff item
     (written ####.##.##). For the September 8, 2026 list, read each item's rate (a rate column if the table has one,
     otherwise the rate stated in the table caption or the heading above the table).
  3. Cut each item to HS6 (first 6 digits) and flag the HS6 product for that list.
     March 13, 2025 list: steel = HS chapters 72-73, aluminum = chapter 76, other goods = all other chapters.
     Vehicles (April 2025 countermeasures, defined by product): every HS6 under headings 8703 and 8704.
     Sept 2026 rate of an HS6 with items at different rates: the highest rate (rule shown in the item file).
  4. Write three files: data/tariff_lists_items.csv (one row per 8-digit item, the audit trail),
     data/tariff_lists_hs6.csv (one row per flagged HS6) and data/tariff_lists_hs8.csv (one row per listed HS8 item;
     use it with run.py --lists-hs8 so only the listed HS8 items get the tariff, not every HS8 of a listed HS6).

Run:  python -m tim.tariff_lists                 # download, build, compare with the current file
      python -m tim.tariff_lists --html-dir DIR  # use pages saved from a browser (File > Save Page As, HTML only)
"""
import argparse
import csv
import os
import re
import sys
from html.parser import HTMLParser

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)

SOURCES = {
    "mar4": dict(url="https://www.canada.ca/en/department-finance/news/2025/03/list-of-products-from-the-united-states-subject-to-25-per-cent-tariffs-effective-march-4-2025.html",
                 file="mar4_2025.html", expected=1258, rate=25),
    "mar13": dict(url="https://www.canada.ca/en/department-finance/news/2025/03/list-of-products-from-the-united-states-subject-to-25-per-cent-tariffs-effective-march-13-2025.html",
                  file="mar13_2025.html", expected=539, rate=25),
    "sep2026": dict(url="https://www.canada.ca/en/department-finance/news/2026/08/list-of-products-from-the-united-states-subject-to-counter-tariffs-effective-september-8-2026.html",
                    file="sep8_2026.html", expected=629, rate=None),
}
COLUMNS = ["Mar4_2025", "Mar13_steel", "Mar13_aluminum", "Mar13_other", "Vehicles_8703_8704", "Sep2026_rate"]
ITEM = re.compile(r"^\s*(\d{4})\.?(\d{2})\.?(\d{2})\s*$")
RATE = re.compile(r"(\d{1,3})\s*(?:%|per\s*cent|percent)", re.I)


# ---------------------------------------------------------------- HTML tables
class _Tables(HTMLParser):
    """Collects every <table>: caption, the last heading before it, header cells and body rows (cell text)."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.tables, self.heading, self._t, self._row, self._cell, self._in, self._htag = [], "", None, None, None, None, None

    def handle_starttag(self, tag, attrs):
        if tag in ("h1", "h2", "h3", "h4", "h5"):
            self._htag, self._hbuf = tag, []
        elif tag == "table":
            self._t = dict(caption="", heading=self.heading, header=[], rows=[])
        elif self._t is not None:
            if tag == "caption":
                self._in = "caption"; self._cap = []
            elif tag == "tr":
                self._row = []
            elif tag in ("td", "th"):
                self._cell = []; self._celltag = tag

    def handle_endtag(self, tag):
        if tag == self._htag:
            self.heading = " ".join("".join(self._hbuf).split()); self._htag = None
        elif self._t is not None:
            if tag == "caption" and self._in == "caption":
                self._t["caption"] = " ".join("".join(self._cap).split()); self._in = None
            elif tag in ("td", "th") and self._cell is not None:
                self._row.append((" ".join("".join(self._cell).split()), self._celltag)); self._cell = None
            elif tag == "tr" and self._row is not None:
                if self._row and all(t == "th" for _, t in self._row) and not self._t["header"]:
                    self._t["header"] = [c for c, _ in self._row]
                elif self._row:
                    self._t["rows"].append([c for c, _ in self._row])
                self._row = None
            elif tag == "table":
                self.tables.append(self._t); self._t = None

    def handle_data(self, data):
        if self._htag:
            self._hbuf.append(data)
        if self._in == "caption":
            self._cap.append(data)
        if self._cell is not None:
            self._cell.append(data)


def parse_tables(html):
    p = _Tables(); p.feed(html); return p.tables


def items_from_page(html, default_rate=None):
    """[(tariff_item 'XXXX.XX.XX', rate or None, table caption)] for every tariff-item row on the page."""
    out = []
    for t in parse_tables(html):
        hdr = [h.lower() for h in t["header"]]
        icol = next((k for k, h in enumerate(hdr) if "tariff item" in h), 0)
        rcol = next((k for k, h in enumerate(hdr) if "rate" in h or "surtax" in h or "%" in h), None)
        m = RATE.search(t["caption"]) or RATE.search(t["heading"])
        table_rate = int(m.group(1)) if m else default_rate
        for row in t["rows"]:
            if icol >= len(row):
                continue
            mi = ITEM.match(row[icol])
            if not mi:
                continue
            rate = table_rate
            if rcol is not None and rcol < len(row):
                mr = RATE.search(row[rcol]) or re.search(r"(\d{1,3})", row[rcol])
                if mr:
                    rate = int(mr.group(1))
            out.append((f"{mi.group(1)}.{mi.group(2)}.{mi.group(3)}", rate, t["caption"] or t["heading"]))
    return out


# ---------------------------------------------------------------- build
def get_page(key, html_dir=None, cache_dir=None, refresh=False):
    src = SOURCES[key]
    if html_dir:
        path = os.path.join(html_dir, src["file"])
        if not os.path.exists(path):
            raise FileNotFoundError(f"{path} not found: save {src['url']} there")
        return open(path, encoding="utf-8", errors="replace").read()
    cache_dir = cache_dir or os.path.join(HERE, "data", "cache", "lists")
    os.makedirs(cache_dir, exist_ok=True)
    path = os.path.join(cache_dir, src["file"])
    if os.path.exists(path) and not refresh:
        return open(path, encoding="utf-8", errors="replace").read()
    from .download import _get
    print(f"Downloading {src['url']}")
    with _get(src["url"]) as r:
        html = r.read().decode("utf-8", errors="replace")
    open(path, "w", encoding="utf-8").write(html)
    return html


def mar13_part(item):
    ch = item[:2]
    return "Mar13_steel" if ch in ("72", "73") else "Mar13_aluminum" if ch == "76" else "Mar13_other"


def build(pages, hs6_universe, descriptions=None):
    """pages: {key: html}. hs6_universe: HS6 codes in the trade data (for the vehicle headings).
    Returns (item rows, {hs6: {column: value}}, counts)."""
    items, flags, counts = [], {}, {}
    sep_rates = {}
    for key, html in pages.items():
        found = items_from_page(html, SOURCES[key]["rate"])
        seen = set()
        for it, rate, cap in found:
            if (it, rate) in seen:
                continue
            seen.add((it, rate))
            hs6 = it.replace(".", "")[:6]
            if key == "mar4":
                col = "Mar4_2025"
            elif key == "mar13":
                col = mar13_part(it)
            else:
                col = "Sep2026_rate"
                if rate is None:
                    raise ValueError(f"No rate found for {it} on the Sept 2026 page (table '{cap}')")
                sep_rates.setdefault(hs6, set()).add(rate)
            items.append(dict(list=key, column=col, tariff_item=it, hs6=hs6, rate=rate, table=cap))
            if col != "Sep2026_rate":
                flags.setdefault(hs6, {})[col] = 1
        counts[key] = len(seen)
    for hs6, rates in sep_rates.items():
        flags.setdefault(hs6, {})["Sep2026_rate"] = max(rates)
    for hs6 in hs6_universe:
        if hs6[:4] in ("8703", "8704"):
            flags.setdefault(hs6, {})["Vehicles_8703_8704"] = 1
    counts["mixed_rate_hs6"] = sum(1 for r in sep_rates.values() if len(r) > 1)
    return items, flags, counts


def write(items, flags, descriptions, items_path, hs6_path):
    with open(items_path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["list", "column", "tariff_item", "hs6", "rate", "table"]); w.writeheader(); w.writerows(items)
    with open(hs6_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["HS6", "Description"] + COLUMNS)
        for hs6 in sorted(flags):
            fl = flags[hs6]
            w.writerow([hs6, descriptions.get(hs6, "")] + [fl.get(c, 0) if c != "Sep2026_rate" else fl.get(c, "") for c in COLUMNS])


def write_hs8(items, descriptions, path):
    """One row per listed HS8 item (same columns as the HS6 file; vehicles are flagged by run.py from headings 8703/8704)."""
    fl = {}
    for it in items:
        h8 = it["tariff_item"].replace(".", "")
        d = fl.setdefault(h8, {})
        if it["column"] == "Sep2026_rate":
            d["Sep2026_rate"] = max(d.get("Sep2026_rate", 0), it["rate"])
        else:
            d[it["column"]] = 1
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["HS8", "Description"] + COLUMNS)
        for h8 in sorted(fl):
            d = fl[h8]
            w.writerow([h8, descriptions.get(h8[:6], "")] + [d.get(c, 0) if c != "Sep2026_rate" else d.get(c, "") for c in COLUMNS])
    return len(fl)


def compare(new_path, old_path):
    rd = lambda p: {r["HS6"]: r for r in csv.DictReader(open(p, encoding="utf-8"))}
    a, b = rd(new_path), rd(old_path)
    print(f"\nComparison with {os.path.basename(old_path)}: {len(a)} HS6 now, {len(b)} before")
    same = True
    for c in COLUMNS:
        na = {h for h, r in a.items() if r.get(c) not in ("", "0", None)}
        nb = {h for h, r in b.items() if r.get(c) not in ("", "0", None)}
        diff_val = [h for h in na & nb if c == "Sep2026_rate" and a[h][c] != b[h][c]]
        same &= not (na - nb or nb - na or diff_val)
        print(f"  {c:20s} now {len(na):5d}  before {len(nb):5d}  only now {len(na - nb):4d}  only before {len(nb - na):4d}"
              + (f"  different rate {len(diff_val)}" if c == "Sep2026_rate" else ""))
    print("  -> identical flags" if same else "  -> differences listed above (see data/tariff_lists_items.csv for the items)")
    return same


def main():
    ap = argparse.ArgumentParser(description="Build data/tariff_lists_hs6.csv from the Finance Canada list pages")
    ap.add_argument("--html-dir", help="folder with saved pages: " + ", ".join(s["file"] for s in SOURCES.values()))
    ap.add_argument("--refresh", action="store_true", help="download the pages again")
    ap.add_argument("--trade", default=os.path.join(HERE, "data", "processed", "us_imports_2024-01_2024-12.csv"),
                    help="HS6 trade file used for descriptions and the vehicle headings")
    ap.add_argument("--out", default=os.path.join(HERE, "data", "tariff_lists_hs6.csv"))
    a = ap.parse_args()
    trade = list(csv.DictReader(open(a.trade, encoding="utf-8")))
    desc = {r["HS6"]: r["Description"] for r in trade}
    pages = {k: get_page(k, a.html_dir, refresh=a.refresh) for k in SOURCES}
    items, flags, counts = build(pages, desc.keys(), desc)
    print("Tariff items found (expected):")
    for k, s in SOURCES.items():
        ok = "ok" if counts[k] == s["expected"] else "CHECK"
        print(f"  {k:8s} {counts[k]:5d} ({s['expected']})  {ok}")
    print(f"  Sept 2026 HS6 products with items at different rates: {counts['mixed_rate_hs6']} (highest rate used)")
    old = a.out + ".previous.csv"
    if os.path.exists(a.out):
        os.replace(a.out, old)
    write(items, flags, desc, os.path.join(os.path.dirname(a.out), "tariff_lists_items.csv"), a.out)
    n8 = write_hs8(items, desc, os.path.join(os.path.dirname(a.out), "tariff_lists_hs8.csv"))
    print(f"Wrote {a.out} ({len(flags)} HS6), tariff_lists_hs8.csv ({n8} HS8) and tariff_lists_items.csv ({len(items)} items)")
    if os.path.exists(old):
        compare(a.out, old)


if __name__ == "__main__":
    main()
