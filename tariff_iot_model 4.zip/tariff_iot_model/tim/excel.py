"""Excel workbook with live formulas: HS8 lines -> industry tariffs -> network (Leontief inverse) -> CPI.

Sheets
  README, Results, Settings, Scenario
  T1_HS8_Lines     one row per (HS8, BS) line: U.S. imports, list flags, tariff by package, dampening ratio
  T2_Trade_HS6     Canada's imports from the U.S. by HS6 (CIMT) and list flags
  T3_Lists         official list values, matched values, scaling
  D1_Ratios_by_Industry   dampening ratio of each input-output industry (formulas on the solve tabs)
  D2-D12           market model (SWP 2026-36) as live formulas, as in the earlier project (tim/excel_market.py)
  N1_Industries    one row per industry: denominator, aCA, aUS, household weights, tariffs, direct and total effect
  N2_IOT_Total, N3_IOT_Domestic, N4_IOT_US   the three IOT tables (industry x industry, households)
  N5_I_minus_A     I - A' (A = domestic input shares)      N6_Leontief   MINVERSE(N5)
  Checks, References
Format as the earlier project: Arial, navy headers, thin borders, tabs coloured by step.
Blue = data, black = formula, green = link to another sheet, yellow = cells you can change.
"""
import datetime

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter as CL
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.worksheet.formula import ArrayFormula

from . import excel_market, static

F = "Arial"
BLUE = Font(name=F, color="0000FF"); BLACK = Font(name=F); GREEN = Font(name=F, color="008000"); BOLD = Font(name=F, bold=True)
TITLE = Font(name=F, bold=True, size=14, color="1F3A5F"); H2 = Font(name=F, bold=True, size=11, color="1F3A5F")
HDR = Font(name=F, bold=True, color="FFFFFF"); NOTE = Font(name=F, italic=True, size=9, color="595959")
HF = PatternFill("solid", fgColor="1F3A5F"); YEL = PatternFill("solid", fgColor="FFFF00"); KEYFILL = PatternFill("solid", fgColor="E2EFDA")
thin = Side(style="thin", color="BFBFBF"); BOX = Border(top=thin, bottom=thin, left=thin, right=thin)
WRAP = Alignment(wrap_text=True, vertical="top")
R0 = 5   # first data row of every table

# Tab groups, as in the earlier project: colour, label
GROUPS = {"start": ("1F3A5F", "Start here"), "input": ("FFC000", "Inputs you can change"), "result": ("00B050", "Results"),
          "T": ("4472C4", "Step 1 - Tariffs by HS8 line and industry"), "D": ("ED7D31", "Step 2 - Market dampening (SWP 2026-36)"),
          "N": ("7030A0", "Step 3 - Supply-chain network on the IOT tables (SWP 2026-35)"), "check": ("7F7F7F", "Checks and sources")}
SHEETS = [
    ("README", "start", "What the workbook does, the method, and this sheet map"),
    ("Results", "result", "CPI effect of each package: full pass-through and with dampening; price change by sector"),
    ("Scenario", "input", "YOUR SCENARIO: tariff rate and coverage by HS chapter; overrides by HS6 or HS8 code"),
    ("Settings", "input", "Switches: denominator of the input shares (B4), consumer channel (B5); data used"),
    ("T1_HS8_Lines", "T", "Each (HS8, industry) line: U.S. imports, list flags, tariff by package, dampening ratio, dampened tariff"),
    ("T2_Trade_HS6", "T", "Imports from the U.S. by HS6 (CIMT)"),
    ("T3_Lists", "T", "Finance Canada lists: official values, matched imports, scale factors"),
    ("D1_Ratios_by_Industry", "D", "Dampening ratio of each input-output industry at 5, 10, 15, 25, 50% and 25% -> 50% (used by T1)"),
    ("D2_Market_Results", "D", "Market model results for the 32 Table F.1 industries at each tariff rate"),
    ("D3_Market_Validation", "D", "Comparison with SWP 2026-36 Tables 3 and F.1"),
    ("D4_Market_Calibration", "D", "The one calibrated number: Canadian firms per industry (N)"),
    ("D5_Market_Inputs", "D", "sigma, rho, N, damping, firm-size distribution"),
    ("D6_Market_Industries", "D", "U.S., rest-of-world and Canadian shares by industry (rest-of-world ratio from the IOT)"),
    ("D7_Market_Firms", "D", "Initial shares, markups and costs of the 11 firm types"),
    ("D8_Solve_5pct", "D", "Market equilibrium at a 5% tariff (50 iterations)"), ("D9_Solve_10pct", "D", "Market equilibrium at 10%"),
    ("D10_Solve_15pct", "D", "Market equilibrium at 15%"), ("D11_Solve_25pct", "D", "Market equilibrium at 25%"),
    ("D12_Solve_50pct", "D", "Market equilibrium at 50%"),
    ("N1_Industries", "N", "Each input-output industry: denominator, aCA, aUS, household weights, tariffs, direct effect d, total effect dp"),
    ("N2_IOT_Total", "N", "IOT Total table (rows = supplying industry, columns = using industry), output and households"),
    ("N3_IOT_Domestic", "N", "IOT Domestic table: domestic flows and household spending on domestic output"),
    ("N4_IOT_US", "N", "IOT Import-from-US table: U.S. flows and household purchases of U.S. products"),
    ("N5_I_minus_A", "N", "I - A' (A = domestic input shares; row = buying industry)"),
    ("N6_Leontief", "N", "Leontief inverse = MINVERSE(N5), recalculates live"),
    ("Checks", "check", "Automatic checks (PASS / REVIEW): workbook vs Python and model checks"),
    ("References", "check", "Sources"),
]


def put(ws, ref, v, font=BLACK, fmt=None, fill=None, box=True):
    c = ws[ref]; c.value = v; c.font = font
    if box:
        c.border = BOX
    if fmt:
        c.number_format = fmt
    if fill:
        c.fill = fill
    return c


def hdr(ws, row, labels, col=1, h=None):
    for k, t in enumerate(labels):
        c = ws.cell(row=row, column=col + k, value=t); c.font = HDR; c.fill = HF
        c.alignment = Alignment(wrap_text=True, vertical="center"); c.border = BOX
    if h:
        ws.row_dimensions[row].height = h


def note(ws, ref, text):
    c = ws[ref]; c.value = text; c.font = NOTE


def widths(ws, d):
    for k, v in d.items():
        ws.column_dimensions[k].width = v


def write(path, io, res, meta):
    wb = Workbook()
    inds, names = io["inds"], io["names"]; n = len(inds); R1 = R0 + n - 1
    L = res["L"]; nl = len(L); L1 = R0 + nl - 1
    trade = res["settings"].get("trade_rows")
    MC = CL(4 + n)                                  # last matrix column (data from column E)
    MAT = lambda sh: f"{sh}!$E${R0}:${MC}${R1}"
    mcol = lambda k: CL(5 + k)                      # matrix column of industry k
    PK = ["Pre-Sept 2025", "Post-Sept 2025", "Sept 8, 2026", "Scenario"]
    spec = res["specs"][(meta["denominator"], meta["consumer"])]

    # ================================================================ README
    rd = wb.active; rd.title = "README"
    rd["A1"] = "Tariff -> CPI model on Statistics Canada's IOT tables (industry level)"; rd["A1"].font = TITLE
    lines = [
        ("What it does", "Canada's counter-tariffs on U.S. products (HS8 tariff items) -> tariff on each input-output industry's U.S. "
                         "products -> price change of every industry through the input-output network (BoC SWP 2026-35, eq. 3-5) -> CPI. "
                         "Optional market dampening: only part of a tariff reaches prices (BoC SWP 2026-36)."),
        ("No goods sections", "The Import-from-US table says which industry's U.S. product each industry buys, so tariffs go straight from "
                              "HS8 to the producing industry (BS-HS8 file) and from there to the users. aUS x Omega_US of the paper is "
                              "b(k,i) = U.S. product of k used by i / denominator of i; aCA x Omega_CA is a(j,i) = domestic product of j "
                              "used by i / denominator of i."),
        ("Equations", "dp = (I - A')^-1 B' tau.  Direct effect d = B' tau.  CPI = SUM_i hd_i dp_i + SUM_k hus_k tau_k, with hd_i = household "
                      "spending on domestic output of i / total household spending, hus_k = household purchases of U.S. products of k / "
                      "total household spending (consumer channel, Settings B5)."),
        ("IOT workbook", meta["iot"]),
        ("BS-HS8 file", f"{meta['concordance']['path']}: {meta['concordance']['lines']} lines, {meta['concordance']['hs8']} HS8 codes"),
        ("Trade", f"Canada's imports from the U.S. by HS6, CIMT, {meta['period']}" + (f" ({meta['n_months']} months)" if meta.get("n_months") else "")),
        ("Built", datetime.date.today().isoformat()),
        ("To change", "Settings B4 (denominator), B5 (consumer channel); Scenario sheet: rates and coverage by HS chapter, and overrides by "
                      "HS6 or HS8 code. Everything recalculates, including the Leontief inverse."),
    ]
    for k, (a, b) in enumerate(lines):
        put(rd, f"A{3 + k}", a, BOLD, box=False); c = put(rd, f"B{3 + k}", b, box=False); c.alignment = WRAP
    widths(rd, {"A": 18, "B": 120})

    # ================================================================ Results (filled after the other sheets exist)
    rs = wb.create_sheet("Results")

    # ================================================================ Settings
    st = wb.create_sheet("Settings")
    st["A1"] = "Settings"; st["A1"].font = TITLE
    note(st, "A2", "Yellow cells can be changed. The workbook recalculates everything, including the Leontief inverse (N6).")
    put(st, "A4", "Denominator of the input shares"); put(st, "B4", meta["denominator"], BLUE, None, YEL)
    note(st, "C4", "Intermediate inputs (as in SWP 2026-35: shares of intermediate cost) or Total output (shares of total cost)")
    put(st, "A5", "Consumer channel (households' direct purchases of U.S. imports)"); put(st, "B5", "Yes" if meta["consumer"] else "No", BLUE, None, YEL)
    for ref, opts in (("B4", "Intermediate inputs,Total output"), ("B5", "Yes,No")):
        dv = DataValidation(type="list", formula1=f'"{opts}"', allow_blank=False); st.add_data_validation(dv); dv.add(ref)
    put(st, "A6", "Canadian firms per industry N (market model)"); put(st, "B6", "=D5_Market_Inputs!B8", GREEN, "0.000")
    note(st, "C6", "Set in D5_Market_Inputs B8 (calibrated to Table F.1 at 25%, D4). The market model (D tabs) recalculates with it.")
    put(st, "A7", "Total household spending (C$ thousands), IOT Total table"); put(st, "B7", f"=SUM(N2_IOT_Total!D{R0}:D{R1})", GREEN, "#,##0")
    put(st, "A8", "Canada's total imports, all countries (C$), for average-tariff points"); put(st, "B8", static.TOTAL_IMPORTS_ALL, BLUE, "#,##0")
    put(st, "A10", "Data", H2)
    for k, (a, b) in enumerate([("IOT workbook", meta["iot"]), ("IOT sheets", ", ".join(f"{k_}={v}" for k_, v in io["sheets"].items())),
                                ("BS-HS8 file", meta["concordance"]["path"]), ("Trade period", meta["period"])]):
        put(st, f"A{11 + k}", a); put(st, f"B{11 + k}", b, BLUE)
    put(st, "A17", "NAICS 2-digit -> sector (for the sector summary)", H2); hdr(st, 18, ["NAICS 2", "Sector #", "Sector"])
    for k, (code, idx) in enumerate(sorted(static.NAICS2_TO_SECTOR.items())):
        put(st, f"A{19 + k}", code, BLUE); put(st, f"B{19 + k}", idx + 1, BLUE); put(st, f"C{19 + k}", static.SECTORS[idx])
    SMAP = f"Settings!$A$19:$B${18 + len(static.NAICS2_TO_SECTOR)}"
    widths(st, {"A": 62, "B": 22, "C": 90})

    # ================================================================ Scenario
    sc = wb.create_sheet("Scenario"); scen = meta["scenario"]
    sc["A1"] = "Custom scenario: tariff on U.S. products"; sc["A1"].font = TITLE
    note(sc, "A2", "Rate (%) and coverage (% of the chapter's U.S. imports) by HS chapter. An override (columns H-I) sets the rate of one HS6 or "
                   "HS8 code (type the code as text, e.g. 87032300). Override > chapter rate.")
    hdr(sc, 4, ["Chapter", "Description", "Rate %", "Coverage %", "U.S. imports, mapped lines (C$)", "Tariff on these imports (C$)"], h=36)
    chap = sorted(set(static.HS_CHAPTERS) | set(scen["hs2"]))
    for k, ch in enumerate(chap):
        r = R0 + k; rate, cov = scen["hs2"].get(ch, (0.0, 100.0))
        if scen.get("uniform") is not None:
            rate = scen["uniform"]
        put(sc, f"A{r}", ch, BLUE).number_format = "@"; put(sc, f"B{r}", static.HS_CHAPTERS.get(ch, ""))
        put(sc, f"C{r}", rate, BLUE, "0.0", YEL); put(sc, f"D{r}", cov, BLUE, "0", YEL)
        put(sc, f"E{r}", f"=SUMIFS(T1_HS8_Lines!$I${R0}:$I${L1},T1_HS8_Lines!$C${R0}:$C${L1},A{r})", GREEN, "#,##0")
        put(sc, f"F{r}", f"=SUMIFS(T1_HS8_Lines!$AH${R0}:$AH${L1},T1_HS8_Lines!$C${R0}:$C${L1},A{r})", GREEN, "#,##0")
    C1 = R0 + len(chap) - 1
    CHAP = f"Scenario!$A${R0}:$D${C1}"
    put(sc, f"B{C1 + 1}", "Total", BOLD); put(sc, f"E{C1 + 1}", f"=SUM(E{R0}:E{C1})", BOLD, "#,##0"); put(sc, f"F{C1 + 1}", f"=SUM(F{R0}:F{C1})", BOLD, "#,##0")
    hdr(sc, 4, ["Override code (HS6 or HS8)", "Rate %"], col=8, h=36)
    ov = list(scen["overrides"].items()); NOV = max(300, len(ov) + 50)
    for k in range(NOV):
        r = R0 + k
        a = sc[f"H{r}"]; a.number_format = "@"; a.fill = YEL; b = sc[f"I{r}"]; b.fill = YEL; b.number_format = "0.0"
        if k < len(ov):
            a.value, b.value = ov[k]; a.font = BLUE; b.font = BLUE
    OVR = f"Scenario!$H${R0}:$I${R0 + NOV - 1}"
    widths(sc, {"A": 9, "B": 40, "C": 9, "D": 11, "E": 18, "F": 18, "H": 18, "I": 9})
    sc.freeze_panes = "A5"

    # ================================================================ T2 trade by HS6
    t2 = wb.create_sheet("T2_Trade_HS6")
    t2["A1"] = f"Canada's imports from the United States by HS6, CIMT, {meta['period']} (C$)"; t2["A1"].font = TITLE
    note(t2, "A2", "Source: Statistics Canada, Canadian International Merchandise Trade (CIMT) annual import files. List flags from data/tariff_lists_hs6.csv.")
    hdr(t2, 4, ["HS6", "Description", "U.S. imports (C$)", "HS8 lines in the BS-HS8 file", "Mapped U.S. imports (C$)"], h=36)
    trade = trade or []
    for k, (h, d, v) in enumerate(trade):
        r = R0 + k
        put(t2, f"A{r}", h, BLUE).number_format = "@"; put(t2, f"B{r}", d, BLUE); put(t2, f"C{r}", v, BLUE, "#,##0")
        put(t2, f"D{r}", f"=COUNTIF(T1_HS8_Lines!$B${R0}:$B${L1},A{r})", GREEN, "0")
        put(t2, f"E{r}", f"=IF(D{r}>0,C{r},0)", BLACK, "#,##0")
    T1R = R0 + len(trade) - 1
    put(t2, f"B{T1R + 1}", "Total", BOLD); put(t2, f"C{T1R + 1}", f"=SUM(C{R0}:C{T1R})", BOLD, "#,##0"); put(t2, f"E{T1R + 1}", f"=SUM(E{R0}:E{T1R})", BOLD, "#,##0")
    TRADE = f"T2_Trade_HS6!$A${R0}:$C${T1R}"
    widths(t2, {"A": 9, "B": 70, "C": 16, "D": 12, "E": 16}); t2.freeze_panes = "A5"

    # ================================================================ T3 lists
    t3 = wb.create_sheet("T3_Lists")
    t3["A1"] = "Counter-tariff lists: official values and scaling"; t3["A1"].font = TITLE
    note(t3, "A2", "Matched = U.S. imports of the HS8 lines with the flag. HS6 flags over-cover some lists (a list item is 8 digits), so each list is "
                   "scaled down to its official value: scale = MIN(1, official / matched).")
    hdr(t3, 4, ["List", "Name", "Official value (C$)", "Matched U.S. imports (C$)", "Scale", "Flag column on T1"], h=30)
    flagcol = {"mar4": "J", "steel": "K", "alum": "L", "other": "M", "veh_pre": "N", "veh_post": "N", "sep2026": "O"}
    keys = ["mar4", "steel", "alum", "other", "veh_pre", "veh_post", "sep2026"]
    SCALE = {}
    for k, key in enumerate(keys):
        r = R0 + k; li = static.LISTS[key]; fc = flagcol[key]
        put(t3, f"A{r}", key); put(t3, f"B{r}", li["name"]); put(t3, f"C{r}", li["official"], BLUE, "#,##0")
        rng = f"T1_HS8_Lines!${fc}${R0}:${fc}${L1}"
        m = (f'=SUMPRODUCT(T1_HS8_Lines!$I${R0}:$I${L1},--({rng}<>""))' if key == "sep2026"
             else f"=SUMPRODUCT(T1_HS8_Lines!$I${R0}:$I${L1},{rng})")
        put(t3, f"D{r}", m, GREEN, "#,##0"); put(t3, f"E{r}", f"=IF(D{r}=0,0,MIN(1,C{r}/D{r}))", BLACK, "0.0000"); put(t3, f"F{r}", fc)
        SCALE[key] = f"T3_Lists!$E${r}"
    widths(t3, {"A": 10, "B": 44, "C": 18, "D": 22, "E": 9, "F": 14})

    # ================================================================ D2-D12 market model (live formulas)
    mkt = excel_market.add(wb, io, res, put, hdr, note, widths, (BLUE, BLACK, GREEN, BOLD, TITLE, H2, NOTE, WRAP, YEL, BOX), R0)
    EX, CO, KEY, N2C = mkt["EX"], mkt["CO"], mkt["KEY"], mkt["N2C"]

    # ================================================================ D1 ratios by industry
    m2 = wb.create_sheet("D1_Ratios_by_Industry")
    m2["A1"] = "Dampening ratio of each input-output industry (share of the tariff cost that reaches the price)"; m2["A1"].font = TITLE
    note(m2, "A2", "Ratio = SUM exact / SUM cost (solve tabs D8-D12) over the Table F.1 industries with the same key (NAICS 3-digit, column C; "
                   "D6 column M); if none, the same 2-digit NAICS (column D); if none, all Table F.1 industries. Increment ratio: steel and aluminum "
                   "items going from 25% to 50%. Column L: the Python solver's ratio at 25%, for the check.")
    hdr(m2, 4, ["Code", "Industry", "Key", "NAICS 2", "Rule"] + [f"Ratio at {int(t * 100)}%" for t in static.RATES] + ["Ratio 25% -> 50%", "Python: ratio at 25%"], h=36)

    def ratio(r, num, den):
        """num(sel) / den(sel) with the key -> NAICS 2 -> all fallback; num/den: functions of a SUMIFS selector."""
        by = lambda rng, crit: lambda R: f"SUMIFS({R},{rng},{crit})"
        k, n2 = by(KEY, f"$C{r}"), by(N2C, f"$D{r}")
        al = lambda R: f"SUM({R})"
        return (f"=IF(COUNTIF({KEY},$C{r})>0,({num(k)})/({den(k)}),IF(COUNTIF({N2C},$D{r})>0,({num(n2)})/({den(n2)}),"
                f"({num(al)})/({den(al)})))")
    for k, code in enumerate(inds):
        r = R0 + k
        put(m2, f"A{r}", code, BLUE); put(m2, f"B{r}", names[k], BLUE)
        put(m2, f"C{r}", f"=MID(A{r},3,3)"); put(m2, f"D{r}", f"=MID(A{r},3,2)"); put(m2, f"E{r}", res["rules"][k], BLUE)
        for j, t in enumerate(static.RATES):
            put(m2, f"{CL(6 + j)}{r}", ratio(r, lambda s, t=t: s(EX[t]), lambda s, t=t: s(CO[t])), BLACK, "0.000")
        put(m2, f"K{r}", ratio(r, lambda s: f"{s(EX[0.5])}-{s(EX[0.25])}", lambda s: f"{s(CO[0.5])}-{s(CO[0.25])}"), BLACK, "0.000")
        put(m2, f"L{r}", float(res["R"][k, static.RATES.index(0.25)]), BLUE, "0.000")
    M2 = lambda c: f"D1_Ratios_by_Industry!${c}${R0}:${c}${R1}"
    widths(m2, {"A": 11, "B": 50, "C": 6, "D": 8, "E": 26, **{CL(c): 10 for c in range(6, 13)}}); m2.freeze_panes = "C5"

    # ================================================================ T1 HS8 lines
    t1 = wb.create_sheet("T1_HS8_Lines")
    t1["A1"] = "HS8 lines: U.S. imports, counter-tariff lists, tariff change by package and dampening ratio"; t1["A1"].font = TITLE
    note(t1, "A2", "One row per (HS8, industry) pair of the BS-HS8 file. U.S. imports of a line = HS6 imports (T2) x share / HS8 lines of that HS6"
                   + (" (here: HS8 values from the HS8 trade file)." if res["settings"].get("trade8") else ".")
                   + " Tariff change: fraction (0.25 = 25 points). Ratio: D1 at the line's rate.")
    hdr(t1, 4, ["HS8", "HS6", "Chapter", "Industry (BS)", "Share of the HS8", "Description (HS6)", "U.S. imports of the HS6 (C$)",
                "HS8 lines in the HS6", "U.S. imports of the line (C$)", "Mar 4, 2025", "Mar 13: steel", "Mar 13: aluminum", "Mar 13: other",
                "Vehicles", "Sept 2026 rate %", "Sept 2026 increase %", "Sept 2026 class",
                "Tariff: pre", "Tariff: post", "Tariff: Sept 2026", "Tariff: scenario", "D1 row", "Ratio: pre", "Ratio: post",
                "Ratio: Sept 2026", "Ratio: scenario", "Dampened: pre", "Dampened: post", "Dampened: Sept 2026", "Dampened: scenario",
                "Imports x tariff: pre", "x post", "x Sept 2026", "x scenario", "Imports x dampened: pre", "x post", "x Sept 2026", "x scenario"], h=48)
    rcol = {t: CL(6 + j) for j, t in enumerate(static.RATES)}
    for i, ln in enumerate(L):
        r = R0 + i
        put(t1, f"A{r}", ln["hs8"], BLUE).number_format = "@"; put(t1, f"B{r}", f"=LEFT(A{r},6)").number_format = "@"
        put(t1, f"C{r}", f"=LEFT(A{r},2)"); put(t1, f"D{r}", ln["bs"], BLUE); put(t1, f"E{r}", ln["share"], BLUE, "0.00")
        put(t1, f"F{r}", ln["desc"], BLUE)
        if res["settings"].get("trade8"):
            put(t1, f"G{r}", None); put(t1, f"H{r}", None); put(t1, f"I{r}", ln["value"], BLUE, "#,##0")
        else:
            put(t1, f"G{r}", f"=IFERROR(VLOOKUP(B{r},{TRADE},3,FALSE),0)", GREEN, "#,##0")
            put(t1, f"H{r}", f"=SUMIF($B${R0}:$B${L1},B{r},$E${R0}:$E${L1})", BLACK, "0.00")
            put(t1, f"I{r}", f"=IF(H{r}=0,0,G{r}*E{r}/H{r})", BLACK, "#,##0")
        for c, key in zip("JKLMN", ("Mar4_2025", "Mar13_steel", "Mar13_aluminum", "Mar13_other", "Vehicles_8703_8704")):
            put(t1, f"{c}{r}", ln[key], BLUE, "0")
        put(t1, f"O{r}", ln["sep_rate"], BLUE, "0")
        put(t1, f"P{r}", f'=IF(O{r}="",0,IF(OR(K{r}=1,L{r}=1),MAX(0,O{r}-25),O{r}))', BLACK, "0")
        put(t1, f"Q{r}", f'=IF(P{r}=0,"",IF(OR(K{r}=1,L{r}=1),"25to50",TEXT(O{r},"0")))')
        put(t1, f"R{r}", f"=0.25*(J{r}*{SCALE['mar4']}+K{r}*{SCALE['steel']}+L{r}*{SCALE['alum']}+M{r}*{SCALE['other']}+N{r}*{SCALE['veh_pre']})", BLACK, "0.0000")
        put(t1, f"S{r}", f"=0.25*(K{r}*{SCALE['steel']}+L{r}*{SCALE['alum']}+N{r}*{SCALE['veh_post']})", BLACK, "0.0000")
        put(t1, f"T{r}", f"=P{r}/100*{SCALE['sep2026']}", BLACK, "0.0000")
        put(t1, f"U{r}", f"=IFERROR(VLOOKUP(A{r},{OVR},2,FALSE)/100,IFERROR(VLOOKUP(B{r},{OVR},2,FALSE)/100,"
                         f"IFERROR(VLOOKUP(C{r},{CHAP},3,FALSE)*VLOOKUP(C{r},{CHAP},4,FALSE)/10000,0)))", GREEN, "0.0000")
        put(t1, f"V{r}", f"=IFERROR(MATCH(D{r},D1_Ratios_by_Industry!$A${R0}:$A${R1},0),0)", GREEN, "0")
        rr_ = lambda t: f"INDEX({M2(rcol[t])},V{r})"
        inc = f"INDEX({M2('K')},V{r})"
        put(t1, f"W{r}", f"=IF(V{r}=0,1,{rr_(0.25)})", GREEN, "0.000"); put(t1, f"X{r}", f"=W{r}", BLACK, "0.000")
        put(t1, f"Y{r}", f'=IF(V{r}=0,1,IF(Q{r}="15",{rr_(0.15)},IF(Q{r}="50",{rr_(0.5)},IF(Q{r}="25to50",{inc},{rr_(0.25)}))))', GREEN, "0.000")
        u = f"U{r}"
        seg = lambda a, b: f"{rr_(a)}+({u}-{a})/{round(b - a, 4)}*({rr_(b)}-{rr_(a)})"
        put(t1, f"Z{r}", f"=IF(V{r}=0,1,IF({u}<=0,{rr_(0.25)},IF({u}<=0.05,{rr_(0.05)},IF({u}<=0.1,{seg(0.05, 0.1)},IF({u}<=0.15,{seg(0.1, 0.15)},"
                         f"IF({u}<=0.25,{seg(0.15, 0.25)},IF({u}<=0.5,{seg(0.25, 0.5)},{rr_(0.5)})))))))", GREEN, "0.000")
        for c, a, b in (("AA", "R", "W"), ("AB", "S", "X"), ("AC", "T", "Y"), ("AD", "U", "Z")):
            put(t1, f"{c}{r}", f"={a}{r}*{b}{r}", BLACK, "0.0000")
        for c, a in zip(("AE", "AF", "AG", "AH", "AI", "AJ", "AK", "AL"), ("R", "S", "T", "U", "AA", "AB", "AC", "AD")):
            put(t1, f"{c}{r}", f"=I{r}*{a}{r}", BLACK, "#,##0")
    put(t1, f"F{L1 + 1}", "Total", BOLD)
    for c in ["I"] + ["AE", "AF", "AG", "AH", "AI", "AJ", "AK", "AL"]:
        put(t1, f"{c}{L1 + 1}", f"=SUM({c}{R0}:{c}{L1})", BOLD, "#,##0")
    t1.freeze_panes = "E5"; t1.auto_filter.ref = f"A4:AL{L1}"
    widths(t1, {"A": 10, "B": 8, "C": 7, "D": 11, "E": 7, "F": 40, "G": 14, "H": 7, "I": 14, **{CL(c): 9 for c in range(10, 39)}})
    T1 = lambda c: f"T1_HS8_Lines!${c}${R0}:${c}${L1}"

    # ================================================================ IOT tables
    def iot_sheet(name, title, Z, H, X=None):
        z = wb.create_sheet(name)
        z["A1"] = f"{title} (C$ thousands)"; z["A1"].font = TITLE
        note(z, "A2", "Rows = supplying industry (its product), columns E onward = using industry; column D = households (PEC columns).")
        put(z, "A4", "Code", BOLD); put(z, "B4", "Industry", BOLD); put(z, "C4", "Output (Total use)" if X is not None else "", BOLD); put(z, "D4", "Households", BOLD)
        for k, code in enumerate(inds):
            put(z, f"{mcol(k)}4", code, BOLD)
        for a, code in enumerate(inds):
            r = R0 + a
            z.cell(row=r, column=1, value=code).font = BLUE; z.cell(row=r, column=2, value=names[a]).font = BLUE
            if X is not None:
                c = z.cell(row=r, column=3, value=X[a]); c.font = BLUE; c.number_format = "#,##0"
            if H[a]:
                c = z.cell(row=r, column=4, value=H[a]); c.font = BLUE; c.number_format = "#,##0"
            for b, v in enumerate(Z[a]):
                if v:
                    c = z.cell(row=r, column=5 + b, value=v); c.font = BLUE; c.number_format = "#,##0"
        z.freeze_panes = "E5"; widths(z, {"A": 11, "B": 30, "C": 14, "D": 14})
    iot_sheet("N2_IOT_Total", f"IOT Total table, {meta['iot']}", io["Z"], io["H"], io["X"])
    iot_sheet("N3_IOT_Domestic", f"IOT Domestic table, {meta['iot']}", io["Zd"], io["Hd"])
    iot_sheet("N4_IOT_US", f"IOT Import-from-US table, {meta['iot']}", io["Zus"], io["Hus"])

    # ================================================================ N1 industries
    n1 = wb.create_sheet("N1_Industries", index=wb.sheetnames.index("N2_IOT_Total"))
    n1["A1"] = "Input-output industries: shares, tariffs and price changes"; n1["A1"].font = TITLE
    note(n1, "A2", "aCA = domestic inputs / denominator, aUS = U.S. inputs / denominator (column sums of N3 and N4). Tariff of an industry = "
                   "import-weighted tariff of its HS8 lines (T1). Direct effect d_i = SUM_k (U.S. product of k used by i) x tariff_k / "
                   "denominator_i. Total effect dp = Leontief inverse (N6) x d. Price changes are fractions (0.01 = 1%).")
    labs = (["Code", "Industry", "Sector #", "Output", "Intermediate inputs", "Denominator", "aCA", "aUS", "aCA + aUS",
             "Households: domestic output", "Households: U.S. products", "Weight hd", "Weight hus", "U.S. imports, HS8 lines (C$)"]
            + [f"Tariff: {p}" for p in PK] + [f"Dampened tariff: {p}" for p in PK]
            + [f"Direct d: {p}" for p in PK] + [f"Direct d, dampened: {p}" for p in PK]
            + [f"Total dp: {p}" for p in PK] + [f"Total dp, dampened: {p}" for p in PK])
    hdr(n1, 4, labs, h=60)
    TAU = [CL(15 + j) for j in range(8)]       # O..V
    DD = [CL(23 + j) for j in range(8)]        # W..AD
    DP = [CL(31 + j) for j in range(8)]        # AE..AL
    for k, code in enumerate(inds):
        r = R0 + k; mc = mcol(k)
        put(n1, f"A{r}", code, BLUE); put(n1, f"B{r}", names[k], BLUE)
        put(n1, f"C{r}", f'=IF(A{r}="NP999999",19,IFERROR(VLOOKUP(MID(A{r},3,2),{SMAP},2,FALSE),""))', GREEN, "0")
        put(n1, f"D{r}", f"=N2_IOT_Total!C{r}", GREEN, "#,##0")
        put(n1, f"E{r}", f"=SUM(N2_IOT_Total!{mc}${R0}:{mc}${R1})", GREEN, "#,##0")
        put(n1, f"F{r}", f'=IF(Settings!$B$4="Total output",D{r},E{r})', GREEN, "#,##0")
        put(n1, f"G{r}", f"=IF(F{r}>0,SUM(N3_IOT_Domestic!{mc}${R0}:{mc}${R1})/F{r},0)", GREEN, "0.0000")
        put(n1, f"H{r}", f"=IF(F{r}>0,SUM(N4_IOT_US!{mc}${R0}:{mc}${R1})/F{r},0)", GREEN, "0.0000")
        put(n1, f"I{r}", f"=G{r}+H{r}", BLACK, "0.0000")
        put(n1, f"J{r}", f"=N3_IOT_Domestic!D{r}", GREEN, "#,##0"); put(n1, f"K{r}", f"=N4_IOT_US!D{r}", GREEN, "#,##0")
        put(n1, f"L{r}", f"=J{r}/Settings!$B$7", GREEN, "0.000000"); put(n1, f"M{r}", f"=K{r}/Settings!$B$7", GREEN, "0.000000")
        put(n1, f"N{r}", f"=SUMIFS({T1('I')},{T1('D')},A{r})", GREEN, "#,##0")
        for j, c in enumerate(["AE", "AF", "AG", "AH", "AI", "AJ", "AK", "AL"]):
            put(n1, f"{TAU[j]}{r}", f"=IF(N{r}=0,0,SUMIFS({T1(c)},{T1('D')},A{r})/N{r})", GREEN, "0.0000")
        for j in range(8):
            put(n1, f"{DD[j]}{r}", f"=IF(F{r}>0,SUMPRODUCT(N4_IOT_US!{mc}${R0}:{mc}${R1},{TAU[j]}${R0}:{TAU[j]}${R1})/F{r},0)", GREEN, "0.000000")
    n1[f"{DP[0]}{R0}"] = ArrayFormula(f"{DP[0]}{R0}:{DP[-1]}{R1}", f"=MMULT(N6_Leontief!$E${R0}:${MC}${R1},{DD[0]}{R0}:{DD[-1]}{R1})")
    for k in range(n):
        for j in range(8):
            n1[f"{DP[j]}{R0 + k}"].number_format = "0.000000"
    put(n1, f"B{R1 + 1}", "Total", BOLD)
    for c in "DEJKN":
        put(n1, f"{c}{R1 + 1}", f"=SUM({c}{R0}:{c}{R1})", BOLD, "#,##0")
    n1.freeze_panes = "C5"; n1.auto_filter.ref = f"A4:{DP[-1]}{R1}"
    widths(n1, {"A": 11, "B": 44, "C": 7, **{CL(c): 12 for c in range(4, 39)}})
    N1 = lambda c: f"N1_Industries!${c}${R0}:${c}${R1}"

    # ================================================================ N5 I - A', N6 Leontief
    n5 = wb.create_sheet("N5_I_minus_A")
    n5["A1"] = "I - A' : row i = buying industry, column j = supplying industry; A'(i, j) = domestic product of j used by i / denominator of i"
    n5["A1"].font = H2
    n6 = wb.create_sheet("N6_Leontief")
    n6["A1"] = "Leontief inverse (I - A')^-1 = MINVERSE(N5): total price effect on i (row) of a cost increase in j (column)"; n6["A1"].font = H2
    for sh in (n5, n6):
        put(sh, "A4", "Code", BOLD); put(sh, "B4", "Industry", BOLD)
        for k, code in enumerate(inds):
            put(sh, f"{mcol(k)}4", code, BOLD); sh.cell(row=R0 + k, column=1, value=code).font = BLUE
            sh.cell(row=R0 + k, column=2, value=names[k]).font = BLUE
        sh.freeze_panes = "E5"; widths(sh, {"A": 11, "B": 30})
    for i in range(n):
        r = R0 + i; ci = mcol(i)
        for j in range(n):
            c = n5.cell(row=r, column=5 + j, value=f"={1 if i == j else 0}-IF(N1_Industries!$F${r}>0,N3_IOT_Domestic!{ci}{R0 + j}/N1_Industries!$F${r},0)")
            c.number_format = "0.0000"
    n6[f"E{R0}"] = ArrayFormula(f"E{R0}:{MC}{R1}", f"=MINVERSE(N5_I_minus_A!E{R0}:{MC}{R1})")

    # ================================================================ Results
    rs["A1"] = "CPI effect of Canada's counter-tariffs on U.S. products (percentage points)"; rs["A1"].font = TITLE
    note(rs, "A2", '=" Denominator: "&Settings!B4&";  consumer channel: "&Settings!B5&".  Direct = first-round cost increase; total = through the whole network."')
    hdr(rs, 4, ["Package", "Full: direct", "Full: indirect", "Full: total", "Dampened: direct", "Dampened: indirect", "Dampened: total",
                "Dampened / full", "Python (this specification): full total", "Python: dampened total"], h=40)
    CONS = 'IF(Settings!$B$5="Yes",SUMPRODUCT({hus},{tau}),0)'
    for p in range(4):
        r = R0 + p
        put(rs, f"A{r}", static.PACKAGES[p])
        for c, dcol, tcol in (("B", DD[p], TAU[p]), ("D", DP[p], TAU[p]), ("E", DD[4 + p], TAU[4 + p]), ("G", DP[4 + p], TAU[4 + p])):
            put(rs, f"{c}{r}", f"=(SUMPRODUCT({N1('L')},{N1(dcol)})+{CONS.format(hus=N1('M'), tau=N1(tcol))})*100", GREEN, "0.00")
        put(rs, f"C{r}", f"=D{r}-B{r}", BLACK, "0.00"); put(rs, f"F{r}", f"=G{r}-E{r}", BLACK, "0.00")
        for c in ("D", "G"):
            rs[f"{c}{r}"].fill = KEYFILL; rs[f"{c}{r}"].font = Font(name=F, bold=True, color="008000")
        put(rs, f"H{r}", f"=IF(D{r}=0,0,G{r}/D{r})", BLACK, "0.000")
        put(rs, f"I{r}", float(spec["full"]["total"][p]), BLUE, "0.00"); put(rs, f"J{r}", float(spec["damp"]["total"][p]), BLUE, "0.00")
    put(rs, "A10", "Paper (SWP 2026-35, Table 2, 20 sectors, full pass-through)"); put(rs, "B10", static.PAPER_TABLE2["pre"][0], BLUE, "0.00")
    put(rs, "C10", static.PAPER_TABLE2["pre"][1], BLUE, "0.00"); put(rs, "D10", static.PAPER_TABLE2["pre"][2], BLUE, "0.00"); note(rs, "E10", "pre-Sept 2025 package")
    put(rs, "A11", "Paper, post-Sept 2025 package"); put(rs, "B11", static.PAPER_TABLE2["post"][0], BLUE, "0.00")
    put(rs, "C11", static.PAPER_TABLE2["post"][1], BLUE, "0.00"); put(rs, "D11", static.PAPER_TABLE2["post"][2], BLUE, "0.00")
    put(rs, "A12", "Custom scenario: average tariff on all imports (points)")
    put(rs, "B12", f"=SUMPRODUCT({T1('I')},{T1('U')})/Settings!$B$8*100", GREEN, "0.00")
    put(rs, "A15", "Price change by sector (%): output-weighted average of its industries", H2)
    hdr(rs, 16, ["Sector", "NAICS"] + [f"Full: {p}" for p in PK] + [f"Dampened: {p}" for p in PK], h=36)
    for i, sec in enumerate(static.SECTORS):
        r = 17 + i
        put(rs, f"A{r}", sec); put(rs, f"B{r}", static.SECTOR_NAICS[i])
        for j in range(8):
            put(rs, f"{CL(3 + j)}{r}", f"=IFERROR(SUMPRODUCT(({N1('C')}={i + 1})*{N1('D')}*{N1(DP[j])})/SUMIFS({N1('D')},{N1('C')},{i + 1})*100,0)", GREEN, "0.000")
    widths(rs, {"A": 58, **{CL(c): 13 for c in range(2, 11)}})

    # ================================================================ Checks
    ck = wb.create_sheet("Checks")
    ck["A1"] = "Checks"; ck["A1"].font = TITLE
    hdr(ck, 3, ["#", "Check", "Workbook", "Python", "Status"], h=20)
    par = spec["par"]
    items = [
        ("Output, all industries (C$ thousands)", f"=SUM({N1('D')})", float(sum(io["X"])), "eq"),
        ("Household spending (C$ thousands)", "=Settings!B7", float(io["Htot"]), "eq"),
        ("U.S. inputs, all industries (N4)", f"=SUM({MAT('N4_IOT_US')})", float(sum(map(sum, io["Zus"]))), "eq"),
        ("U.S. imports on HS8 lines (C$)", f"=SUM({T1('I')})", float(sum(x["value"] for x in L)), "eq"),
        ("Tariff revenue at full pass-through, pre-Sept 2025 (C$)", f"=SUM({T1('AE')})", float(sum(x["value"] * t for x, t in zip(L, res["T"][:, 0]))), "eq"),
        ("Largest aCA + aUS (below 1: the network converges)", f"=MAX({N1('I')})", float((par["aCA"] + par["aUS"]).max()), "lt1"),
        ("Leontief: (I - A') x inverse = identity (sum of absolute deviations, first row)",
         f"=SUMPRODUCT(ABS(MMULT(N5_I_minus_A!E{R0}:{MC}{R0},N6_Leontief!$E${R0}:${MC}${R1})-(COLUMN(N5_I_minus_A!E{R0}:{MC}{R0})=5)))", 0.0, "small"),
        ("U.S. imports with no HS8 line (share of U.S. imports)", f"=1-T2_Trade_HS6!E{T1R + 1}/T2_Trade_HS6!C{T1R + 1}",
         float(sum(v for _, _, v in res["unmapped"]) / max(1.0, sum(v for _, _, v in trade))), "info"),
        ("Industry codes in the BS-HS8 file that are not in the IOT tables", f'=SUMPRODUCT(--({T1("V")}=0))', float(len([x for x in L if x["bs"] not in set(inds)])), "zero"),
        ("Market model: largest convergence error, all solve tabs (D8-D12)", "=D3_Market_Validation!B20", 0.0, "small"),
        ("Market model: ratios at 25%, workbook vs Python solver (sum of absolute differences, D1 I vs L)",
         f"=SUMPRODUCT(ABS(D1_Ratios_by_Industry!I{R0}:I{R1}-D1_Ratios_by_Industry!L{R0}:L{R1}))", 0.0, "small"),
        ("Market model: N in use (D5 B8)", "=D5_Market_Inputs!B8", float(res["N"]), "eq"),
    ] + [(f"CPI, {static.PACKAGES[p]}: full total", f"=Results!D{R0 + p}", float(spec["full"]["total"][p]), "eq") for p in range(4)] \
      + [(f"CPI, {static.PACKAGES[p]}: dampened total", f"=Results!G{R0 + p}", float(spec["damp"]["total"][p]), "eq") for p in range(4)]
    for k, (lab, f, py, kind) in enumerate(items):
        r = 4 + k
        put(ck, f"A{r}", k + 1); put(ck, f"B{r}", lab); put(ck, f"C{r}", f, GREEN, "#,##0.0000"); put(ck, f"D{r}", py, BLUE, "#,##0.0000")
        stt = {"eq": f'=IF(ABS(C{r}-D{r})<=1e-6*MAX(1,ABS(D{r})),"PASS","REVIEW")', "lt1": f'=IF(C{r}<1,"PASS","REVIEW")',
               "small": f'=IF(C{r}<1e-6,"PASS","REVIEW")', "zero": f'=IF(C{r}=0,"PASS","REVIEW")', "info": '="INFO"'}[kind]
        put(ck, f"E{r}", stt)
    note(ck, f"B{6 + len(items)}", "Python values are for the specification chosen when the workbook was built; change Settings and the CPI rows show REVIEW.")
    widths(ck, {"A": 4, "B": 70, "C": 18, "D": 18, "E": 9})

    # ================================================================ References
    rf = wb.create_sheet("References")
    rf["A1"] = "References"; rf["A1"].font = TITLE
    for k, t in enumerate([
        "Bustamante, C. et al. (2026). The Production Network Amplification of Retaliatory Tariffs. Bank of Canada Staff Working Paper 2026-35.",
        "Bank of Canada Staff Working Paper 2026-36: market structure and tariff pass-through (Atkeson-Burstein oligopoly), Tables 3 and F.1.",
        "Statistics Canada: input-output tables with separate Domestic, Import-from-US and Imports tables (IOT workbook, on request).",
        "Statistics Canada: Canadian International Merchandise Trade (CIMT), annual import files (HS6 by country).",
        "Department of Finance Canada: lists of U.S. products subject to counter-tariffs (March 4 and March 13, 2025; September 8, 2026).",
        "U.S. Census Bureau: A Profile of U.S. Importing and Exporting Companies, 2021-2022, Table 1a (firm size classes).",
        f"BS-HS8 file: {meta['concordance']['path']}."]):
        put(rf, f"A{3 + k}", t)
    widths(rf, {"A": 140})

    # ================================================================ tabs: order, colours, sheet map (as in the earlier project)
    for name, grp, _ in SHEETS:
        ws = wb[name]; ws.sheet_properties.tabColor = GROUPS[grp][0]; ws.sheet_view.showGridLines = False
    wb._sheets = [wb[name] for name, _, _ in SHEETS]
    r0 = rd.max_row + 2
    rd.cell(row=r0, column=1, value="Sheet map").font = H2
    note(rd, f"A{r0 + 1}", "Tabs are coloured by step: yellow = inputs you can change, green = results, blue = Step 1 tariffs, orange = Step 2 market "
                           "dampening, purple = Step 3 supply-chain network, grey = checks and sources.")
    hdr(rd, r0 + 2, ["Tab", "Step and contents"])
    for i, (name, grp, what) in enumerate(SHEETS):
        r = r0 + 3 + i
        c = rd.cell(row=r, column=1, value=name); c.font = BOLD; c.hyperlink = f"#'{name}'!A1"; c.border = BOX
        c = rd.cell(row=r, column=2, value=f"{GROUPS[grp][1]}: {what}"); c.font = BLACK; c.border = BOX
    r = r0 + 4 + len(SHEETS)
    rd.cell(row=r, column=1, value="Flow").font = BOLD
    rd.cell(row=r, column=2, value="T2 trade + T3 lists + Scenario -> T1 tariff on each HS8 line (x D1 dampening ratio, from the D8-D12 market solve tabs) "
                                   "-> N1 tariff on each industry's U.S. products -> N1 direct effect (N4 U.S. flows) -> N6 Leontief inverse (N3 domestic "
                                   "flows) -> N1 total effect -> Results (household weights from N3 and N4).").alignment = WRAP
    rd.row_dimensions[r].height = 45
    wb.active = 1
    wb.save(path)
