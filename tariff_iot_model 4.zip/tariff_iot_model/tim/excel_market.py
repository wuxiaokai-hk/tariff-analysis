"""Market model (BoC SWP 2026-36) as live formulas: the D tabs, as in the earlier project.

D2_Market_Results       exact price change and ratio by Table F.1 industry and tariff rate (links to the solve tabs)
D3_Market_Validation    comparison with SWP 2026-36 Tables 3 and F.1
D4_Market_Calibration   the one calibrated number, N, and the fit at other N
D5_Market_Inputs        sigma, rho, N, damping, firm-size distribution (U.S. Census Table 1a)
D6_Market_Industries    U.S., rest-of-world and Canadian shares by industry; rest-of-world / U.S. import ratio from the IOT
D7_Market_Firms         initial shares, markups and costs of the 11 firm types
D8-D12 Solve tabs       the market equilibrium at 5, 10, 15, 25 and 50%: 50 iterations of the share equation, each a formula
"""
import numpy as np
from openpyxl.chart import Reference, ScatterChart, Series
from openpyxl.utils import get_column_letter as CL
from openpyxl.worksheet.formula import ArrayFormula

from . import market, static

NT, NIT = 11, 50
TYPES = [f"US{k + 1}" for k in range(5)] + [f"ROW{k + 1}" for k in range(5)] + ["CA"]
SOLVE = {0.05: "D8_Solve_5pct", 0.10: "D9_Solve_10pct", 0.15: "D10_Solve_15pct", 0.25: "D11_Solve_25pct", 0.50: "D12_Solve_50pct"}
KEYMAP = {313: "31A", 314: "31A", 315: "31B", 316: "31B"}


def add(wb, io, res, put, hdr, note, W, fonts, R0=5):
    BLUE, BLACK, GREEN, BOLD, TITLE, H2, NOTE, WRAP, YEL, BOX = fonts
    F1 = static.TABLE_F1; NI = len(F1); RL = R0 + NI - 1; RATES = static.RATES

    # ---------------- D5 inputs
    ip = wb.create_sheet("D5_Market_Inputs"); ip["A1"] = "Market model inputs (BoC SWP 2026-36)"; ip["A1"].font = TITLE
    hdr(ip, 3, ["Parameter", "Value", "Source / note"])
    P = [(5, "sigma: substitution between firms within an industry", static.SIGMA, "0.00", None, "SWP 2026-36 Section 3.2 (from Edmond, Midrigan and Xu, 2015)."),
         (6, "rho: substitution across industries", static.RHO, "0.00", None, "SWP 2026-36 Section 3.2."),
         (8, "N: number of equivalent Canadian firms per industry (calibrated)", res["N"], "0.000", YEL,
          "Fitted to SWP 2026-36 Table F.1 at 25% (D4_Market_Calibration). Not published in the paper."),
         (9, "Damping in the iteration", market.DAMP, "0.00", None, f"Numerical setting; {NIT} iterations converge (D3 shows the largest change in the last iteration).")]
    for row, lab, v, fmt, fill, nt in P:
        ip.cell(row=row, column=1, value=lab).font = BLACK
        put(ip, f"B{row}", v, BLUE, fmt, fill); c = ip.cell(row=row, column=3, value=nt); c.font = NOTE; c.alignment = WRAP
    ip.cell(row=11, column=1, value="Size distribution of U.S. and rest-of-world firms (share of export value)").font = H2
    hdr(ip, 12, ["Size class", "Share of known U.S. export value (%)", "Normalized share"])
    for i, (nm, v) in enumerate(static.SIZE_CLASSES):
        r = 13 + i; put(ip, f"A{r}", nm); put(ip, f"B{r}", v, BLUE, "0.0"); put(ip, f"C{r}", f"=B{r}/SUM($B$13:$B$17)", BLACK, "0.0000")
    note(ip, "A18", "U.S. Census Bureau, A Profile of U.S. Importing and Exporting Companies, 2021-2022, Table 1a (2022 exports by employment size), "
                    "grouped into five classes as SWP 2026-36 uses five size groups per origin; the same distribution is used for rest-of-world firms.")
    W(ip, {"A": 62, "B": 20, "C": 80})

    # ---------------- D6 industries
    idt = wb.create_sheet("D6_Market_Industries")
    idt["A1"] = "Industry data: SWP 2026-36 Table F.1 (25% tariff) and rest-of-world import shares"; idt["A1"].font = TITLE
    note(idt, "A2", "Columns C-G transcribed from SWP 2026-36 Table F.1. Rest-of-world / U.S. import ratio from the IOT Total table "
                    "(columns INTIM*): (total imports - imports from the U.S.) / imports from the U.S. of the industries in each group (columns O-S). "
                    "Key (M) and NAICS 2 (N): how input-output industries find their rows (D1).")
    hdr(idt, 4, ["NAICS", "Industry", "U.S. share (%)", "Paper: exact price change (%)", "Paper: first-order (%)", "Paper: markup part (%)",
                 "Paper: cost part (%)", "2-digit sector", "Rest-of-world / U.S. import ratio", "Rest-of-world share", "Canadian share",
                 "Paper ratio: exact / cost", "Key for D1", "NAICS 2 for D1"], h=48)
    for i, (nn, name, us, ex, fo, mk_, cost) in enumerate(F1):
        r = R0 + i; two = str(nn)[:2]
        put(idt, f"A{r}", nn, BLUE, "0"); put(idt, f"B{r}", name, BLUE)
        for c, v in zip("CDEFG", (us, ex, fo, mk_, cost)):
            put(idt, f"{c}{r}", v, BLUE, "0.00")
        put(idt, f"H{r}", two, BLUE)
        put(idt, f"I{r}", f"=VLOOKUP(H{r},$O$5:$S$11,5,FALSE)", BLACK, "0.000")
        put(idt, f"J{r}", f"=MIN(I{r}*C{r}/100,0.9*(1-C{r}/100))", BLACK, "0.0000")
        put(idt, f"K{r}", f"=1-C{r}/100-J{r}", BLACK, "0.0000")
        put(idt, f"L{r}", f'=IF(G{r}>0,D{r}/G{r},"")', BLACK, "0.000")
        put(idt, f"M{r}", KEYMAP.get(nn, str(nn)), BLUE); put(idt, f"N{r}", two, BLUE)
    hdr(idt, 4, ["2-digit", "IOT industries used", "Total imports (C$ thousands)", "Imports from the U.S. (C$ thousands)", "ROW/US ratio"], col=15, h=48)
    IMP = np.array(io["IMP"], float); inds = io["inds"]
    for i, (k, grp) in enumerate(static.ROW_RATIO_GROUP.items()):
        r = 5 + i
        sel = [j for j, c in enumerate(inds) if c.startswith("BS") and c[2:4] in grp]
        put(idt, f"O{r}", k, BLUE); put(idt, f"P{r}", "BS" + "/".join(grp) + (" (manufacturing, as wholesalers import manufactured goods)" if k == "41" else ""))
        put(idt, f"Q{r}", float(IMP[sel].sum()), BLUE, "#,##0"); put(idt, f"R{r}", float(IMP[sel, 0].sum()), BLUE, "#,##0")
        put(idt, f"S{r}", f"=IF(R{r}>0,(Q{r}-R{r})/R{r},0)", BLACK, "0.000")
    W(idt, {"A": 8, "B": 30, "C": 10, "D": 12, "E": 11, "F": 11, "G": 10, "H": 9, "I": 12, "J": 12, "K": 10, "L": 12, "M": 8, "N": 8,
            "O": 8, "P": 40, "Q": 16, "R": 16, "S": 10})
    KEY, N2C = f"D6_Market_Industries!$M${R0}:$M${RL}", f"D6_Market_Industries!$N${R0}:$N${RL}"

    # ---------------- D7 firms
    fm = wb.create_sheet("D7_Market_Firms")
    fm["A1"] = "Firms: 11 firm types per industry (5 U.S., 5 rest-of-world, 1 Canadian type with N firms)"; fm["A1"].font = TITLE
    note(fm, "A2", "Initial share per firm w0, number of firms n, U.S. flag, pre-tariff price p0 = w0^(1/(1-sigma)) (industry index normalized to 1), "
                   "markup mu0, marginal cost c = p0 / mu0 (SWP 2026-36 eq. 3.3-3.4).")
    blk = lambda b: [CL(3 + b * NT + j) for j in range(NT)]   # b: 0 w0, 1 n, 2 U.S. flag, 3 cost
    hdr(fm, 4, ["NAICS", "Industry"] + [f"w0 {t}" for t in TYPES] + [f"n {t}" for t in TYPES] + [f"US? {t}" for t in TYPES] + [f"cost {t}" for t in TYPES], h=40)
    MU = lambda w: f"(1/(1-(({w})/D5_Market_Inputs!$B$6+(1-({w}))/D5_Market_Inputs!$B$5)))"
    for i in range(NI):
        r = R0 + i; put(fm, f"A{r}", f"=D6_Market_Industries!A{r}", GREEN, "0"); put(fm, f"B{r}", f"=D6_Market_Industries!B{r}", GREEN)
        for j in range(NT):
            w, nn, us, cc = (blk(b)[j] for b in range(4))
            if j < 5:
                put(fm, f"{w}{r}", f"=D6_Market_Industries!$C{r}/100*D5_Market_Inputs!$C${13 + j}", GREEN, "0.000000")
            elif j < 10:
                put(fm, f"{w}{r}", f"=D6_Market_Industries!$J{r}*D5_Market_Inputs!$C${13 + j - 5}", GREEN, "0.000000")
            else:
                put(fm, f"{w}{r}", f"=D6_Market_Industries!$K{r}/D5_Market_Inputs!$B$8", GREEN, "0.000000")
            put(fm, f"{nn}{r}", 1 if j < 10 else "=D5_Market_Inputs!$B$8", BLUE if j < 10 else GREEN, "0.00")
            put(fm, f"{us}{r}", 1 if j < 5 else 0, BLUE, "0")
            put(fm, f"{cc}{r}", f"={w}{r}^(1/(1-D5_Market_Inputs!$B$5))/{MU(f'{w}{r}')}", BLACK, "0.000000")
    W(fm, {"A": 8, "B": 28}); fm.freeze_panes = "C5"

    # ---------------- solve tabs
    def solve_sheet(tau):
        nm = SOLVE[tau]; ws = wb.create_sheet(nm)
        ws["A1"] = (f"Equilibrium with a {int(round(tau * 100))}% tariff on U.S. firms: {NIT} iterations of "
                    "w_next = (1-d) w + d x (mu(w) c)^(1-sigma) / SUM n (mu(w) c)^(1-sigma)"); ws["A1"].font = TITLE
        put(ws, "A2", "Tariff rate", BOLD); put(ws, "B2", tau, BLUE, "0%")
        cT = [CL(3 + j) for j in range(NT)]; nC = [CL(3 + NT + j) for j in range(NT)]
        it0 = 3 + 2 * NT
        hdr(ws, 4, ["NAICS", "Industry"] + [f"cost after tariff {t}" for t in TYPES] + [f"n {t}" for t in TYPES], h=40)
        for k in range(NIT + 1):
            for j in range(NT):
                ws.cell(row=4, column=it0 + k * NT + j, value=f"it{k} {TYPES[j]}").font = BOLD
        fw, fn, fu, fc = (blk(b) for b in range(4))
        for i in range(NI):
            r = R0 + i; put(ws, f"A{r}", f"=D7_Market_Firms!A{r}", GREEN, "0"); put(ws, f"B{r}", f"=D7_Market_Firms!B{r}", GREEN)
            for j in range(NT):
                put(ws, f"{cT[j]}{r}", f"=D7_Market_Firms!{fc[j]}{r}*(1+$B$2*D7_Market_Firms!{fu[j]}{r})", GREEN, "0.000000")
                put(ws, f"{nC[j]}{r}", f"=D7_Market_Firms!{fn[j]}{r}", GREEN, "0.00")
            for j in range(NT):
                ws.cell(row=r, column=it0 + j, value=f"=D7_Market_Firms!{fw[j]}{r}").font = GREEN
            for k in range(1, NIT + 1):
                prev = [CL(it0 + (k - 1) * NT + j) for j in range(NT)]
                pr = f"{prev[0]}{r}:{prev[-1]}{r}"
                den = f"SUMPRODUCT(${nC[0]}{r}:${nC[-1]}{r},({MU(pr)}*${cT[0]}{r}:${cT[-1]}{r})^(1-D5_Market_Inputs!$B$5))"
                for j in range(NT):
                    pj = f"{prev[j]}{r}"
                    ws.cell(row=r, column=it0 + k * NT + j,
                            value=f"=(1-D5_Market_Inputs!$B$9)*{pj}+D5_Market_Inputs!$B$9*({MU(pj)}*${cT[j]}{r})^(1-D5_Market_Inputs!$B$5)/{den}")
        last = [CL(it0 + NIT * NT + j) for j in range(NT)]; pl = [CL(it0 + (NIT - 1) * NT + j) for j in range(NT)]
        oc = it0 + (NIT + 1) * NT + 1; O = [CL(oc + x) for x in range(5)]
        hdr(ws, 4, ["Exact price change (%)", "Cost term (%)", "Markup term (%)", "Ratio exact / cost", "Convergence (max change)"], col=oc, h=40)
        for i in range(NI):
            r = R0 + i; Lr = f"{last[0]}{r}:{last[-1]}{r}"
            put(ws, f"{O[0]}{r}", f"=LN(SUMPRODUCT(${nC[0]}{r}:${nC[-1]}{r},({MU(Lr)}*${cT[0]}{r}:${cT[-1]}{r})^(1-D5_Market_Inputs!$B$5))^(1/(1-D5_Market_Inputs!$B$5)))*100", BLACK, "0.000")
            put(ws, f"{O[1]}{r}", f"=D6_Market_Industries!C{r}/100*LN(1+$B$2)*100", GREEN, "0.000")
            put(ws, f"{O[2]}{r}", f"=SUMPRODUCT(${nC[0]}{r}:${nC[-1]}{r},D7_Market_Firms!{fw[0]}{r}:{fw[-1]}{r},LN({MU(Lr)})-LN({MU(f'D7_Market_Firms!{fw[0]}{r}:{fw[-1]}{r}')}))*100", BLACK, "0.000")
            put(ws, f"{O[3]}{r}", f'=IF({O[1]}{r}>0,{O[0]}{r}/{O[1]}{r},"")', BLACK, "0.000")
            put(ws, f"{O[4]}{r}", f"=MAX(ABS({last[0]}{r}-{pl[0]}{r}),ABS({last[4]}{r}-{pl[4]}{r}),ABS({last[-1]}{r}-{pl[-1]}{r}))", BLACK, "0.0E+00")
        W(ws, {"A": 8, "B": 28}); ws.freeze_panes = "C5"
        return nm, O
    SOL = {t: solve_sheet(t) for t in RATES}

    # ---------------- D2 results
    rs = wb.create_sheet("D2_Market_Results", index=wb.sheetnames.index("D5_Market_Inputs"))
    rs["A1"] = "Market model results: actual price effect vs full cost pass-through, by industry"; rs["A1"].font = TITLE
    note(rs, "A2", "Exact = change in the industry price index (%). Ratio = exact / cost term = share of the tariff cost that reaches prices "
                   "(dampening ratio). Paper values from SWP 2026-36 Table F.1 (25%).")
    hdr(rs, 4, ["NAICS", "Industry", "U.S. share (%)"] + [f"Exact, {int(t * 100)}%" for t in RATES] + [f"Ratio, {int(t * 100)}%" for t in RATES]
        + ["Markup term, 25%", "Paper: exact, 25%", "Paper: ratio, 25%", "Paper: markup, 25%"], h=40)
    for i in range(NI):
        r = R0 + i
        put(rs, f"A{r}", f"=D6_Market_Industries!A{r}", GREEN, "0"); put(rs, f"B{r}", f"=D6_Market_Industries!B{r}", GREEN)
        put(rs, f"C{r}", f"=D6_Market_Industries!C{r}", GREEN, "0.00")
        for k, t in enumerate(RATES):
            nm, O = SOL[t]
            put(rs, f"{CL(4 + k)}{r}", f"={nm}!{O[0]}{r}", GREEN, "0.00"); put(rs, f"{CL(9 + k)}{r}", f"={nm}!{O[3]}{r}", GREEN, "0.000")
        nm, O = SOL[0.25]; put(rs, f"N{r}", f"={nm}!{O[2]}{r}", GREEN, "0.00")
        put(rs, f"O{r}", f"=D6_Market_Industries!D{r}", GREEN, "0.00"); put(rs, f"P{r}", f"=D6_Market_Industries!L{r}", GREEN, "0.000")
        put(rs, f"Q{r}", f"=D6_Market_Industries!F{r}", GREEN, "0.00")
    W(rs, {"A": 8, "B": 30, **{CL(c): 11 for c in range(3, 18)}})
    ch = ScatterChart(); ch.title = "Exact price change at 25%: model vs paper (Table F.1)"; ch.x_axis.title = "Paper (%)"; ch.y_axis.title = "Model (%)"
    ch.height = 9; ch.width = 14
    s = Series(Reference(rs, min_col=7, min_row=R0, max_row=RL), Reference(rs, min_col=15, min_row=R0, max_row=RL), title="Industries")
    s.marker.symbol = "circle"; s.graphicalProperties.line.noFill = True; ch.series.append(s); rs.add_chart(ch, "S4")

    # ---------------- D3 validation
    vl = wb.create_sheet("D3_Market_Validation", index=wb.sheetnames.index("D5_Market_Inputs"))
    vl["A1"] = "Validation against SWP 2026-36"; vl["A1"].font = TITLE
    vl["A3"] = "1. Aggregate results by tariff rate (Table 3), not used in calibration (except 25%)"; vl["A3"].font = H2
    note(vl, "A4", "Aggregate = SUM(industry weight x industry result). Weights: Table 1 expenditure weight of each 2-digit sector, split equally "
                   "across its 3-digit industries (the paper does not publish 3-digit weights).")
    hdr(vl, 5, ["Tariff", "Model: exact (%)", "Model: cost (%)", "Model: ratio", "Paper: exact (%)", "Paper: cost (%)", "Paper: ratio", "Model ratio - paper ratio"], h=32)
    hdr(vl, 5, ["2-digit", "Table 1 weight (%)", "Industries", "Weight per industry (%)"], col=11)
    for i, (k, wt) in enumerate(static.TABLE1_WEIGHTS.items()):
        r = 6 + i; put(vl, f"K{r}", k, BLUE); put(vl, f"L{r}", wt, BLUE, "0.00")
        put(vl, f"M{r}", f"=COUNTIF(D6_Market_Industries!$H$5:$H${RL},K{r})", BLACK, "0"); put(vl, f"N{r}", f"=L{r}/M{r}", BLACK, "0.000")
    for i, t in enumerate([0.05, 0.10, 0.25, 0.50]):
        r = 6 + i; nm, O = SOL[t]
        wv = f"SUMIF($K$6:$K$12,D6_Market_Industries!$H$5:$H${RL},$N$6:$N$12)"
        put(vl, f"A{r}", t, BLUE, "0%")
        put(vl, f"B{r}", f"=SUMPRODUCT({wv},{nm}!{O[0]}5:{O[0]}{RL})/100", BLACK, "0.000")
        put(vl, f"C{r}", f"=SUMPRODUCT({wv},{nm}!{O[1]}5:{O[1]}{RL})/100", BLACK, "0.000")
        put(vl, f"D{r}", f"=B{r}/C{r}", BLACK, "0.000")
        pe, pc = static.TABLE3[t]
        put(vl, f"E{r}", pe, BLUE, "0.00"); put(vl, f"F{r}", pc, BLUE, "0.00"); put(vl, f"G{r}", f"=E{r}/F{r}", BLACK, "0.000")
        put(vl, f"H{r}", f"=D{r}-G{r}", BLACK, "+0.000;-0.000")
    vl["A12"] = "2. Industry results at 25% (Table F.1), the calibration target"; vl["A12"].font = H2
    hdr(vl, 13, ["Statistic", "Value"])
    conv = "=MAX(" + ",".join(f"{SOL[t][0]}!{SOL[t][1][4]}5:{SOL[t][1][4]}{RL}" for t in RATES) + ")"
    ST = [("Correlation, exact: model vs paper", f"=CORREL(D2_Market_Results!G5:G{RL},D2_Market_Results!O5:O{RL})", "0.000"),
          ("Sum of exact effects: model", f"=SUM(D2_Market_Results!G5:G{RL})", "0.00"), ("Sum of exact effects: paper", f"=SUM(D2_Market_Results!O5:O{RL})", "0.00"),
          ("Correlation, markup term: model vs paper", f"=CORREL(D2_Market_Results!N5:N{RL},D2_Market_Results!Q5:Q{RL})", "0.000"),
          ("Median ratio, model (industries with paper exact > 0.3%)", f"=MEDIAN(IF(D2_Market_Results!O5:O{RL}>0.3,D2_Market_Results!L5:L{RL}))", "0.000"),
          ("Median ratio, paper (same industries)", f"=MEDIAN(IF(D2_Market_Results!O5:O{RL}>0.3,D2_Market_Results!P5:P{RL}))", "0.000"),
          ("Largest convergence error, all solve tabs", conv, "0.0E+00")]
    for i, (lab, f, fmt) in enumerate(ST):
        r = 14 + i; put(vl, f"A{r}", lab)
        if "MEDIAN(IF" in f:
            vl[f"B{r}"] = ArrayFormula(f"B{r}", f); vl[f"B{r}"].number_format = fmt; vl[f"B{r}"].border = BOX
        else:
            put(vl, f"B{r}", f, BLACK, fmt)
    W(vl, {"A": 52, "B": 14, "C": 14, "D": 14, "E": 14, "F": 14, "G": 14, "H": 16, "K": 10, "L": 14, "M": 10, "N": 14})

    # ---------------- D4 calibration
    cb = wb.create_sheet("D4_Market_Calibration", index=wb.sheetnames.index("D5_Market_Inputs"))
    cb["A1"] = "Calibration of N (number of equivalent Canadian firms)"; cb["A1"].font = TITLE
    rowsC = [("What is calibrated", "Only N (D5_Market_Inputs B8). SWP 2026-36 uses Canadian firm data (NALMF) that is not public and does not report the number of Canadian firms per industry."),
             ("Target", "Sum of squared differences between model and paper exact price changes at 25%, over the paper's 32 industries (Table F.1)."),
             ("Result", f"N = {res['N']:.3f} minimizes the target (golden-section search in Python, tim/market.py). To re-check, change D5_Market_Inputs B8 and watch B8 below, "
                        "or run Excel Solver: minimize D4_Market_Calibration!B8 by changing D5_Market_Inputs!B8. The table at right shows the target at other N."),
             ("Why it matters", "With few Canadian firms (N = 3-5), they are large, gain share when U.S. prices rise and raise markups, offsetting U.S. markup cuts; "
                                "effects come out well above the paper. With N around 16-20 the model matches the paper's industry pattern and its aggregate results at other rates.")]
    for i, (a, b) in enumerate(rowsC):
        r = 3 + i; cb.cell(row=r, column=1, value=a).font = BOLD; c = cb.cell(row=r, column=2, value=b); cb.row_dimensions[r].height = 32; c.font = BLACK; c.alignment = WRAP
    put(cb, "A8", "Sum of squared differences at the current N", BOLD); put(cb, "B8", f"=SUMXMY2(D2_Market_Results!G5:G{RL},D2_Market_Results!O5:O{RL})", BLACK, "0.000")
    hdr(cb, 10, ["N", "Sum of squared differences (same model run in Python at each N)"], col=4)
    for i, Nv in enumerate([3, 5, 8, 10, 12, 14, 16, 18, 20, 25, 30, 40, 60]):
        put(cb, f"D{11 + i}", float(Nv), BLUE, "0"); put(cb, f"E{11 + i}", market.sse_25(res["rr"], Nv), BLUE, "0.00")
    W(cb, {"A": 28, "B": 110, "D": 8, "E": 40})

    EX = {t: f"{SOL[t][0]}!${SOL[t][1][0]}${R0}:${SOL[t][1][0]}${RL}" for t in RATES}
    CO = {t: f"{SOL[t][0]}!${SOL[t][1][1]}${R0}:${SOL[t][1][1]}${RL}" for t in RATES}
    return dict(EX=EX, CO=CO, KEY=KEY, N2C=N2C, SOL=SOL, RL=RL)
