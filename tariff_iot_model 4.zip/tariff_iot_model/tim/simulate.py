"""Build a SIMULATED BS-HS8 file (two columns: input-output industry code, HS8 tariff item) for testing.

Not Statistics Canada data. Each HS8 code is given the input-output industry (BS code) that makes the product, by
rules on HS chapters, headings and subheadings (the longest matching HS prefix wins). The HS8 codes are built from
the HS6 codes in the CIMT trade file: HS6 + "00" for every product, and also HS6 + "90" in chapters 84, 85 and 87,
so that some HS6 products have more than one HS8 line (as in the real tariff schedule).

Run:  python -m tim.simulate [--trade data/processed/us_imports_2024-01_2024-12.csv] [--out FILE.xlsx]
"""
import argparse
import csv
import os

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# (HS prefix, BS code). Prefixes of 2, 4 or 6 digits; the longest match is used.
RULES = [
    ("01", "BS112A00"), ("0106", "BS112A00"),
    ("02", "BS311600"),
    ("03", "BS114000"), ("0303", "BS311700"), ("0304", "BS311700"), ("0305", "BS311700"),
    ("04", "BS311500"), ("0407", "BS112A00"), ("0408", "BS311900"), ("0409", "BS112A00"), ("0410", "BS311900"),
    ("05", "BS112A00"),
    ("06", "BS1114A0"),
    ("07", "BS111A00"), ("0710", "BS311400"), ("0711", "BS311400"), ("0712", "BS311400"),
    ("08", "BS111A00"), ("0811", "BS311400"), ("0812", "BS311400"), ("0813", "BS311400"), ("0814", "BS311400"),
    ("09", "BS311900"),
    ("10", "BS111A00"),
    ("11", "BS311200"),
    ("12", "BS111A00"), ("1211", "BS111A00"), ("1213", "BS111A00"),
    ("13", "BS311900"),
    ("14", "BS111A00"),
    ("15", "BS311200"), ("1501", "BS311600"), ("1502", "BS311600"), ("1503", "BS311600"), ("1504", "BS311700"),
    ("1505", "BS311600"), ("1506", "BS311600"),
    ("16", "BS311600"), ("1604", "BS311700"), ("1605", "BS311700"),
    ("17", "BS311300"),
    ("18", "BS311300"),
    ("19", "BS311800"), ("1901", "BS311900"), ("1904", "BS311200"),
    ("20", "BS311400"),
    ("21", "BS311900"),
    ("22", "BS3121A0"), ("2201", "BS312110"), ("2202", "BS312110"), ("2203", "BS312120"), ("2209", "BS311900"),
    ("23", "BS311100"),
    ("24", "BS312A00"), ("2401", "BS111A00"),
    ("25", "BS21239A"), ("2505", "BS212320"), ("2507", "BS212320"), ("2508", "BS212320"), ("2515", "BS212310"),
    ("2516", "BS212310"), ("2517", "BS212310"), ("2520", "BS327A00"), ("2522", "BS327A00"), ("2523", "BS327300"),
    ("26", "BS212290"), ("2601", "BS212210"), ("2603", "BS212230"), ("2604", "BS212230"), ("2607", "BS212230"),
    ("2608", "BS212230"), ("2616", "BS212220"),
    ("27", "BS3241A0"), ("2701", "BS212100"), ("2709", "BS211110"), ("2710", "BS324110"), ("2711", "BS211110"),
    ("2716", "BS221100"),
    ("28", "BS325100"), ("2814", "BS325300"),
    ("29", "BS325100"),
    ("30", "BS325400"),
    ("31", "BS325300"), ("3104", "BS212396"),
    ("32", "BS325500"), ("3201", "BS325100"), ("3202", "BS325100"), ("3203", "BS325100"), ("3204", "BS325100"),
    ("3205", "BS325100"), ("3206", "BS325100"), ("3215", "BS325900"),
    ("33", "BS325600"),
    ("34", "BS325600"), ("3403", "BS324110"), ("3404", "BS325900"), ("3406", "BS339900"), ("3407", "BS325900"),
    ("35", "BS325500"), ("3501", "BS311500"), ("3502", "BS311900"), ("3505", "BS311200"), ("3507", "BS325900"),
    ("36", "BS325900"),
    ("37", "BS325900"),
    ("38", "BS325900"), ("3808", "BS325300"),
    ("39", "BS326100"), *[(f"39{h:02d}", "BS325200") for h in range(1, 16)],
    ("40", "BS326200"), ("4001", "BS111A00"), ("4002", "BS325200"),
    ("41", "BS31B000"), ("4101", "BS311600"), ("4102", "BS311600"), ("4103", "BS311600"),
    ("42", "BS31B000"), ("43", "BS31B000"),
    ("44", "BS321900"), ("4401", "BS113000"), ("4403", "BS113000"), ("4404", "BS113000"), ("4406", "BS321100"),
    ("4407", "BS321100"), ("4408", "BS321200"), ("4410", "BS321200"), ("4411", "BS321200"), ("4412", "BS321200"),
    ("45", "BS321900"), ("46", "BS321900"),
    ("47", "BS322100"),
    ("48", "BS322200"), ("4801", "BS322100"), ("4802", "BS322100"), ("4803", "BS322100"), ("4804", "BS322100"),
    ("4805", "BS322100"),
    ("49", "BS323000"),
    *[(f"{c}", "BS31A000") for c in range(50, 61)],
    ("61", "BS31B000"), ("62", "BS31B000"), ("63", "BS31A000"), ("64", "BS31B000"), ("65", "BS31B000"),
    ("66", "BS339900"), ("67", "BS339900"),
    ("68", "BS327A00"), ("6810", "BS327300"), ("6811", "BS327300"),
    ("69", "BS327A00"), ("70", "BS327A00"),
    ("71", "BS339900"), ("7101", "BS212392"), ("7102", "BS212392"), ("7103", "BS212392"), ("7104", "BS212392"),
    *[(f"71{h:02d}", "BS331400") for h in range(6, 13)],
    ("72", "BS331100"),
    ("73", "BS332B00"), *[(f"73{h:02d}", "BS331200") for h in range(1, 7)], ("7308", "BS332300"),
    ("7309", "BS332400"), ("7310", "BS332400"), ("7311", "BS332400"), ("7318", "BS332700"),
    ("74", "BS331400"), ("75", "BS331400"),
    ("76", "BS331300"), ("7610", "BS332300"), ("7611", "BS332400"), ("7612", "BS332400"), ("7613", "BS332400"),
    ("7614", "BS332B00"), ("7615", "BS332B00"), ("7616", "BS332B00"),
    ("78", "BS331400"), ("79", "BS331400"), ("80", "BS331400"), ("81", "BS331400"),
    ("82", "BS332B00"), ("83", "BS332B00"),
    ("84", "BS333900"), *[(f"84{h:02d}", "BS333600") for h in range(1, 13)], ("8409", "BS336300"),
    ("8415", "BS333400"), ("8418", "BS335B00"), ("8419", "BS333200"), ("8422", "BS335B00"), ("8424", "BS333100"),
    *[(f"84{h:02d}", "BS333100") for h in range(29, 37)], *[(f"84{h:02d}", "BS333200") for h in range(37, 50)],
    ("8443", "BS334C00"), ("8450", "BS335B00"), ("8451", "BS333200"), ("8452", "BS333200"), ("8453", "BS333200"),
    *[(f"84{h:02d}", "BS333500") for h in range(54, 67)], ("8468", "BS333500"),
    *[(f"84{h:02d}", "BS334C00") for h in range(70, 74)], *[(f"84{h:02d}", "BS333200") for h in range(74, 81)],
    ("8481", "BS332B00"), ("8482", "BS332B00"), ("8483", "BS333600"),
    ("85", "BS335900"), *[(f"85{h:02d}", "BS335300") for h in range(1, 5)], ("8508", "BS335B00"), ("8509", "BS335B00"),
    ("8510", "BS335B00"), ("8511", "BS336300"), ("8512", "BS336300"), ("8513", "BS335B00"), ("8514", "BS333900"),
    ("8515", "BS333900"), ("8516", "BS335B00"), ("8517", "BS334200"), *[(f"85{h:02d}", "BS334C00") for h in range(18, 24)],
    *[(f"85{h:02d}", "BS334200") for h in range(25, 32)], ("8532", "BS334400"), ("8533", "BS334400"), ("8534", "BS334400"),
    *[(f"85{h:02d}", "BS335300") for h in range(35, 39)], ("8539", "BS335B00"), *[(f"85{h:02d}", "BS334400") for h in range(40, 44)],
    ("86", "BS336500"),
    ("87", "BS336900"), ("8701", "BS333100"), ("8702", "BS336120"), ("8703", "BS336110"), ("8704", "BS336110"),
    ("870422", "BS336120"), ("870423", "BS336120"), ("870432", "BS336120"), ("8705", "BS336120"), ("8706", "BS336110"),
    ("8707", "BS336200"), ("8708", "BS336300"), ("8709", "BS333900"), ("8715", "BS339900"), ("8716", "BS336200"),
    ("88", "BS336400"), ("89", "BS336600"),
    ("90", "BS334C00"), *[(f"90{h:02d}", "BS339100") for h in range(18, 22)],
    ("91", "BS334C00"), ("92", "BS339900"), ("93", "BS332B00"),
    ("94", "BS337100"), ("940120", "BS336300"), ("940310", "BS337200"), ("940330", "BS337200"), ("9404", "BS337900"),
    ("9405", "BS335B00"), ("9406", "BS321900"),
    ("95", "BS339900"), ("96", "BS339900"), ("97", "BS339900"),
]


def industry_of(hs):
    best = None
    for p, bs in RULES:
        if hs.startswith(p) and (best is None or len(p) > len(best[0])):
            best = (p, bs)
    return best[1] if best else None


def build(hs6_codes):
    rows = []
    for h in sorted(set(hs6_codes)):
        bs = industry_of(h)
        if bs is None:          # chapters 98-99 (special classifications) are not mapped
            continue
        rows.append((bs, h + "00"))
        if h[:2] in ("84", "85", "87"):
            rows.append((bs, h + "90"))
    return rows


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--trade", default=os.path.join(HERE, "data", "processed", "us_imports_2024-01_2024-12.csv"))
    ap.add_argument("--out", default=os.path.join(HERE, "data", "simulated", "SIMULATED_BS_HS8.xlsx"))
    a = ap.parse_args()
    hs6 = [r["HS6"] for r in csv.DictReader(open(a.trade, encoding="utf-8"))]
    rows = build(hs6)
    from openpyxl import Workbook
    wb = Workbook(); ws = wb.active; ws.title = "BS_HS8"
    ws.append(["BS code", "HS8"])
    for bs, h8 in rows:
        ws.append([bs, h8])
    ws.column_dimensions["A"].width = 12; ws.column_dimensions["B"].width = 12
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    wb.save(a.out)
    print(f"Wrote {a.out}: {len(rows)} HS8 lines, {len(set(b for b, _ in rows))} industries (SIMULATED, rule-based)")


if __name__ == "__main__":
    main()
