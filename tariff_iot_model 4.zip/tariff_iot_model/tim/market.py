"""Market model (BoC SWP 2026-36): how much of a tariff's cost reaches the price of an industry's products.

For each Table F.1 industry (NAICS 3-digit) and tariff rate: 11 firm types (5 U.S. and 5 rest-of-world size classes,
one each; the Canadian type with N identical firms), nested CES with sigma = 10.5 within and rho = 1.24 across
industries, markups mu(w) = 1 / (1 - (w/rho + (1-w)/sigma)). Ratio = exact price change / full cost change.
N is calibrated so the model's exact price changes at 25% match Table F.1 (least squares).

Each input-output industry (BS code) gets the ratio of the Table F.1 industries with its NAICS 3-digit code
(BS31A000 -> 313 + 314, BS31B000 -> 315 + 316); if none, the Table F.1 industries of its 2-digit code; else all.
"""
import math

import numpy as np

from . import static

ITERS, DAMP = 50, 0.5


def mu(w):
    return 1 / (1 - (w / static.RHO + (1 - w) / static.SIGMA))


def size_shares():
    q = np.array([v for _, v in static.SIZE_CLASSES]); return q / q.sum()


def row_ratios(io):
    """Rest-of-world / U.S. imports by 2-digit group, from the Total table's import columns (INTIM*)."""
    IMP = np.array(io["IMP"], float)
    M, MUS = IMP.sum(1), IMP[:, 0]
    two = [c[2:4] for c in io["inds"]]
    out = {}
    for k, grp in static.ROW_RATIO_GROUP.items():
        sel = [i for i, t in enumerate(two) if io["inds"][i].startswith("BS") and t in grp]
        m, mu_ = M[sel].sum(), MUS[sel].sum()
        out[k] = (m - mu_) / mu_ if mu_ > 0 else 0.0
    return out


def industry_firms(us_share, rr, N):
    q = size_shares(); u = us_share / 100
    row = min(rr * u, 0.9 * (1 - u)); ca = 1 - u - row
    n = np.r_[np.ones(10), N]
    w0 = np.r_[u * q, row * q, ca / N]
    us = np.r_[np.ones(5), np.zeros(6)].astype(bool)
    return n, w0, us


def solve(n, w0, us, tau, iters=ITERS, damp=DAMP):
    S = static.SIGMA
    p0 = w0 ** (1 / (1 - S)); c = p0 / mu(w0); c1 = c * np.where(us, 1 + tau, 1)
    w = w0.copy(); prev = w
    for _ in range(iters):
        prev = w
        x = (mu(w) * c1) ** (1 - S)
        w = (1 - damp) * w + damp * x / (n * x).sum()
    p = mu(w) * c1
    exact = math.log(((n * p ** (1 - S)).sum()) ** (1 / (1 - S))) * 100
    cost = (n * w0 * np.where(us, math.log(1 + tau), 0)).sum() * 100
    mk = (n * w0 * (np.log(mu(w)) - np.log(mu(w0)))).sum() * 100
    conv = max(abs(w[0] - prev[0]), abs(w[4] - prev[4]), abs(w[-1] - prev[-1]))
    return exact, cost, mk, conv, w


def run_market(rr, N, rates=static.RATES):
    """{rate: array (Table F.1 industries x [exact, cost, markup, convergence])}."""
    out = {}
    for t in rates:
        rows = []
        for (naics, name, us, *_rest) in static.TABLE_F1:
            n, w0, usf = industry_firms(us, rr[str(naics)[:2]], N)
            e, c, m, cv, _ = solve(n, w0, usf, t)
            rows.append((e, c, m, cv))
        out[t] = np.array(rows)
    return out


def sse_25(rr, N):
    paper = np.array([f[3] for f in static.TABLE_F1])
    e = run_market(rr, N, [0.25])[0.25][:, 0]
    return float(((e - paper) ** 2).sum())


def calibrate_N(rr, lo=2.0, hi=60.0, tol=1e-4):
    a, b = math.log(lo), math.log(hi); g = (math.sqrt(5) - 1) / 2
    c, d = b - g * (b - a), a + g * (b - a)
    fc, fd = sse_25(rr, math.exp(c)), sse_25(rr, math.exp(d))
    while b - a > tol:
        if fc < fd:
            b, d, fd = d, c, fc; c = b - g * (b - a); fc = sse_25(rr, math.exp(c))
        else:
            a, c, fc = c, d, fd; d = a + g * (b - a); fd = sse_25(rr, math.exp(d))
    return math.exp((a + b) / 2)


def f1_rows(code):
    """Table F.1 row indices used for an input-output industry, and how they were chosen."""
    naics = [f[0] for f in static.TABLE_F1]
    key = code[2:5]
    if key in static.F1_GROUPS:
        want = static.F1_GROUPS[key]; rule = f"NAICS {'+'.join(map(str, want))}"
    elif key.isdigit():
        want = [int(key)]; rule = f"NAICS {key}"
    else:
        want = []; rule = ""
    rows = [i for i, n in enumerate(naics) if n in want]
    if not rows:
        rows = [i for i, n in enumerate(naics) if str(n)[:2] == code[2:4]]; rule = f"NAICS {code[2:4]} (2-digit)"
    if not rows:
        rows = list(range(len(naics))); rule = "all Table F.1 industries"
    return rows, rule


def industry_ratios(mk, inds):
    """R (industries x [5%, 10%, 15%, 25%, 50%, 25%->50% increment]) and the rule used for each industry."""
    R = np.zeros((len(inds), len(static.RATES) + 1)); rules = []
    for k, code in enumerate(inds):
        ii, rule = f1_rows(code); rules.append(rule)
        for j, t in enumerate(static.RATES):
            R[k, j] = mk[t][ii, 0].sum() / mk[t][ii, 1].sum()
        R[k, -1] = (mk[0.5][ii, 0].sum() - mk[0.25][ii, 0].sum()) / (mk[0.5][ii, 1].sum() - mk[0.25][ii, 1].sum())
    return R, rules


def interp(Rk, rate):
    """Ratio at any rate: linear between 5, 10, 15, 25 and 50%, flat outside."""
    return float(np.interp(rate, static.RATES, Rk[:len(static.RATES)]))


def line_ratios(L, R, inds):
    """Dampening ratio of each HS8 line in each package (lines x 4), at the line's nominal rate."""
    ix = {c: k for k, c in enumerate(inds)}; k25 = static.RATES.index(0.25)
    col = {"15": static.RATES.index(0.15), "25": k25, "50": static.RATES.index(0.5), "25to50": -1}
    P = np.ones((len(L), 4))
    for i, r in enumerate(L):
        k = ix.get(r["bs"])
        if k is None:
            continue
        P[i, 0] = P[i, 1] = R[k, k25]
        P[i, 2] = R[k, col[r["sep_class"]]] if r["sep_class"] else R[k, k25]
        P[i, 3] = interp(R[k], r["scen_rate"]) if r["scen_rate"] > 0 else R[k, k25]
    return P


def validation(mk):
    two = [str(f[0])[:2] for f in static.TABLE_F1]
    cnt = {k: two.count(k) for k in static.TABLE1_WEIGHTS}
    wt = np.array([static.TABLE1_WEIGHTS[k] / cnt[k] for k in two]) / 100
    out = []
    for t, (pe, pc) in static.TABLE3.items():
        e, c = (wt * mk[t][:, 0]).sum(), (wt * mk[t][:, 1]).sum()
        out.append(dict(rate=t, exact=e, cost=c, ratio=e / c, paper_exact=pe, paper_cost=pc, paper_ratio=pe / pc))
    paper = np.array([f[3] for f in static.TABLE_F1])
    return out, float(np.corrcoef(mk[0.25][:, 0], paper)[0, 1])
