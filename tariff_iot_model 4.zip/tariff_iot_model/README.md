# tariff_iot_model

Price effect of Canada's counter-tariffs on U.S. products, built directly on Statistics Canada's IOT tables
(separate **Domestic** and **Import from US** tables), at the level of the input-output industries.

It follows the two Bank of Canada papers:

- **Network model:** BoC SWP 2026-35, eq. 3–5 (Bustamante et al., *The Production Network Amplification of Retaliatory Tariffs*).
- **Market dampening:** BoC SWP 2026-36 (Atkeson–Burstein oligopoly).

This is a separate project from `tariff_price_model`. There are **no goods sections** and no 20-sector aggregation:

- The **BS–HS8 file** says which industry makes each HS8 tariff item.
- The **Import-from-US table** says which industry buys each industry's U.S. product.
- So a tariff goes HS8 → producing industry → every industry that uses that product → CPI.

## Run

```
pip install -r requirements.txt          # numpy, openpyxl
python run.py --iot IOT.xlsx --concordance BS_HS8.xlsx
python tests/test_model.py
```

Try it on the simulated files:

```
python run.py --iot data/simulated/SIMULATED_IOT_2024.xlsx --concordance data/simulated/SIMULATED_BS_HS8.xlsx
```

**Outputs** (folder `output/`):

- `summary_*.csv`: CPI by package and specification, plus the price change by sector.
- `industries_*.csv`: each industry's aCA, aUS, tariffs and price changes.
- `Tariff_IOT_Model_*.xlsx`: the same calculation as live formulas.

## Inputs

| Input | Format |
|---|---|
| IOT workbook (`--iot`) | Sheets **Total**, **Domestic**, **Import from US** (needed) and **Imports** (optional), recognised by name, or set them with `--iot-sheets total=...,domestic=...,us=...`. Wide layout: industry codes down the left with titles in the next column; use codes across the top with titles in the next row. **The code row and code column are found automatically** (row 6 or 7, column B, and so on); each sheet's layout is printed. The output column can be called "Total use", "Total" or "TOTAL". |
| BS–HS8 file (`--concordance`) | Two columns: industry code (BS…) and HS8 tariff item, `.xlsx` or `.csv`. The columns are found by content, a header row is skipped, and HS8 codes typed as numbers get their leading zero back. An HS8 listed with two industries is split equally between them. |
| Trade | Canada's imports from the U.S. by HS6, Statistics Canada CIMT annual files. Downloaded for `--trade-start`/`--trade-end` (default 2024) and cached in `data/processed`. |
| Lists | `data/tariff_lists_hs6.csv` (flags by HS6). `python -m tim.tariff_lists` rebuilds it from the Finance Canada pages and also writes `data/tariff_lists_hs8.csv`; use that with `--lists-hs8` to flag only the listed HS8 items. |
| Scenario | `data/scenario_hs2.csv` (rate % and coverage % by HS chapter) and `data/scenario_overrides.csv` (`code,rate_pct`, for an HS6 or HS8 code). |

The IOT workbook is cached in `data/processed` under a key built from the file's size and modification time.
**Edit or replace the workbook and it is read again automatically**; there is no `--refresh` to remember.

## Method

**1. Tariff on each HS8 line** (an HS8 code paired with an industry):

| Package | Tariff change |
|---|---|
| Pre-Sept 2025 | 25% × (March 4 list + steel + aluminum + other goods + vehicles) |
| Post-Sept 2025 | 25% × (steel + aluminum + vehicles) |
| Sept 8, 2026 | The increase over the rate already in force (steel and aluminum items: rate − 25) |
| Scenario | Chapter rate × coverage, or an override for the HS6 or HS8 code |

Each list is scaled to its official value: scale = min(1, official ÷ matched U.S. imports).

**2. U.S. imports of a line** = the HS6 value from CIMT × the line's share ÷ the number of HS8 lines of that HS6.
CIMT's bulk files are at HS6, so the value is split equally. If you have HS8 trade values, pass them with
`--trade-hs8 FILE` (columns `HS8,value`).

**3. Tariff on industry k's U.S. products:** τ_k = Σ (imports × tariff) ÷ Σ imports, over the HS8 lines of k.

**4. Dampening (SWP 2026-36):**

- The market model is solved for the 32 Table F.1 industries, with N calibrated to Table F.1 at 25%.
- Each IOT industry takes the ratio of the Table F.1 industries with the same NAICS 3-digit code. BS31A000 uses
  313 + 314 and BS31B000 uses 316. If no 3-digit match exists, it uses the same 2-digit code; failing that, all of Table F.1.
- Each line's ratio is taken at its own rate. Steel and aluminum items going from 25% to 50% in September 2026 use
  the increment ratio. Scenario lines are interpolated between 5, 10, 15, 25 and 50%.
- Dampened tariff = tariff × ratio.

**5. Network (SWP 2026-35), industry level:**

```
dp_i = SUM_k b_ki tau_k + SUM_j a_ji dp_j        dp = (I - A')^-1 B' tau
b_ki = Zus[k, i] / den_i     (Import-from-US table: U.S. product of k used by i)
a_ji = Zd[j, i]  / den_i     (Domestic table: domestic product of j used by i)
den_i = SUM_j Z[j, i]        (Total table: intermediate inputs of i)  — or the output of i (Settings / --denominator)
```

In the paper's notation, aUS_i = Σ_k b_ki and Ω_US(i, k) = b_ki ÷ aUS_i; likewise aCA_i = Σ_j a_ji and Ω_CA(i, j) = a_ji ÷ aCA_i.
The IOT tables give these directly, so no proportionality assumption and no goods sections are needed.

**6. CPI:**

```
dP = SUM_i (Hd_i / H) dp_i  +  SUM_k (Hus_k / H) tau_k
```

- Hd_i: households' spending on the domestic output of i (Domestic table, PEC columns).
- Hus_k: households' purchases of the U.S. products of k (Import-from-US table).
- H: total household spending (Total table).
- The second term is the consumer channel (`--no-consumer` turns it off). It is an extension of the paper.

## Excel workbook

Format as the earlier project: Arial, navy headers, thin borders, and tabs coloured by step
(yellow = inputs, green = results, blue = Step 1 tariffs, orange = Step 2 dampening, purple = Step 3 network, grey = checks).
Blue numbers = data, black = formulas, green = links to other sheets.


| Sheet | Contents |
|---|---|
| Results | CPI by package: full and dampened, direct / indirect / total; price change by sector |
| Settings | **B4** denominator, **B5** consumer channel (yellow), N, data used |
| Scenario | Rate and coverage by HS chapter; overrides by HS6 or HS8 code (yellow) |
| T1_HS8_Lines | Each line: U.S. imports, list flags, tariff by package, dampening ratio, dampened tariff |
| T2_Trade_HS6 / T3_Lists | CIMT trade by HS6; official list values and scaling |
| D1_Ratios_by_Industry | Dampening ratio of each IOT industry at 5–50% and for 25% → 50% (formulas on the solve tabs) |
| D2–D7 | Market model (SWP 2026-36): results, validation against Tables 3 and F.1, calibration of N, inputs, industries, firms |
| D8–D12 | The market equilibrium at 5, 10, 15, 25 and 50%: 50 iterations of the share equation, all formulas (change N in D5 B8 and everything follows) |
| N1_Industries | Each industry: denominator, aCA, aUS, household weights, tariffs, direct effect d, total effect dp |
| N2–N4 | The Total, Domestic and Import-from-US tables |
| N5_I_minus_A / N6_Leontief | I − A′ and its inverse (`MINVERSE`, recalculates live) |
| Checks | Workbook vs Python, convergence, Leontief check, unmapped imports |

The Python results are checked against the workbook recalculated in LibreOffice: every check passes, with differences of about 1e-15.

## Limitations

- **HS8 trade weights:** CIMT's bulk files are HS6, so the HS8 lines of an HS6 get equal values unless `--trade-hs8` is given.
- **Unmapped imports:** imports with no line in the BS–HS8 file (for example HS chapters 98–99) get no tariff; the share is reported.
- **Coverage of the market model:** Table F.1 covers goods industries only. The network model covers every industry.
- **Simulated files:** the files in `data/simulated` are **not Statistics Canada data**. The IOT workbook was built from the public
  table by import proportionality; the BS–HS8 file uses rules on HS headings (`python -m tim.simulate`). Replace them with the real files.
