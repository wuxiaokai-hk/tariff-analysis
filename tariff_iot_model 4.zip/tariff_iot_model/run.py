"""Tariff -> CPI model on Statistics Canada's IOT tables, at the level of the input-output industries.

    python run.py --iot IOT.xlsx --concordance BS_HS8.xlsx

Inputs
  --iot           IOT workbook: Total, Domestic and Import-from-US tables (Imports optional), wide layout
  --concordance   BS-HS8 file: two columns, input-output industry code and HS8 tariff item
  trade           Canada's imports from the U.S. by HS6 (CIMT), downloaded for --trade-start..--trade-end
                  (or --trade-hs8 FILE with columns HS8,value to weight HS8 lines with HS8 values)
  lists           data/tariff_lists_hs6.csv (or --lists-hs8 FILE with an HS8 column)
  scenario        data/scenario_hs2.csv (rate and coverage by HS chapter) + --overrides FILE (code,rate_pct; HS6 or HS8)
Outputs (folder output/): summary CSV, industry CSV and the Excel workbook with live formulas.
"""
import argparse
import csv
import datetime
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from tim import cimt, concordance, excel, iot, model, network, static, tariffs  # noqa: E402

DATA = os.path.join(HERE, "data"); CACHE = os.path.join(DATA, "cache"); PROCESSED = os.path.join(DATA, "processed")


def label(a, b):
    return a[:4] if (a[5:], b[5:]) == ("01", "12") and a[:4] == b[:4] else f"{a} to {b}"


def main():
    ap = argparse.ArgumentParser(description="Tariff -> CPI model on the IOT tables (industry level)")
    ap.add_argument("--iot", required=True, help="IOT workbook (.xlsx)")
    ap.add_argument("--iot-sheets", default=None, help="sheet names if not recognised: total=...,domestic=...,us=...,imports=...")
    ap.add_argument("--concordance", required=True, help="BS-HS8 file (.xlsx or .csv, two columns)")
    ap.add_argument("--concordance-sheet", default=None)
    ap.add_argument("--trade-start", default="2024-01"); ap.add_argument("--trade-end", default="2024-12")
    ap.add_argument("--trade-hs8", default=None, help="optional CSV with columns HS8,value (C$) to weight HS8 lines")
    ap.add_argument("--lists", default=os.path.join(DATA, "tariff_lists_hs6.csv"))
    ap.add_argument("--lists-hs8", default=None, help="optional list flags by HS8 (same columns, key column HS8)")
    ap.add_argument("--scenario", default=os.path.join(DATA, "scenario_hs2.csv"))
    ap.add_argument("--overrides", default=os.path.join(DATA, "scenario_overrides.csv"), help="code,rate_pct (HS6 or HS8)")
    ap.add_argument("--uniform-rate", type=float, default=None, help="scenario: same rate (%%) on every chapter")
    ap.add_argument("--N", type=float, default=None, help="Canadian firms per industry (default: calibrated to Table F.1)")
    ap.add_argument("--denominator", choices=["Intermediate inputs", "Total output"], default="Intermediate inputs")
    ap.add_argument("--no-consumer", action="store_true", help="leave out households' direct purchases of U.S. imports")
    ap.add_argument("--refresh", action="store_true", help="download the trade data again")
    ap.add_argument("--out", default=None); ap.add_argument("--no-excel", action="store_true")
    a = ap.parse_args()

    sheets = dict(x.split("=", 1) for x in a.iot_sheets.split(",")) if a.iot_sheets else None
    io = iot.load(a.iot, PROCESSED, sheets)
    print(f"IOT workbook: {os.path.basename(a.iot)}; sheets {io['sheets']}; {len(io['inds'])} industries")
    conc, cinfo = concordance.read(a.concordance, a.concordance_sheet)
    print(f"BS-HS8 file: {cinfo['path']} (industry codes in column {cinfo['bs_column']}, HS8 in column {cinfo['hs8_column']}): "
          f"{cinfo['lines']} lines, {cinfo['hs8']} HS8 codes, {cinfo['split']} HS8 split between industries")
    rows, months = cimt.load(a.trade_start, a.trade_end, CACHE, PROCESSED, refresh=a.refresh)
    trade8 = None
    if a.trade_hs8:
        trade8 = {r["HS8"].zfill(8): float(r["value"]) for r in csv.DictReader(open(a.trade_hs8, encoding="utf-8"))}
    lists6 = tariffs.read_lists(a.lists)
    lists8 = tariffs.read_lists(a.lists_hs8, "HS8", 8) if a.lists_hs8 else None
    scen = tariffs.read_scenario(a.scenario, a.overrides if os.path.exists(a.overrides) else None, a.uniform_rate)
    print("Running the market model (calibrating N) and the network model ...")
    res = model.run(io, conc, rows, lists6, dict(N=a.N, scenario=scen, trade8=trade8, lists8=lists8, trade_rows=rows))
    per = label(a.trade_start, a.trade_end)

    cons = not a.no_consumer
    s = res["specs"][(a.denominator, cons)]
    print(f"\nTrade {per}; Canadian firms per industry N = {res['N']:.2f}; denominator: {a.denominator}; "
          f"consumer channel: {'Yes' if cons else 'No'}")
    un = sum(v for _, _, v in res["unmapped"]); tot = sum(v for _, _, v in rows)
    print(f"U.S. imports with no HS8 line in the BS-HS8 file: C${un / 1e9:.1f}bn of C${tot / 1e9:.1f}bn "
          f"({un / tot * 100:.1f}%), no tariff applied" + (f"; industry codes not in the IOT tables: {res['unknown_bs']}" if res["unknown_bs"] else ""))
    print(f"{'Package':45s} {'Full':>7s} {'Damp.':>7s} {'Ratio':>7s}   (CPI pp)")
    for k, p in enumerate(static.PACKAGES):
        f, d = s["full"]["total"][k], s["damp"]["total"][k]
        print(f"{p:45s} {f:7.2f} {d:7.2f} {d / f if f else 0:7.3f}")
    print(f"Custom scenario: average tariff {res['scen_points']:.2f} points on total imports")
    print("Paper (SWP 2026-35, 20 sectors, full pass-through): pre 1.56, post 0.72")
    v = {x["rate"]: x for x in res["validation"]}
    print("Market model vs SWP 2026-36 Table 3 (ratio model / paper): " +
          ", ".join(f"{int(t * 100)}% {v[t]['ratio']:.2f}/{v[t]['paper_ratio']:.2f}" for t in v) + f"; Table F.1 correlation {res['corr']:.3f}")

    os.makedirs(os.path.join(HERE, "output"), exist_ok=True)
    tag = f"{os.path.splitext(os.path.basename(a.iot))[0]}_trade{a.trade_start}_{a.trade_end}"
    summ = os.path.join(HERE, "output", f"summary_{tag}.csv")
    with open(summ, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["iot", os.path.basename(a.iot), "concordance", cinfo["path"], "trade_period", per, "N", round(res["N"], 4),
                    "built", datetime.date.today().isoformat()])
        w.writerow([])
        w.writerow(["Package", "Specification", "Full direct", "Full indirect", "Full total", "Dampened direct", "Dampened indirect", "Dampened total"])
        for (den, cn), sp in res["specs"].items():
            for k, p in enumerate(static.PACKAGES):
                fd, ft, dd, dt = sp["full"]["direct"][k], sp["full"]["total"][k], sp["damp"]["direct"][k], sp["damp"]["total"][k]
                w.writerow([p, f"{den}; consumer channel {'Yes' if cn else 'No'}", round(fd, 4), round(ft - fd, 4), round(ft, 4),
                            round(dd, 4), round(dt - dd, 4), round(dt, 4)])
        w.writerow([])
        w.writerow(["Sector (output-weighted average of its industries)"] + [f"Full price change %: {p}" for p in static.PKEYS]
                   + [f"Dampened price change %: {p}" for p in static.PKEYS])
        fs, ds = (network.by_sector(io["inds"], s["par"]["X"], s[k]["p"]) * 100 for k in ("full", "damp"))
        for i, sec in enumerate(static.SECTORS):
            w.writerow([sec] + [round(x, 4) for x in fs[i]] + [round(x, 4) for x in ds[i]])
    ind = os.path.join(HERE, "output", f"industries_{tag}.csv")
    with open(ind, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["Code", "Industry", "U.S. imports, mapped HS8 lines (C$)", "aCA", "aUS", "Household weight (domestic)",
                    "Household weight (U.S. imports)", "Market ratio rule"] + [f"Tariff: {p}" for p in static.PKEYS]
                   + [f"Dampened tariff: {p}" for p in static.PKEYS] + [f"Price change %: {p}" for p in static.PKEYS]
                   + [f"Dampened price change %: {p}" for p in static.PKEYS])
        par = s["par"]
        for k, c in enumerate(io["inds"]):
            w.writerow([c, io["names"][k], round(res["V"][k]), round(par["aCA"][k], 6), round(par["aUS"][k], 6), round(par["hd"][k], 6),
                        round(par["hus"][k], 6), res["rules"][k]] + [round(x, 6) for x in res["tau_full"][k]]
                       + [round(x, 6) for x in res["tau_damp"][k]] + [round(x * 100, 5) for x in s["full"]["p"][k]]
                       + [round(x * 100, 5) for x in s["damp"]["p"][k]])
    print(f"\nSummary: {summ}\nIndustries: {ind}")

    if not a.no_excel:
        out = a.out or os.path.join(HERE, "output", f"Tariff_IOT_Model_{tag}.xlsx")
        print("Writing workbook ...")
        excel.write(out, io, res, dict(iot=os.path.basename(a.iot), concordance=cinfo, period=per,
                                       n_months=len(months) if months else None, denominator=a.denominator, consumer=cons,
                                       scenario=scen, scenario_file=os.path.basename(a.scenario)))
        print(f"Workbook: {out}  (open in Excel; formulas calculate on opening)")


if __name__ == "__main__":
    main()
